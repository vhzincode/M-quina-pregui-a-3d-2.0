# Estudar um viral

> Pra IA. Faça um passo de cada vez, na ordem. Fale com a pessoa como no resto da Máquina: frases curtas, sem termo
> técnico, uma coisa de cada vez.

O que é: a pessoa traz um vídeo que viralizou (de qualquer canal, de qualquer site) e você descobre **por que ele
prendeu a atenção**, pra ela usar a mesma estrutura no tema do canal dela. Não é pra copiar o vídeo nem as frases.

Onde fica: `estudos/<nome-do-video>/`, uma pasta por vídeo. Quem baixa é o painel (menu **Estudar virais**) ou o
`npm run estudar`. Em cada pasta:

| Arquivo | O que é |
|---|---|
| `info.md` | Comece por aqui: o título, o canal, o link, a data, a duração, as views (e por dia), as curtidas, os comentários e a legenda do post |
| `transcricao-com-tempos.txt` | Tudo que é falado, frase por frase, com o tempo (`[00:12] frase`) |
| `transcricao.txt` | O mesmo texto, corrido |
| `mosaico-1.jpg`, `mosaico-2.jpg`... | 20 fotos das cenas por imagem, em ordem (da esquerda pra direita, de cima pra baixo), uma a cada 2 s no vídeo curto. É o jeito mais rápido de ver o vídeo inteiro |
| `quadros/` | As mesmas fotos, uma por arquivo, com o tempo no nome (`00m14s.jpg` = aos 14 s). Abra uma quando precisar ver um detalhe |
| `capa.jpg` | A capa (thumbnail) que aparece antes de clicar |
| `video.mp4` ou `audio.m4a` | O vídeo ou o áudio. Você não precisa abrir: o texto e as fotos bastam |
| `analise.md` | O estudo que você escreve no passo 3 |

## Passo 1. O vídeo já está na pasta?

- **A pessoa mandou um link** ("estuda esse viral: https://..."): rode `npm run estudar -- "<o link>"` (no Windows, se
  o npm der erro: `npm.cmd run estudar -- "<o link>"`). Ele baixa o vídeo, a capa e as fotos das cenas e diz a pasta.
  Na primeira vez, ele instala o baixador sozinho (uns 40 MB). Se der erro, mostre a mensagem dele pra pessoa, com as
  palavras dele: ela já diz o que fazer.
- **Falta a transcrição** (o `info.md` diz "a transcrição ainda não foi feita"): ela é feita no painel, porque roda no
  navegador. Rode `npm run painel -- --estudar` e diga pra pessoa: "Abri o painel no Estudar virais. A transcrição
  começa sozinha lá: quando aparecer **Ver o texto** no vídeo, me avisa". Sem a transcrição, dá pra estudar só as
  cenas e os números, mas avise que fica pela metade.
- **Já tem a pasta com a transcrição**: siga.

## Passo 2. Ler e olhar

1. Leia o `info.md` e a `transcricao-com-tempos.txt` inteira.
2. Olhe todos os `mosaico-*.jpg`, em ordem, e a `capa.jpg`. Fale só das cenas que você vê nas fotos: nunca invente.
3. Leia o guia do estudo, `viralizar/estudar-copy.md`, inteiro.
4. Leia o caderno, `estudos/virais-estudados.md`: os virais que a pessoa já estudou e o que se repete entre eles.
5. Leia o método do canal: `metodo/formula-roteiro.md` e `metodo/ritmo-e-visual.md` (e o `canal/metodo.md`, se
   existir, que vale por cima), e o `canal/canal.md` (do que o canal fala).

## Passo 3. O estudo

Siga o `viralizar/estudar-copy.md` (as partes 1 a 4) e escreva no formato da parte 5, em `estudos/<pasta>/analise.md`.
Com a pasta, você tem as fotos das cenas: use-as na lente "O gancho" e diga também o ritmo das trocas de cena e o que
aparece escrito na tela.

Depois, atualize o caderno (`estudos/virais-estudados.md`), como diz a parte 6 do guia: no bloco do vídeo (o título
com `estudos/<pasta>`), troque a linha "**Conclusão:** ainda não estudado..." pelas linhas da sua Conclusão, e
reescreva "O que se repete" e "Pra testar no próximo vídeo". Não mude o título nem as linhas dos números e do link.

Mande pra pessoa **só a Conclusão e o teste**, curto, e termine com a resposta pronta:
`Pode responder: "Faz um roteiro pro meu canal com essa estrutura" ou "Estuda outro"`.

## Passo 4. Virar roteiro (se ela pedir)

"Faz um roteiro com essa estrutura", "usa isso no meu próximo vídeo": siga o `comandos/novo-video.md` com um tema do
canal dela, usando a estrutura e o ritmo do estudo. **Nunca copie as frases, a piada ou o tema do viral**: a ideia é o
esqueleto, não o conteúdo. Repostar o vídeo ou o texto dos outros fere o direito autoral e as redes derrubam.

## Comparar vários

"Compara os virais", "o que eles têm em comum?": siga a parte 7 do `viralizar/estudar-copy.md`, com o caderno
(`estudos/virais-estudados.md`) e o `analise.md` de cada pasta (faça o passo 3 nas que ainda não têm). O resultado vai
pro próprio caderno ("O que se repete" e "Pra testar no próximo vídeo"). O padrão que virou regra no canal da pessoa
(testado, com número) vai também pro `canal/aprendizados.md`, com o OK dela.

## Sem pasta (IA de chat)

Quem usa a IA pelo chat não tem a pasta: no painel, cada estudo tem o botão **Copiar pra IA de chat**, que leva o guia
de estudo, o resumo do caderno, os números e tudo que é falado, com os tempos. A IA de chat segue o guia colado (sem as
fotos, ela diz isso) e, no fim, a pessoa cola a resposta no mesmo vídeo, em **Guardar a resposta da IA**: o painel
guarda o `analise.md` e atualiza o caderno sozinho.
