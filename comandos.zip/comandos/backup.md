# Backup no GitHub

> Pra pessoa não perder a Máquina, o canal e os vídeos se o computador quebrar, for formatado ou a pasta sumir. Ligar
> leva uns 5 minutos e é uma vez só. Depois, a IA faz o backup no fim de cada vídeo.

O backup guarda a pasta da Máquina num **repositório privado** do GitHub da própria pessoa. O GitHub é um site grátis
que guarda arquivos e as versões deles. Privado quer dizer que só ela vê: a Máquina recusa repositório público, porque
o código da Máquina é vendido e não pode ficar aberto pra todo mundo.

## O que vai e o que fica

| Vai pro backup | Fica só no computador |
|---|---|
| O canal inteiro (`canal/`: o nome, o personagem, o logo, o banner, o que a IA aprendeu, o histórico, as conquistas) | A chave da voz (`.env`): é segredo |
| De cada vídeo: o roteiro, a ficha de cena, o `roteiro.json`, o `cena.js`, a capa, o texto de postar, a opinião | Os vídeos `.mp4` e a voz já narrada: grandes demais pro GitHub |
| Os virais estudados: a análise, a transcrição, a capa e os mosaicos, e o caderno dos virais | O vídeo baixado de cada viral e as fotos das cenas |
| A própria Máquina, pronta pra usar | O que a Máquina instala sozinha (`node_modules`, `.ferramentas`) e os testes |

Arquivo maior que 45 MB fica de fora sozinho (o GitHub recusa acima de 100 MB), e o backup avisa qual foi.

## Ligar (a primeira vez)

Quem liga é a pessoa, no painel, porque o login é no site do GitHub, com a conta dela. Nenhuma senha passa pela
Máquina.
1. Rodar `npm run backup -- --ligar`: ele abre o painel no quadro "Backup no GitHub", em Comece aqui
2. Dizer pra pessoa, com as suas palavras: "Abri o painel no backup. Clique em **Ligar o backup**. Vai aparecer um
   código de 8 letras: clique em **Abrir o GitHub**, entre na sua conta (ou crie uma, é grátis), cole o código e clique
   em **Authorize**. O resto a Máquina faz sozinha. Quando aparecer *Backup ligado*, me avise."
3. Ela avisou: `npm run backup -- --estado` confere e mostra o endereço do repositório. Anotar no histórico

Por dentro, a Máquina: baixa o programa oficial do GitHub (o `gh`, conferindo a soma) pra `.ferramentas/`; no Windows
sem Git, baixa o Git portátil oficial também; no Mac sem as ferramentas da Apple, abre a janela da Apple pra instalar.
Depois cria o repositório privado (`maquina-<nome-do-canal>`), troca o `.gitignore` que veio no zip pelo do backup (o
do zip deixa o canal de fora) e manda tudo. O repositório fica anotado em `canal/backup.json`, que vai junto na versão
nova da Máquina (`npm run importar`): ligar de novo lá continua de onde parou, no mesmo repositório.

## Todo dia

- **No fim de cada vídeo** (passo 5 de `comandos/novo-video.md`): `npm run backup`. Se o backup não está ligado, ele
  diz e não faz nada: não insista, só lembre a pessoa de vez em quando
- **A pessoa pediu** ("faz o backup", "salva no GitHub"): `npm run backup`
- No painel, em Comece aqui: o botão **Fazer backup agora** e quando foi o último

## Perdi o computador (ou formatei): como voltar

1. No computador novo, entrar no **github.com** com a conta, abrir o repositório `maquina-<nome-do-canal>`, clicar no
   botão verde **Code** e em **Download ZIP** (não precisa baixar a Máquina de novo na área de membros: ela está no
   backup, junto com o canal)
2. Extrair o zip numa pasta (Documentos, por exemplo) e abrir essa pasta na IA. Mandar: **instalar**. O
   `npm run instalar` põe o que fica de fora do backup (`node_modules`, o navegador que desenha o vídeo)
3. A chave da voz não vem (é segredo): `npm run chave` e colar de novo
4. Os vídeos `.mp4` não vêm: a capa, o roteiro e a cena estão lá, e o vídeo se refaz com `node motor/render.js
   videos/<tema>` (a voz é narrada de novo, então gasta crédito da ElevenLabs)
5. Ligar o backup de novo no painel: ele reconhece o repositório e continua de onde parou

## Se travar

| O que apareceu | O que fazer |
|---|---|
| "O Mac precisa das ferramentas da Apple" | Uma janela da Apple abriu: clicar em Instalar e esperar (5 a 10 minutos). Não abriu? Rodar `xcode-select --install`. Depois, Ligar o backup de novo |
| "O código venceu" | O código vale uns 15 minutos. Clicar em Ligar o backup de novo |
| "O acesso foi negado" | No site, a pessoa clicou em Cancel. Ligar de novo e clicar em **Authorize** |
| "Esta pasta já tem um controle de versões (git)" | A pasta não veio do zip (ou alguém usou git nela). O backup não mexe: usar numa pasta da Máquina que veio do zip |
| "O repositório está público" | O backup tenta deixar privado sozinho (Ligar o backup de novo). Se não der: no GitHub, abrir o repositório, Settings, lá embaixo em **Change visibility** → **Private** |
| "O login no GitHub saiu" | Ligar o backup de novo (o login fica só nesta pasta, em `.ferramentas/gh-config/`) |
| "Não consegui mandar o backup" | Conferir a internet e rodar `npm run backup` de novo. O detalhe do erro aparece embaixo da mensagem |
| Um arquivo ficou de fora por ser grande | Normal: o GitHub não aceita arquivo tão grande. Ele continua no computador |
| Linux sem git | `sudo apt install git` (ou o instalador do sistema) e Ligar o backup de novo |

Nunca peça pra pessoa abrir o terminal pra isso, e nunca mostre nem mande o token do GitHub (fica em
`.ferramentas/gh-config/`, que não vai pro backup).
