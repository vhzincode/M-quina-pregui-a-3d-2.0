# Onde fica cada coisa (toda mídia tem lugar certo)

> Pra IA: a tabela completa de onde a Máquina grava cada arquivo. As regras curtas estão no `AGENTS.md`.

A pessoa tem que achar qualquer arquivo pelo nome do vídeo. O motor já grava assim; a IA segue o mesmo pro que fizer
por conta própria.

| O quê | Onde |
|---|---|
| A entrega: `video.mp4`, `capa.png`, `publicacao.md` | `videos/<tema>/` |
| O roteiro e a cena: `roteiro.md`, `roteiro.json`, `cena.js` | `videos/<tema>/` |
| Todo teste do vídeo: prévias, trechos, vídeo com voz de teste | `videos/<tema>/testes/` (o motor grava lá sozinho) |
| A narração de cada frase, guardada pra não gastar crédito de novo | `videos/<tema>/narracao/` (o motor cuida) |
| Versão anterior de um vídeo já entregue | `videos/<tema>/versoes/` |
| A revisão das cenas: a folha (uma imagem por frase) e o relatório | `videos/<tema>/testes/folha.jpg` e `revisao.txt` |
| Cada cena solta, que o painel mostra pra pessoa opinar | `videos/<tema>/testes/cenas/` e `testes/cenas.json` (o `--revisar` grava) |
| A opinião que a pessoa deu no painel (cena por cena e o vídeo pronto) | `videos/<tema>/opiniao.json` (o painel grava; `npm run painel -- <tema> --opiniao` mostra) |
| Amostras de voz pra escolher a do canal | `canal/testes-de-voz/` (`npm run testar-voz -- <id>`) |
| A chave da voz (ElevenLabs) | `.env` na raiz da pasta, linha `ELEVENLABS_API_KEY=` (`npm run chave` abre a janelinha) |
| Logo do canal | `canal/logo.png` |
| Banner do YouTube e as descrições do canal em cada rede | `canal/banner.jpg` e `canal/perfil.md` (o painel salva os dois) |
| Pacote extra de modelos 3D e cenários (baixado à parte) | `motor/modelos/` e `referencias/cenarios/` (`npm run painel -- --pacote <zip>` ou o painel põem lá; o registro fica em `motor/modelos/pacotes.json`) |
| Imagens e vídeos de referência que a pessoa mandou | `canal/referencias/` (`npm run quadros -- <vídeo>` faz a folha de um vídeo) |
| Os virais que a pessoa baixou pra estudar: o vídeo, a capa, as fotos das cenas, a transcrição e o seu estudo | `estudos/<nome>/` (o painel e o `npm run estudar` gravam; o seu estudo vai em `analise.md`) |
| O caderno dos virais: cada estudo, a conclusão de cada um, o que se repete e o próximo teste | `estudos/virais-estudados.md` (a Máquina põe cada vídeo novo; você escreve a conclusão; a versão nova não apaga) |
| O backup no GitHub: o repositório privado da pessoa e o que não vai pra ele | `canal/backup.json` (o repositório; vem junto no `npm run importar`) e o `.gitignore` do backup; o login do GitHub fica em `.ferramentas/gh-config/`, que não vai pro backup (`comandos/backup.md`) |
| Tudo pra viralizar: as dicas, cada rede, os horários, os cuidados, os números e o jeito de estudar a copy | `viralizar/` (comece pelo `LEIA-PRIMEIRO.md`; é parte da Máquina, não escreva lá) |
| As conquistas do canal (os marcos batidos, a última leitura do YouTube e as capas dos vídeos que bateram marco) | `canal/conquistas.json` e `canal/conquistas/` (o painel e o `npm run conquistas` gravam; não edite à mão, use o `npm run conquistas`) |
| O programa que baixa os vídeos (yt-dlp) e os atalhos do ffmpeg | `.ferramentas/` (a Máquina baixa e atualiza sozinha; não mexa) |
| Teste da instalação | `videos/exemplo/testes/` (apagar depois do teste) |

- Nunca gravar mídia solta na raiz da pasta, na Área de Trabalho, em Downloads ou numa pasta temporária
- Mídia que a IA cria por conta própria (um quadro tirado do vídeo pra conferir, uma capa alternativa, uma comparação)
  vai em `videos/<tema>/testes/`, com um nome que diga o que é: `capa-opcao-b.png`, `quadro-12s.jpg`
- Refazer um vídeo já entregue: antes do render, mover o `video.mp4` e a `capa.png` antigos pra
  `videos/<tema>/versoes/` com a data (`video-28-10-2026.mp4`, `capa-28-10-2026.png`), pra dar pra voltar atrás
- Ao mostrar uma mídia pra pessoa, mandar o link do arquivo (pra abrir com um clique) e dizer em que pasta ela fica
