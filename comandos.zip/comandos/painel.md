# O painel da Máquina (`npm run painel`)

> Pra IA: o que tem em cada menu do painel e quando abrir. O resumo (e a regra de terminar toda resposta com o link)
> está no `AGENTS.md`, regra número 4. Leia este arquivo quando a pessoa perguntar de um menu ou pedir algo que o painel faz.

Uma página no navegador da pessoa, com o menu do lado. É a parte visual: mostra o que a Máquina fez e facilita umas
configurações; mudança de vídeo, roteiro e cena a pessoa pede pra você. Ela atualiza sozinha quando você muda um
arquivo, então a pessoa acompanha tudo lá:
- **Comece aqui:** como a Máquina funciona, o que falta instalar ou configurar (o `npm run conferir` em palavras
  simples), com a barra de progresso, o **Backup no GitHub** (ligar, fazer agora e quando foi o último:
  `comandos/backup.md`) e o quadro pra subir um pacote extra de modelos 3D
- **Meu canal:** as perguntas do canal, cada uma no seu campo e separadas por assunto (as mesmas do
  `CONFIGURAR-MEU-CANAL.txt`; em branco, o campo já vem com o padrão da Máquina escrito): a capa (banner do YouTube) e o
  logo, o nome, o @ e a assinatura, do que fala e quem assiste, o jeito dos vídeos (jeito de falar, o que evitar, estilo
  do vídeo, marca registrada, estilo da capa, fechamento, chamada do fim e hashtags), o visual (redondo ou simples), o
  personagem e as cores dele, o cenário e a hora, a voz, a cor e as descrições nas redes (`canal/perfil.md`). **O que a
  pessoa salva lá muda os arquivos do canal** (`canal/canal.md`, `canal/identidade.md`, com o bloco "No roteiro.json"):
  leia de novo antes de cada vídeo, e não desfaça o que ela mudou no painel sem perguntar. No fim fica **Os roteiros**:
  o método (`metodo/formula-roteiro.md` e `metodo/ritmo-e-visual.md`), tópico por tópico, pra ela ler e mudar; o que
  ela muda vai pro `canal/metodo.md`
- **Vídeos:** um card por pasta de `videos/`, com o vídeo completo, o texto de postar com botão de copiar, as cenas (a
  folha do `--revisar`, uma imagem por frase) e o roteiro. **Nas cenas, a pessoa marca Gostei ou Mudar em cada uma e clica
  em "Mandar pra IA"**: a opinião fica em `videos/<tema>/opiniao.json`, e `npm run painel -- <tema> --opiniao` mostra em
  texto, com a linha `PRA IA:` do que fazer
- **Modelos 3D:** tudo que a Máquina sabe desenhar, por tipo, com a foto de cada um e o pedido pra copiar. As fotos e o
  catálogo ficam em `referencias/modelos/` (`catalogo.json`: o nome, como pedir e o código do `cena.js` de cada item):
  bom pra mostrar à pessoa o que dá pra usar. `npm run modelos` tira as fotos que faltam (`--todos` refaz todas,
  depois de mudar o motor); o painel roda sozinho quando um pacote extra é vinculado
- **Potencializar a máquina:** os extras vendidos à parte (30 Roteiros + 100 Temas, Canal Gringo, Checklist Viral +
  Plano de 30 Dias e Atualizações Para Sempre), com o link de compra, onde achar o arquivo na área de membros e o quadro
  pra soltar o arquivo baixado (o de hoje ou o que veio pelo Google Drive). `motor/potencializar.js` põe cada coisa no
  lugar: os 30 roteiros em `videos/<NN-tema>/`, já com o bloco "No roteiro.json" do canal e a assinatura do fim, e o
  resto em `canal/extras/` (vai junto no `npm run importar`). "Faz o vídeo de videos/<NN-tema>: o roteiro já está
  pronto" = `node motor/render.js videos/<NN-tema>` (cena-modelo montagem, sem `cena.js`); "com cena própria" = o
  `comandos/novo-video.md` partindo desse roteiro, sem reescrever a narração. Os modelos do Canal Gringo ficam em
  `canal/extras/gringo/canal-en.md` e `canal-es.md`. Sem o painel, o mesmo pelo `npm run extras`; o passo a passo de
  cada extra está em `comandos/extras.md`
- **Estudar virais:** a pessoa cola o link de um vídeo que viralizou (YouTube, Instagram, TikTok, Kwai e centenas de
  outros sites), vê as qualidades (do 144p ao 4K, com o formato e o tamanho, ou só o áudio) e baixa pra
  `estudos/<nome>/`, com a capa, os números e as fotos das cenas. A transcrição roda ali no navegador (o Whisper) e
  grava o texto na pasta; também dá pra soltar um áudio ou vídeo do computador. Cada estudo tem o pedido pronto pra
  você estudar: siga o `comandos/estudar-viral.md` (o estudo da copy e as conclusões: `viralizar/estudar-copy.md`).
  Cada conclusão vai pro **caderno dos virais** (`estudos/virais-estudados.md`), que junta todos os estudos, o que se
  repete entre eles e o próximo teste. É também a **central de viralização**, com uma aba pra cada assunto (o caderno,
  todas as dicas, YouTube, Instagram, TikTok, horários, cuidados e números): são os arquivos de `viralizar/`, que você
  também lê (`viralizar/LEIA-PRIMEIRO.md` diz qual arquivo ler pra cada pergunta)
- **Conquistas:** três trilhas que andam sozinhas: Ritmo (vídeos postados), Alcance (as views do vídeo mais visto) e
  Seguidores (os inscritos), e o nível é a soma das três. A Máquina lê o YouTube público da pessoa pelo "@ nas redes"
  (sem senha e sem login) e marca cada conquista; a cada uma, o painel monta a arte do story com a capa do vídeo, pra
  ela postar marcando o @desconstruindouniverso, que reposta. A pessoa contou que bateu um marco: siga o
  `viralizar/conquistas.md` (comemore, rode `npm run conquistas`, e, se foi no Instagram ou no TikTok, que a Máquina
  não lê, `npm run conquistas -- --marcar <marco>`; depois mande o link do painel em Conquistas,
  `npm run painel -- --conquistas`)
- **Sobre:** de onde a Máquina veio (o canal Desconstruindo Universo) e os perfis dele nas redes, com o e-mail de
  suporte
- **Ajuda:** as perguntas mais comuns, separadas por assunto, com um campo pra procurar, e as boas práticas. Cada
  resposta traz o pedido pronto pra pessoa copiar e mandar pra você

Quando abrir: no fim da configuração (`comandos/instalar.md`, passo 4), quando as cenas de um vídeo ficam prontas
(`npm run painel -- <tema>`, passo 3 de `comandos/novo-video.md`), na entrega do vídeo e sempre que a pessoa pedir
("abre o painel", "cadê o meu vídeo?"). Rodar de novo reabre o mesmo painel, **sem encher o navegador de abas**: se o
painel já está na tela da pessoa, ele só troca de tela ali mesmo; se abrir uma aba nova, a velha se fecha sozinha. O
`--revisar` só abre o painel quando dá APROVADO (antes, o que já estiver aberto atualiza sozinho). O comando volta na hora e o painel fica
aberto por 12 horas; se o seu programa fechar o painel quando o comando termina, use `npm run painel -- --esperar` (fica
preso ao comando até a pessoa clicar em "Mandar pra IA" ou "Terminei", e mostra o que ela mandou). O painel não troca a
conversa: tudo o que dá pra fazer nele dá pra pedir aqui também.
