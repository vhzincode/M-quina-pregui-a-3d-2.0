# A fórmula do roteiro

O vídeo não explica o objeto pronto. Ele **monta o objeto do zero, junto com quem assiste**, e cada peça só aparece
porque resolve um problema que a peça anterior criou. No fim, a pessoa entende por que a coisa é do jeito que é.

## O que faz um vídeo viralizar

Tirado dos vídeos de "como funciona" que passaram de 1 milhão de views e dos números de um canal feito com este método.

- **Viraliza o vídeo que a pessoa manda pra alguém.** Segurar até o fim ajuda, mas o que espalha é o envio: o vídeo
  mais visto do canal tinha uma turma que manda pro amigo e 6 dicas que davam pra usar
- **Prender o começo não basta.** O vídeo que menos gente pulou no começo foi um dos que menos foram enviados: a
  pessoa ficou, mas não tinha pra quem mandar
- **O gancho com contradição segura mais.** Com uma contradição na pergunta ("mesmo com", "se", "tão... e..."), de 22%
  a 32% das pessoas pularam nos 3 primeiros segundos. Com o "Como funciona X?" sozinho, até 46% pularam
- **Um problema novo a cada 10 ou 15 segundos.** Ver coisa quebrando prende: a pessoa fica pra ver o que quebra depois
- **Visual bonito é o mínimo, não o que faz viralizar.** O vídeo mais caprichado no visual foi um dos que menos
  espalharam. O que espalha é o tema e o roteiro

## Como escolher o tema

Antes de escrever, três perguntas. **Dois "sim" e o tema é forte:**

1. **A pessoa já viveu a cena do gancho?** Já ficou sem sinal no meio da rua; já queimou a mão no cabo da panela
2. **Tem uma turma que manda o vídeo pra alguém?** Pescador, mãe de pet, quem trabalha em obra, quem tem carro velho
3. **A pessoa sai com uma dica que dá pra usar?** Um jeito de fazer melhor, um erro pra evitar, um "nunca faça isso"

- **O que mais rende:** coisa que a pessoa usa ou vê todo dia e nunca pensou por dentro. Obra e estrutura grande
  (ponte, prédio, telhado) primeiro, depois aparelho (geladeira, micro-ondas, ar-condicionado) e carro. Tem partes
  escondidas (dentro da parede, embaixo da terra, atrás do aparelho) e dá pra montar peça por peça
- **A água é a vilã** em 7 de cada 10 vídeos que viralizaram: vaza, infiltra, alaga, apodrece
- **Bicho, só quando a pessoa convive com ele** (mosquito, gato, cachorro). Bicho de outro país fica pra depois
- **Espaço e história, só com medo ou mito forte** (o perigo escondido, o mito que todo mundo repete). Sem isso, é o
  que mais perde gente no começo
- **Assunto polêmico pode, sempre neutro:** mostra o que dá certo e o que dá errado de cada lado, com número
  conferido, e deixa a conclusão pra quem assiste
- **Teste rápido:** dá pra fechar com "Coloque ___, ___ e [uma piada]. Agora é só ___."? E tem uns 5 problemas que dá
  pra ver quebrando na tela? Se sim, o tema encaixa

## Por que prende

- **Quem assiste é o inventor.** O texto fala "você" o tempo todo: "então você põe", "você encaixa". Não é aula, é missão
- **Cada ciclo é uma fase de jogo:** quebra, conserta e ganha uma peça nova com o nome em amarelo, que funciona como
  conquista
- **O nome técnico é a recompensa.** A peça aparece pelo que ela faz ("um espelho em forma de tigela") e só depois
  ganha o nome ("Esse é o refletor")
- **O "ah, então é por isso".** Ligar a explicação a algo que a pessoa já viu e nunca entendeu ("é ele que faz aquele
  barulho quando você liga"). É o trecho que ela manda pros amigos
- **Sem porta de saída:** a fala começa no primeiro segundo e quase não para, e a imagem muda o tempo todo

## O esqueleto

```
GANCHO        Uma pergunta BEM curiosa, de até ~10 palavras, com uma contradição e a resposta no vídeo.
              "Como uma pilha desse tamanho ilumina o quintal inteiro?"

COMEÇO        Se você [tenta resolver do jeito mais simples], [o que dá errado, em cena].
              O personagem já sofre aqui, e o primeiro problema aparece até uns 8 segundos.
              "Se você precisa achar a chave no quintal à noite, tateia o chão e tropeça no primeiro degrau."

CICLOS        Mas [problema novo, criado pela solução anterior, que dá pra ver quebrando].
(6 a 10x)     Então você [solução, descrita pelo que ela faz].
              Esse é o / Essa é a [NOME].
              (às vezes) É por isso que [algo do dia a dia].

ACABAMENTO    Coloque [2 ou 3 detalhes que completam o objeto, o último com uma piada].
              "Coloque uma alça de pano, um gancho pra pendurar e um adesivo que ninguém lê."
USO           Agora é só [usar].
              "Agora é só apagar a luz e achar a chave de primeira."
VITÓRIA       A frase de vitória do seu canal (o Fechamento, em Meu canal), curta e com o tema do vídeo.
CHAMADA       O pedido do fim do seu canal (a Chamada, em Meu canal), curto. A assinatura do canal pode vir colada
              nele, curtinha; o cartão de seguir aparece na tela de qualquer jeito. Nada depois disso.
```

O "Por fora, é só... Por dentro, é..." das versões antigas ainda funciona, se for o fechamento do seu canal.

## As regras que fazem funcionar

1. **O problema nasce da solução anterior.** Lâmpada → não acende sozinha → pilha → a luz espalha → refletor → a pilha
   acaba → botão. É uma corrente. Se dá pra trocar dois ciclos de lugar sem quebrar nada, virou lista de peças
2. **O problema é visível.** Racha, tomba, vaza, apaga, esquenta, derrete, cai. Nada de "perde eficiência": tem que dar
   pra mostrar na tela (o motor tem pronto: treme, tomba, murcha, apaga, esquenta, congela, pisca, quebra)
3. **Um desastre que se vê em todo ciclo.** A casa alaga, o objeto desmonta, o personagem cai. A falha é a cena mais
   forte do ciclo
4. **Descreve antes de nomear.** "Você põe atrás da lâmpada um espelho em forma de tigela, que joga a luz pra frente.
   Esse é o refletor."
5. **O nome vem sozinho, numa frase curta.** "Esse é o refletor." Vira o rótulo amarelo na tela
6. **Ciência sem nome de lei.** "Empurra o ar pra baixo e é empurrado pra cima." Nada de "terceira lei de Newton"
7. **Os conectores se repetem de propósito:** "Mas", "Então você", "Esse é". Quem assiste começa a antecipar a virada

## O personagem que sofre por nós

O personagem vive uma pequena história em todo vídeo:

- **A dor logo no começo:** depois do gancho, ele já está com o problema (encharcado, no escuro, sem água)
- **Sofre em cada falha, com o corpo:** sua, congela, leva choque, cai, fica verde. Sofre, mas nunca é humilhado
- **Ganha no fim:** na vitória, ele comemora
- A mesma graça pode voltar duas vezes (o tombo que se repete). Um ajudante (um bicho, um vizinho) pode aparecer, com
  um papel na história

## Os temperos

- **"É por isso que..." da vida real (pelo menos 2):** "É por isso que a lanterna esquenta na mão depois de um tempo."
- **Uma dica que dá pra usar (pelo menos 1):** o que fazer, o que evitar. É o que faz a pessoa salvar e mandar
- **Um número concreto (pelo menos 1):** "uma pilha comum aguenta umas poucas horas acesa direto." Gruda na memória
- **Comparação caseira (1 a 3):** "igual a uma mangueira com o dedo na ponta". Certa antes de engraçada
- **Quebra de mito:** "A pilha não guarda eletricidade pronta. Ela fabrica na hora, com uma reação química."
- **Humor na medida:** o personagem sofrendo cada falha, a piada no último item do "Coloque..." e, no máximo, uma ou
  duas frases secas no meio ("E garfo? Nem pensar!"). A piada nunca toma o lugar da explicação

## Linguagem

- Sempre "você". Frases curtas, de ~10 palavras: a legenda entra palavra por palavra. No máximo 4 frases com mais de
  15 palavras no vídeo inteiro
- Coloquial: "pra", "tá", "aí", "rapidinho". Diminutivo deixa leve: "pecinha", "furinho"
- Verbo de ação física: põe, encaixa, estica, aperta, enrola, pendura
- Palavra difícil só depois do que ela faz, em palavra do dia a dia: "Na parede, pra passar os fios, vai um tubo
  amarelo chamado eletroduto."
- Nada de "basicamente", "é importante ressaltar", "você sabia que...?", bordão de internet ou risada escrita

## Tamanho

| | Primeiro vídeo (aprendendo) | Vídeo pra crescer e monetizar |
|---|---|---|
| Duração | ~60 s | Curto e seco: 1:05 a 1:50. Longo e denso: 1:55 a 2:50 (o YouTube Shorts vai até 3:00) |
| Palavras | 150 a 200 | 220 a 550 (os que viralizaram têm, em média, uns 470) |
| Ciclos "Mas → Então → Esse é" | 3 a 4 | 6 a 10 |

A ~190 palavras por minuto, que é o ritmo dos vídeos curtos que prendem. O meio-termo (uns 1:50 sem ser seco nem denso)
é o que menos aparece entre os que viralizaram.

## Gancho, título e capa conversam

- **Gancho falado:** a pergunta que a pessoa já se fez, com uma contradição dentro ("mesmo com", "se", "tão... e..."):
  "Como um prego tão fino segura um quadro pesado na parede?". Pode ser ousado ("Se um tubarão morder o cabo, a
  internet cai?"). O "Como funciona X?" sozinho é o que mais faz pular
- **Título:** a pergunta que uma criança curiosa faria e alguém digitaria na busca, com o detalhe que intriga
  ("Como um avião tão pesado consegue voar?"). Até ~60 caracteres
- **Capa:** a pergunta escrita (ou bem perto dela) + a imagem do detalhe mais estranho, tudo exagerado: a cara do
  personagem, o gesto, o tamanho do objeto
- **Proibido:** "Você sabia que...?", pergunta que se responde sozinha e prometer o que o vídeo não mostra

## O pedido do fim

- **Um pedido principal, fácil de responder,** logo depois da vitória: uma pergunta curta ligada ao tema ("Qual coisa a
  gente desmonta no próximo? Comenta aí.") ou o par de palavras do próprio tema ("Se você sabia, comente [palavra]. Se
  não sabia, comente [outra]."). Quem sabia se exibe, quem não sabia brinca consigo mesmo, e os dois comentam
- **A assinatura do canal fecha curtinha** ("E segue o..."), e o cartão de seguir aparece na tela
- **Não peça like** nem empilhe mais pedidos (mandar pra alguém, clicar no link, ativar o sininho, tudo junto)

## Checklist antes de aprovar o roteiro

- [ ] O tema passa em pelo menos 2 das 3 perguntas (a pessoa viveu, tem turma, sai com dica)
- [ ] Abre com a pergunta curiosa, com uma contradição, e a resposta aparece no vídeo
- [ ] Depois, "Se você..." com o personagem já sofrendo, e o primeiro problema até uns 8 segundos
- [ ] Cada problema nasce da solução anterior e dá pra ver quebrando: um desastre em todo ciclo
- [ ] Toda peça é descrita antes de ganhar nome
- [ ] Pelo menos 2 "é por isso que", 1 dica que dá pra usar, 1 número e 1 comparação caseira
- [ ] Frases curtas (~10 palavras; no máximo 4 com mais de 15)
- [ ] Fecha com "Coloque..." (a piada no último item), "Agora é só...", a vitória e um pedido só
- [ ] A ciência foi conferida (simplificar pode, inventar não)
- [ ] Toda frase tem uma ideia de cena diferente da anterior (a ficha de cena do `referencias/COMO-FAZER-O-VIDEO.md`,
      no formato de `referencias/modelo-construcao/roteiro.md`): se uma frase não tem nada pra mostrar, troque a frase
- [ ] Toda coisa concreta que a narração cita (peça, objeto, bicho, lugar, efeito) aparece na tela na frase em que é
      falada (o teste dos substantivos da ficha)
- [ ] Nenhuma frase copiada de outro vídeo
