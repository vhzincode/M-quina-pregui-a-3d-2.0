# Ritmo e visual

O que o roteiro não mostra, mas segura a pessoa no vídeo. O `cena.js` de cada vídeo faz isso (ver `referencias/COMO-FAZER-O-VIDEO.md` e o exemplo em `videos/exemplo/`).

## Ritmo

- **~190 palavras por minuto.** Mais rápido que uma conversa: o motor acelera a voz até chegar perto disso
- **Sem respiro:** a fala começa no primeiro segundo e ocupa uns 90% do vídeo. Silêncio é porta de saída
- **A imagem muda a cada 1 ou 2 segundos.** Uma frase = um plano de câmera. Nenhum plano parado. Num vídeo que
  viralizou, foram umas 18 trocas de plano por minuto
- **Cada frase é uma cena diferente, com 4 ingredientes:** a câmera se mexendo (e diferente da frase anterior), o
  personagem atuando, algo acontecendo (peça entrando, peça falhando, efeito) e um texto ou som. A mesma animação em
  várias frases seguidas é o que mais faz a pessoa sair do vídeo. A revisão (`--revisar`) confere isso sozinha
- **O que a voz fala aparece na hora:** "tropeça" → ele tropeçando quando a palavra sai, não um segundo depois
- **A câmera perto e andando:** o personagem ocupa pelo menos 1/3 da altura da tela e a peça da frase enche boa parte
  do quadro. Plano aberto só no gancho, numa revelação e no fim. A câmera anda com vontade em toda frase (chegando,
  girando, subindo, passando) e nunca filma junto duas coisas longe uma da outra. Câmera longe e parada deixa o cenário
  com cara de vazio e o vídeo com cara de parado
- **Quadro cheio:** coisas do lugar perto da ação e, de vez em quando, algo passando na frente da câmera
- **Volume em −14 LUFS**, o padrão das redes (o motor normaliza)

## Na tela

- **Legenda uma palavra por vez**, branca com contorno preto, no meio da tela. O termo-chave (`*palavra*` no roteiro)
  fica amarelo
- **Rótulo amarelo grande** no "Esse é o X", colado na peça. A peça fica amarela translúcida por um instante
- **A camada de informação:** pílulas que dizem o que a narração diz (com cor que tem sentido: vermelho = problema,
  verde = funciona, as outras = neutras), placas de estado ("VAZANDO", "FUNCIONANDO"), medidores e contadores
  ("3 HORAS"), etapas numeradas. Até 3 na tela de uma vez, e só quando ajudam
- **✓ verde e ✗ vermelho** quando funciona ou falha
- **O invisível vira visível:** luz como feixe, calor como fogo, vapor subindo, água escorrendo
- **Preto e branco e rebobinar, só no desastre mais forte:** no máximo 2 por vídeo. Em todo ciclo, cansam

## Som

- **Um efeito em cada interação:** peça caindo, encaixando, luz acendendo, fogo, água
- **Sempre por baixo da voz:** a trilha baixinha abaixa sozinha quando a voz fala, e efeito nenhum fica mais alto que
  a narração
- Os sons ficam em `motor/sons/`. Dá pra trocar a trilha por uma música sua (`trilha.arquivo` no roteiro.json)

## Capa e primeiro segundo

- A capa é o **1º quadro do vídeo**, e a pergunta fica escrita no topo enquanto o gancho é falado: quem vê a capa e
  toca no vídeo não percebe corte. Logo depois, o personagem já aparece vivendo o problema
- **Tudo exagerado:** a cara do personagem, o gesto, o tamanho do objeto e o detalhe mais estranho, com contraste forte.
  A capa tem que causar uma emoção (susto, curiosidade, riso)
- **Tudo que importa fica no meio da tela** (entre 1/8 e 7/8 da altura): o TikTok corta a capa em 3:4
- A pergunta numa caixa branca, com uma palavra na cor do canal

## Depois de postar, o que olhar

- **% que pula nos 3 primeiros segundos** (o Instagram e o TikTok mostram): passou de 35%, o problema é o gancho ou a
  capa. Teste uma pergunta com contradição
- **Envios a cada mil views:** é o que mais espalha. Baixo, o tema não tem turma pra quem mandar, ou falta o "é por
  isso que" e a dica
- **Views por hora nas primeiras 24 horas:** compare sempre na mesma idade. Vídeo que começa devagar pode crescer
  depois, se quem fica assiste até o fim
- **Seguidores por vídeo:** o número que diz se o canal está crescendo
