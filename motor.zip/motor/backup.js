// O backup da Máquina no GitHub: npm run backup
//
//   npm run backup                  faz o backup agora (se ainda não está ligado, diz como ligar)
//   npm run backup -- --ligar       abre o painel no quadro do backup, onde a pessoa liga com 3 cliques
//   npm run backup -- --estado      só conta como está (ligado ou não, o repositório, o último backup)
//
// Pra a pessoa não perder o canal e os vídeos se o computador quebrar, for formatado ou a pasta sumir. Guarda a pasta
// da Máquina num repositório PRIVADO do GitHub da própria pessoa (grátis), com o canal, os roteiros, as cenas, as
// capas, os estudos e as conquistas. Fica de fora o que é segredo (.env, com a chave da voz), o que a Máquina instala
// sozinha (node_modules, .ferramentas) e o que é grande demais pro GitHub (os .mp4, a voz já narrada e os testes): o
// vídeo se refaz pelo roteiro e pela cena.
//
// Como liga (no painel, em Comece aqui): a Máquina baixa o programa oficial do GitHub (o gh, conferindo a soma) pra
// .ferramentas/, a pessoa entra na conta dela pelo navegador com um código de 8 letras (nenhuma senha passa pela
// Máquina), e a Máquina cria o repositório privado e manda tudo. O login fica em .ferramentas/gh-config/, só nesta
// pasta. Repositório público é recusado: a Máquina é vendida, e o código dela não pode ficar aberto.
const fs = require('fs');
const path = require('path');
const os = require('os');
const https = require('https');
const crypto = require('crypto');
const { spawn, execFileSync } = require('child_process');

const RAIZ = path.join(__dirname, '..');
const FERR = path.join(RAIZ, '.ferramentas');
const EXE = process.platform === 'win32' ? '.exe' : '';
const GH = path.join(FERR, 'gh', `gh${EXE}`);
const GH_CONFIG = path.join(FERR, 'gh-config');
const GIT_PORTATIL = path.join(FERR, 'git', 'cmd', 'git.exe'); // o MinGit, no Windows sem Git
const MARCA = path.join(RAIZ, 'canal', 'backup.json');           // o repositório do canal: vem junto no npm run importar
const LINK_LOGIN = 'https://github.com/login/device';

class Erro extends Error { constructor(msg, detalhe = '') { super(msg); this.detalhe = detalhe; } }

// O que NÃO vai pro backup. A primeira linha marca que este .gitignore é o do backup (o que vem no zip é o de quem faz
// a Máquina, que deixa o canal de fora, e é trocado por este quando o backup liga)
const IGNORAR = `# Backup da Máquina Preguiça 3D no GitHub (npm run backup): o que NÃO vai pro backup. O resto vai.
# A chave da voz e outros segredos ficam só no seu computador
.env
.env.*
env.txt
# Os programas que a Máquina instala ou baixa sozinha (o npm run instalar põe de novo)
node_modules
.ferramentas/
# O que a Máquina está fazendo agora (o painel mostra ao vivo): muda o tempo todo e não serve de backup
.andamento.json*
# Grande demais pro GitHub: o vídeo se refaz pelo roteiro e pela cena (a voz já narrada fica só aqui)
*.mp4
*.mov
*.webm
*.mkv
videos/**/narracao/
videos/**/narracao.wav
videos/**/testes/
videos/**/versoes/
referencias/**/testes/
estudos/**/*.m4a
estudos/**/*.mp3
estudos/**/*.wav
estudos/*/quadros/
canal/testes-de-voz/
canal/importado-*/
canal/pedido-do-video.txt
# Lixo do sistema
.DS_Store
Thumbs.db
desktop.ini
*.baixando
`;

// ===================================================================== programas
const opcional = (f) => { try { return f(); } catch { return null; } };
function gitDoSistema() {
  if (process.platform === 'win32' && fs.existsSync(GIT_PORTATIL)) return GIT_PORTATIL;
  // No Mac, o git só existe com as ferramentas da Apple: sem elas, chamar o git abre uma janela pedindo pra instalar
  if (process.platform === 'darwin' && !opcional(() => execFileSync('xcode-select', ['-p'], { stdio: 'pipe' }))) return null;
  return opcional(() => (execFileSync('git', ['--version'], { stdio: 'pipe', timeout: 15000 }), 'git'));
}
const temGh = () => fs.existsSync(GH);
const envGh = () => ({ ...process.env, GH_CONFIG_DIR: GH_CONFIG, GH_NO_UPDATE_NOTIFIER: '1', GH_NO_EXTENSION_UPDATE_NOTIFIER: '1', NO_COLOR: '1' });

function pedirUrl(url, { destino, seguir = true, json = false, tempo = 30000 } = {}, saltos = 0) {
  return new Promise((ok, falha) => {
    const headers = { 'User-Agent': 'maquina-preguica-3d', ...(json ? { Accept: 'application/vnd.github+json' } : {}) };
    const req = https.get(url, { headers, timeout: tempo }, (res) => {
      if ([301, 302, 303, 307, 308].includes(res.statusCode) && res.headers.location) {
        res.resume();
        if (!seguir) return ok({ local: res.headers.location, status: res.statusCode });
        if (saltos > 6) return falha(new Error('O GitHub redirecionou demais.'));
        return pedirUrl(new URL(res.headers.location, url).href, { destino, json }, saltos + 1).then(ok, falha);
      }
      if (res.statusCode !== 200) { res.resume(); return ok({ status: res.statusCode }); }
      if (!destino) {
        const partes = [];
        res.on('data', (d) => partes.push(d));
        res.on('end', () => ok({ status: 200, texto: Buffer.concat(partes).toString('utf8') }));
        res.on('error', falha);
        return;
      }
      const hash = crypto.createHash('sha256');
      const saida = fs.createWriteStream(destino);
      res.on('data', (d) => hash.update(d));
      res.on('error', falha);
      saida.on('error', falha);
      saida.on('finish', () => ok({ status: 200, sha256: hash.digest('hex') }));
      res.pipe(saida);
    });
    req.on('timeout', () => req.destroy(new Error('A internet demorou demais pra responder.')));
    req.on('error', falha);
  });
}

function rodar(programa, args, { env, entrada, aoLer, tempo = 120000, cwd = RAIZ } = {}) {
  return new Promise((ok) => {
    let p;
    try { p = spawn(programa, args, { cwd, env: env || process.env, windowsHide: true }); } catch (e) { return ok({ codigo: -1, saida: '', erro: e.message }); }
    let saida = '', erro = '';
    const relogio = tempo ? setTimeout(() => { erro += '\n(o tempo acabou)'; p.kill(); }, tempo) : null;
    p.stdout.on('data', (d) => { const t = d.toString('utf8'); saida = (saida + t).slice(-50000); if (aoLer) aoLer(t, p); });
    p.stderr.on('data', (d) => { const t = d.toString('utf8'); erro = (erro + t).slice(-50000); if (aoLer) aoLer(t, p); });
    p.on('error', (e) => { erro += `\n${e.message}`; });
    p.on('close', (codigo) => { if (relogio) clearTimeout(relogio); ok({ codigo, saida, erro }); });
    if (entrada != null) { try { p.stdin.write(entrada); } catch { /* o programa não lê */ } }
  });
}

// Tira um .zip ou .tar.gz numa pasta, com o que cada sistema já tem
async function extrair(arquivo, pasta) {
  fs.mkdirSync(pasta, { recursive: true });
  if (/\.tar\.gz$/.test(arquivo)) return rodar('tar', ['-xzf', arquivo, '-C', pasta]);
  if (process.platform === 'darwin') return rodar('ditto', ['-x', '-k', arquivo, pasta]);
  if (process.platform === 'win32') {
    const q = (s) => `'${s.replace(/'/g, "''")}'`;
    return rodar('powershell', ['-NoProfile', '-Command', `Expand-Archive -LiteralPath ${q(arquivo)} -DestinationPath ${q(pasta)} -Force`], { tempo: 300000 });
  }
  return rodar('unzip', ['-q', '-o', arquivo, '-d', pasta]);
}
// Acha um arquivo pelo nome dentro de uma pasta (o zip do gh tem uma pasta com a versão no nome)
function acharDentro(pasta, nome) {
  for (const f of fs.readdirSync(pasta, { withFileTypes: true })) {
    const c = path.join(pasta, f.name);
    if (f.isDirectory()) { const r = acharDentro(c, nome); if (r) return r; } else if (f.name === nome) return c;
  }
  return null;
}

// O programa oficial do GitHub (o gh), baixado da página de versões dele, conferindo a soma de cada arquivo
async function garantirGh(aviso) {
  if (temGh()) return GH;
  const arch = process.arch === 'arm64' ? 'arm64' : process.arch === 'ia32' ? '386' : 'amd64';
  const sistema = process.platform === 'darwin' ? 'macOS' : process.platform === 'win32' ? 'windows' : 'linux';
  const ext = process.platform === 'linux' ? 'tar.gz' : 'zip';
  aviso('Baixando o programa oficial do GitHub (uns 15 MB)...');
  const { local } = await pedirUrl('https://github.com/cli/cli/releases/latest', { seguir: false });
  const tag = (String(local || '').match(/\/tag\/v?([^/?#]+)/) || [])[1];
  if (!tag) throw new Erro('Não achei o programa do GitHub na internet. Confira a internet e tente de novo.');
  const base = `https://github.com/cli/cli/releases/download/v${tag}/`;
  const nome = `gh_${tag}_${sistema}_${arch}.${ext}`;
  const somas = await pedirUrl(`${base}gh_${tag}_checksums.txt`);
  const soma = ((somas.texto || '').split('\n').map((l) => l.trim().split(/\s+/)).find((p) => p[1] === nome) || [])[0];
  if (!soma) throw new Erro(`O programa do GitHub não tem versão pra este computador (${process.platform}, ${process.arch}).`);
  fs.mkdirSync(FERR, { recursive: true });
  const tmp = path.join(FERR, `${nome}.baixando`), pasta = path.join(FERR, 'gh-baixado');
  const r = await pedirUrl(base + nome, { destino: tmp });
  if (r.sha256 !== soma) { fs.rmSync(tmp, { force: true }); throw new Erro('O programa do GitHub veio diferente do oficial (a internet pode ter cortado). Tente de novo.'); }
  const arq = tmp.replace(/\.baixando$/, '');
  fs.renameSync(tmp, arq);
  fs.rmSync(pasta, { recursive: true, force: true });
  await extrair(arq, pasta);
  const bin = acharDentro(pasta, `gh${EXE}`);
  if (!bin) throw new Erro('Não consegui abrir o programa do GitHub que baixei. Tente de novo.');
  fs.mkdirSync(path.dirname(GH), { recursive: true });
  fs.copyFileSync(bin, GH);
  fs.chmodSync(GH, 0o755);
  fs.rmSync(pasta, { recursive: true, force: true });
  fs.rmSync(arq, { force: true });
  return GH;
}

// O git: no Mac, as ferramentas da Apple (uma janela pede pra instalar); no Windows sem Git, o MinGit oficial, que não
// pede administrador; no Linux, o do sistema
async function garantirGit(aviso) {
  const g = gitDoSistema();
  if (g) return g;
  if (process.platform === 'darwin') {
    opcional(() => spawn('xcode-select', ['--install'], { stdio: 'ignore', detached: true }).unref());
    throw new Erro('O Mac precisa das ferramentas da Apple pra guardar o backup. Abriu uma janela: clique em Instalar e espere terminar (uns 5 a 10 minutos). Depois, clique em Ligar o backup de novo. A janela não apareceu? Peça pra IA: "instala as ferramentas da Apple pro backup".');
  }
  if (process.platform !== 'win32') throw new Erro('Falta o programa git neste computador. Peça pra IA: "instala o git pro backup".');
  aviso('Baixando o git, que guarda as versões dos arquivos (uns 40 MB)...');
  const rel = await pedirUrl('https://api.github.com/repos/git-for-windows/git/releases/latest', { json: true });
  const d = opcional(() => JSON.parse(rel.texto || '')) || {};
  const alvo = process.arch === 'arm64' ? /^MinGit-[\d.]+(\.windows\.\d+)?-arm64\.zip$/ : /^MinGit-[\d.]+(\.windows\.\d+)?-64-bit\.zip$/;
  const a = (d.assets || []).find((x) => alvo.test(x.name));
  if (!a) throw new Erro('Não achei o git pra este computador. Instale o Git do site git-scm.com e tente de novo.');
  const soma = (String(d.body || '').match(new RegExp(`${a.name.replace(/[.+]/g, '\\$&')}\\s*\\|\\s*([a-f0-9]{64})`, 'i')) || [])[1];
  if (!soma) throw new Erro('Não consegui conferir o git que viria do GitHub. Instale o Git do site git-scm.com e tente de novo.');
  fs.mkdirSync(FERR, { recursive: true });
  const tmp = path.join(FERR, `${a.name}.baixando`);
  const r = await pedirUrl(a.browser_download_url, { destino: tmp });
  if (r.sha256.toLowerCase() !== soma.toLowerCase()) { fs.rmSync(tmp, { force: true }); throw new Erro('O git veio diferente do oficial (a internet pode ter cortado). Tente de novo.'); }
  const arq = tmp.replace(/\.baixando$/, '');
  fs.renameSync(tmp, arq);
  await extrair(arq, path.join(FERR, 'git'));
  fs.rmSync(arq, { force: true });
  if (!fs.existsSync(GIT_PORTATIL)) throw new Erro('Não consegui abrir o git que baixei. Instale o Git do site git-scm.com e tente de novo.');
  return GIT_PORTATIL;
}

// ===================================================================== o repositório
const lerMarca = () => opcional(() => JSON.parse(fs.readFileSync(MARCA, 'utf8'))) || null;
function git(g, args, extra = {}) { return rodar(g, ['-c', 'core.quotepath=false', ...args], { tempo: 15 * 60 * 1000, ...extra }); }
// O login que a pessoa fez no painel. Na gravação do curso (06/11), o programa do GitHub falhou uma vez ao responder
// e o backup do fim do vídeo disse que "o login saiu", e na segunda tentativa funcionou: por isso tenta 3 vezes e, se o
// programa não responder, lê o login direto do arquivo dele (entrou com --insecure-storage: fica em
// .ferramentas/gh-config/hosts.yml, só nesta pasta). O login de verdade saiu só quando o GitHub recusa no envio
async function lerToken() {
  for (let i = 0; i < 3; i++) {
    const t = await rodar(GH, ['auth', 'token', '--hostname', 'github.com'], { env: envGh(), tempo: 30000 });
    const token = (t.saida || '').trim();
    if (t.codigo === 0 && /^\S+$/.test(token)) return token;
    await new Promise((ok) => setTimeout(ok, 1500));
  }
  const hosts = opcional(() => fs.readFileSync(path.join(GH_CONFIG, 'hosts.yml'), 'utf8')) || '';
  return ((hosts.match(/^github\.com:[\s\S]*?\boauth_token:\s*["']?([^\s"']+)/m) || [])[1]) || '';
}
// O login vai num cabeçalho, pelas variáveis do git (não aparece na lista de processos), e nada de janela pedindo senha
async function envComToken() {
  const token = await lerToken();
  if (!token) throw new Erro('O login no GitHub saiu. Clique em Ligar o backup de novo pra entrar.');
  return {
    ...process.env, GIT_TERMINAL_PROMPT: '0', GCM_INTERACTIVE: 'never',
    GIT_CONFIG_COUNT: '2', GIT_CONFIG_KEY_0: 'credential.helper', GIT_CONFIG_VALUE_0: '',
    GIT_CONFIG_KEY_1: 'http.https://github.com/.extraheader',
    GIT_CONFIG_VALUE_1: `AUTHORIZATION: basic ${Buffer.from(`x-access-token:${token}`).toString('base64')}`
  };
}
// Esta pasta já é um git que não é o do backup (a pasta de quem desenvolve a Máquina, por exemplo): não mexe
function gitDeOutroUso(g) {
  if (!fs.existsSync(path.join(RAIZ, '.git'))) return false;
  const marca = opcional(() => execFileSync(g || 'git', ['config', '--get', 'maquina.backup'], { cwd: RAIZ, stdio: 'pipe' }).toString().trim());
  return marca !== 'sim';
}
// Repositório público aparece pra qualquer um, sem login: é assim que a Máquina confere
// tempo: o conferir espera no máximo 8 s (com a internet lenta, o painel ficava 30 s em "Configuração ...")
async function ehPublico(repo, tempo = 30000) {
  try { const r = await pedirUrl(`https://api.github.com/repos/${repo}`, { json: true, tempo }); return r.status === 200; } catch { return null; }
}
const nomeDoRepo = () => {
  const canal = opcional(() => fs.readFileSync(path.join(RAIZ, 'canal', 'canal.md'), 'utf8')) || '';
  const nome = ((canal.match(/\*\*Nome do canal:\*\*\s*(.+)/) || [])[1] || '').replace(/\[.*?\]/g, '').trim();
  const slug = nome.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 40);
  return slug ? `maquina-${slug}` : 'minha-maquina-preguica-3d';
};

// ===================================================================== o estado (pro painel e pro npm run conferir)
function estado() {
  const g = gitDoSistema();
  const marca = lerMarca();
  const ligado = !!(g && marca && marca.repo && fs.existsSync(path.join(RAIZ, '.git')) && !gitDeOutroUso(g));
  const e = { ligado, repo: marca && marca.repo, link: marca && marca.repo ? `https://github.com/${marca.repo}` : null, git: !!g, gh: temGh(),
    pastaDeDesenvolvimento: !!(g && gitDeOutroUso(g) && !marca), fluxo: { ...fluxo } };
  if (!ligado) {
    // A pasta é nova (versão nova da Máquina, ou o backup baixado do GitHub): o canal lembra do repositório
    e.religar = !!(marca && marca.repo);
    return e;
  }
  const ultimo = opcional(() => execFileSync(g, ['log', '-1', '--format=%cI'], { cwd: RAIZ, stdio: 'pipe' }).toString().trim());
  const mudou = opcional(() => execFileSync(g, ['status', '--porcelain'], { cwd: RAIZ, stdio: 'pipe', maxBuffer: 20 * 1024 * 1024 }).toString().split('\n').filter(Boolean).length) || 0;
  const naoEnviado = opcional(() => execFileSync(g, ['rev-list', '--count', 'origin/main..HEAD'], { cwd: RAIZ, stdio: 'pipe' }).toString().trim());
  return { ...e, ultimo: ultimo || null, pendentes: mudou, naoEnviado: Number(naoEnviado) || 0 };
}

// ===================================================================== ligar (o painel acompanha pelo fluxo)
const fluxo = { etapa: 'parado', mensagem: '', codigo: '', link: LINK_LOGIN, erro: '', repo: '' };
let ligando = null;
function ligar() {
  if (ligando) return { ok: true, ...fluxo };
  Object.assign(fluxo, { etapa: 'preparando', mensagem: 'Preparando...', codigo: '', erro: '', repo: '' });
  const aviso = (m) => { fluxo.mensagem = m; };
  ligando = (async () => {
    const g = await garantirGit(aviso);
    if (gitDeOutroUso(g)) throw new Erro('Esta pasta já tem um controle de versões (git) que não é o do backup da Máquina, então não mexi nela. Use o backup numa pasta da Máquina que veio do zip.');
    await garantirGh(aviso);
    // 1. O login: o código de 8 letras vai pra tela do painel, e a pessoa autoriza no site do GitHub
    const jaEntrou = (await rodar(GH, ['auth', 'status', '--hostname', 'github.com'], { env: envGh(), tempo: 30000 })).codigo === 0;
    if (!jaEntrou) {
      Object.assign(fluxo, { etapa: 'esperando-codigo', mensagem: 'Pedindo o código pro GitHub...' });
      let mandouEnter = false;
      const r = await rodar(GH, ['auth', 'login', '--hostname', 'github.com', '--git-protocol', 'https', '--web', '--insecure-storage'], {
        env: envGh(), entrada: '', tempo: 15 * 60 * 1000,
        aoLer: (t, p) => {
          const m = t.match(/\b([A-Z0-9]{4}-[A-Z0-9]{4})\b/);
          if (m && !fluxo.codigo) Object.assign(fluxo, { etapa: 'codigo', codigo: m[1], mensagem: 'Agora é no site do GitHub.' });
          const u = t.match(/https:\/\/github\.com\/login\/device\S*/);
          if (u) fluxo.link = u[0];
          // se ele esperar o Enter pra abrir o navegador, o Enter vai (quem abre o site é a pessoa, pelo botão do painel)
          if (/press enter/i.test(t) && !mandouEnter) { mandouEnter = true; try { p.stdin.write('\n'); } catch { /* fechou */ } }
        }
      });
      if (r.codigo !== 0) {
        const txt = `${r.saida}\n${r.erro}`;
        if (/expired|tempo acabou/i.test(txt)) throw new Erro('O código venceu antes de ser usado (ele vale uns 15 minutos). Clique em Ligar o backup de novo.', txt.slice(-600));
        if (/denied|access_denied/i.test(txt)) throw new Erro('O GitHub disse que o acesso foi negado. Clique em Ligar o backup de novo e, no site, em Authorize.', txt.slice(-600));
        throw new Erro('Não consegui entrar no GitHub. Confira a internet e clique em Ligar o backup de novo.', txt.slice(-600));
      }
    }
    // Se o login deixou o git do computador inteiro usando o programa desta pasta, desfaz: numa pasta nova da Máquina
    // o caminho quebraria (o backup manda o login direto em cada envio e não precisa disso)
    for (const host of ['github.com', 'gist.github.com']) {
      await git(g, ['config', '--global', '--unset-all', `credential.https://${host}.helper`, '\\.ferramentas']);
    }
    // 2. Quem é a pessoa no GitHub (o nome dela vai em cada backup, com o e-mail escondido que o GitHub dá)
    Object.assign(fluxo, { etapa: 'criando', codigo: '', mensagem: 'Entrou! Criando o seu cofre privado no GitHub...' });
    const u = await rodar(GH, ['api', 'user', '--jq', '[.login, .id] | @tsv'], { env: envGh() });
    const [login, id] = (u.saida || '').trim().split('\t');
    if (!login) throw new Erro('Entrei no GitHub, mas não consegui ler o seu usuário. Clique em Ligar o backup de novo.', u.erro);
    // 3. O repositório: o que o canal lembra (pasta nova de quem já tinha backup), ou um novo, sempre privado
    const marca = lerMarca();
    let repo = marca && marca.repo && marca.repo.split('/')[0].toLowerCase() === login.toLowerCase() ? marca.repo : `${login}/${nomeDoRepo()}`;
    const ver = async (r) => rodar(GH, ['repo', 'view', r, '--json', 'visibility,isEmpty', '--jq', '[.visibility, .isEmpty] | @tsv'], { env: envGh() });
    let v = await ver(repo);
    if (v.codigo !== 0) {
      const c = await rodar(GH, ['repo', 'create', repo, '--private', '--description', 'Backup da minha Máquina Preguiça 3D (privado: só eu vejo)'], { env: envGh() });
      if (c.codigo !== 0) {
        if (!/already exists/i.test(c.erro)) throw new Erro('O GitHub não deixou criar o repositório do backup. Tente de novo daqui a pouco.', c.erro.slice(-600));
        repo = `${login}/${nomeDoRepo()}-${Date.now().toString(36).slice(-4)}`;
        const c2 = await rodar(GH, ['repo', 'create', repo, '--private', '--description', 'Backup da minha Máquina Preguiça 3D (privado: só eu vejo)'], { env: envGh() });
        if (c2.codigo !== 0) throw new Erro('O GitHub não deixou criar o repositório do backup. Tente de novo daqui a pouco.', c2.erro.slice(-600));
      }
      v = await ver(repo);
    }
    const [visibilidade] = (v.saida || '').trim().split('\t');
    if (visibilidade && visibilidade !== 'PRIVATE') {
      aviso('O repositório estava aberto pra todo mundo: deixando ele privado...');
      const p = await rodar(GH, ['repo', 'edit', repo, '--visibility', 'private', '--accept-visibility-change-consequences'], { env: envGh() });
      if (p.codigo !== 0) throw new Erro(`O repositório ${repo} está público, e a Máquina não guarda backup aberto pra todo mundo. No site do GitHub, abra o repositório, vá em Settings e, lá embaixo, em Change visibility → Private. Depois, clique em Ligar o backup de novo.`, p.erro.slice(-600));
    }
    fluxo.repo = repo;
    // 4. A pasta vira um git, com a lista do que não vai, e o primeiro backup sobe
    aviso('Guardando tudo no seu cofre (na primeira vez, pode levar uns minutos)...');
    const ign = path.join(RAIZ, '.gitignore');
    const atual = opcional(() => fs.readFileSync(ign, 'utf8')) || '';
    if (!atual.startsWith('# Backup da Máquina')) fs.writeFileSync(ign, IGNORAR);
    if (!fs.existsSync(path.join(RAIZ, '.git'))) {
      const i = await git(g, ['init', '-b', 'main']);
      if (i.codigo !== 0) { await git(g, ['init']); await git(g, ['symbolic-ref', 'HEAD', 'refs/heads/main']); }
    }
    for (const [k, val] of [['maquina.backup', 'sim'], ['user.name', login], ['user.email', `${id}+${login}@users.noreply.github.com`], ['core.autocrlf', 'false']]) await git(g, ['config', k, val]);
    const url = `https://github.com/${repo}.git`;
    if ((await git(g, ['remote', 'get-url', 'origin'])).codigo === 0) await git(g, ['remote', 'set-url', 'origin', url]);
    else await git(g, ['remote', 'add', 'origin', url]);
    fs.mkdirSync(path.dirname(MARCA), { recursive: true });
    fs.writeFileSync(MARCA, JSON.stringify({ repo, ligadoEm: new Date().toISOString(), aviso: 'O repositório do backup no GitHub (npm run backup). Não apague.' }, null, 2));
    // Já tinha backup (pasta nova da Máquina): o histórico continua de onde parou
    const env = await envComToken();
    const temMain = await git(g, ['ls-remote', '--heads', 'origin', 'main'], { env });
    const semCommit = (await git(g, ['rev-parse', '--verify', 'HEAD'])).codigo !== 0;
    if (temMain.codigo === 0 && /refs\/heads\/main/.test(temMain.saida) && semCommit) {
      const f = await git(g, ['fetch', 'origin', 'main'], { env });
      if (f.codigo === 0) await git(g, ['update-ref', 'refs/heads/main', 'FETCH_HEAD']);
    }
    const b = await fazerBackup({ g, env, primeiro: true, aviso });
    Object.assign(fluxo, { etapa: 'pronto', mensagem: b.mensagem, repo });
    return b;
  })().catch((e) => {
    Object.assign(fluxo, { etapa: 'erro', erro: e.message, detalhe: e.detalhe || '', mensagem: '' });
  }).finally(() => { ligando = null; });
  return { ok: true, ...fluxo };
}

// ===================================================================== fazer o backup
const quando = (d = new Date()) => d.toLocaleString('pt-BR', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' });
// A porcentagem do envio, das linhas que o git escreve ("Writing objects:  45% (100/220), 5.20 MiB | 1.10 MiB/s")
function lerEnvio(texto) {
  const ms = [...String(texto).matchAll(/(Counting|Compressing|Writing) objects:\s+(\d+)%(?:\s*\((\d+)\/(\d+)\))?(?:,\s*([\d.,]+\s*[KMG]i?B))?/g)];
  if (!ms.length) return null;
  const m = ms[ms.length - 1];
  const fase = { Counting: 'contando os arquivos', Compressing: 'compactando', Writing: 'mandando pro GitHub' }[m[1]];
  return { fase, pct: Number(m[2]), feito: m[3] ? Number(m[3]) : null, total: m[4] ? Number(m[4]) : null, tamanho: m[5] ? m[5].replace('iB', 'B') : '' };
}
// aviso(mensagem): o que está acontecendo, pro quadro do backup no painel (o primeiro backup leva uns minutos, e a pessoa
// achava que tinha travado). O andamento (motor/andamento.js) mostra o mesmo no alto de toda tela do painel
async function fazerBackup({ g, env, primeiro, aviso = () => {} } = {}) {
  const A = require('./andamento');
  A.comecar('backup', { detalhe: 'conferindo o que mudou' });
  try {
    const r = await guardar({ g, env, primeiro, aviso, A });
    A.terminar('backup', { estado: 'volta', mensagem: r.mensagem });
    return r;
  } catch (e) {
    A.terminar('backup', { estado: 'volta', mensagem: `O backup não foi feito: ${e.message}` });
    throw e;
  }
}
async function guardar({ g, env, primeiro, aviso, A }) {
  const diz = (m, feito = null, total = null) => { aviso(m); A.progresso({ detalhe: m.replace(/\.\.\.$/, ''), feito, total }); };
  g = g || gitDoSistema();
  const marca = lerMarca();
  if (!g || !marca || !fs.existsSync(path.join(RAIZ, '.git')) || gitDeOutroUso(g)) throw new Erro('O backup ainda não está ligado nesta pasta.');
  if (!temGh()) await garantirGh(() => {});
  env = env || await envComToken();
  // A lista do que não vai pro backup, sempre a desta versão (a de um backup ligado numa versão antiga ganha o que entrou)
  const ign = path.join(RAIZ, '.gitignore');
  const atual = opcional(() => fs.readFileSync(ign, 'utf8')) || '';
  if (atual.startsWith('# Backup da Máquina') && atual !== IGNORAR) fs.writeFileSync(ign, IGNORAR);
  // Nenhum arquivo maior que 45 MB (o GitHub recusa acima de 100 MB e reclama acima de 50): fica de fora, com aviso
  diz('Conferindo o que mudou desde o último backup...');
  const grandes = [];
  const lista = (await git(g, ['ls-files', '--others', '--modified', '--exclude-standard', '-z'], { tempo: 120000 })).saida.split('\0').filter(Boolean);
  const exclude = path.join(RAIZ, '.git', 'info', 'exclude');
  for (const f of lista) {
    const t = opcional(() => fs.statSync(path.join(RAIZ, f)).size) || 0;
    if (t > 45 * 1024 * 1024) { grandes.push(f); fs.mkdirSync(path.dirname(exclude), { recursive: true }); fs.appendFileSync(exclude, `\n/${f.replace(/([*?[\]!#])/g, '\\$1')}\n`); }
  }
  if (lista.length) diz(`Juntando ${lista.length} ${lista.length > 1 ? 'arquivos novos ou mudados' : 'arquivo novo ou mudado'}...`);
  await git(g, ['add', '-A']);
  const nada = (await git(g, ['diff', '--cached', '--quiet'])).codigo === 0;
  if (!nada) {
    const c = await git(g, ['commit', '-q', '-m', `${primeiro ? 'Primeiro backup' : 'Backup'} de ${quando()}`]);
    if (c.codigo !== 0) throw new Erro('Não consegui juntar os arquivos do backup.', c.erro.slice(-600));
  }
  // O envio, com a porcentagem (o --progress faz o git contar mesmo sem terminal)
  diz(primeiro ? 'Mandando tudo pro seu cofre no GitHub (na primeira vez leva uns minutos)...' : 'Mandando pro GitHub...');
  const enviar = () => git(g, ['push', '--progress', '-u', 'origin', 'main'], {
    env,
    aoLer: (t) => {
      const e = lerEnvio(t);
      if (e) diz(`${primeiro ? 'Mandando tudo pro seu cofre no GitHub' : 'Mandando pro GitHub'}: ${e.fase}, ${e.pct}%${e.tamanho ? ` (${e.tamanho})` : ''}...`, e.pct, 100);
    }
  });
  const p = await enviar();
  if (p.codigo !== 0) {
    const t = p.erro;
    if (/rejected|non-fast-forward|fetch first/i.test(t)) {
      // o GitHub tem um backup mais novo (de outra pasta): este vem por cima, sem apagar o histórico de lá
      diz('Juntando com o backup que já estava no GitHub...');
      const f = await git(g, ['fetch', 'origin', 'main'], { env });
      if (f.codigo === 0) {
        await git(g, ['merge', '-q', '-s', 'ours', '--allow-unrelated-histories', '-m', `Backup de ${quando()} (juntando com o que já estava no GitHub)`, 'FETCH_HEAD']);
        const p2 = await enviar();
        if (p2.codigo === 0) return { ok: true, mensagem: `Backup feito em ${quando()}.`, repo: marca.repo, grandes };
      }
    }
    if (/large|exceeds|GH001/i.test(t)) throw new Erro('O GitHub recusou um arquivo grande demais. Peça pra IA: "o backup deu erro de arquivo grande".', t.slice(-600));
    // Aqui, sim, o login saiu: o GitHub recusou a entrada (a pessoa tirou a permissão, ou o login venceu)
    if (/authentication failed|invalid username|could not read username|403|401|bad credentials|permission denied/i.test(t)) throw new Erro('O login no GitHub saiu. Clique em Ligar o backup de novo pra entrar.', t.slice(-600));
    throw new Erro('Não consegui mandar o backup pro GitHub. Confira a internet e tente de novo.', t.slice(-600));
  }
  return { ok: true, mensagem: nada ? 'Nada mudou desde o último backup: está tudo guardado.' : `Backup feito em ${quando()}.`, repo: marca.repo, grandes };
}

module.exports = { estado, ligar, fazerBackup, ehPublico, IGNORAR, Erro, lerToken, lerEnvio };

// ===================================================================== na linha de comando
if (require.main === module) {
  const args = process.argv.slice(2);
  (async () => {
    const e = estado();
    if (args.includes('--ligar') || (!e.ligado && !args.includes('--estado'))) {
      if (e.pastaDeDesenvolvimento) { console.log('BACKUP: esta pasta já tem um git que não é o do backup da Máquina, então o backup não liga aqui.'); return; }
      console.log(e.ligado ? `BACKUP: já está ligado (${e.link}).` : `BACKUP: ainda não está ligado.${e.religar ? ` O canal já tinha backup em ${e.link}: ligar de novo continua de onde parou.` : ''}`);
      if (!e.ligado) {
        try { require('child_process').execFileSync(process.execPath, [path.join(__dirname, 'painel.js'), '--backup'], { stdio: 'inherit' }); } catch { /* o painel explica */ }
        console.log('PRA IA: abri o painel no quadro "Backup no GitHub", em Comece aqui. Diga pra pessoa, com as suas palavras: "Abri o painel no backup. Clique em Ligar o backup, depois em Abrir o GitHub: entre na sua conta (ou crie uma, é grátis), cole o código que aparece no painel e clique em Authorize. O resto a Máquina faz sozinha. Quando aparecer Backup ligado, me avise." Quando ela avisar, rode npm run backup -- --estado. Leia comandos/backup.md se travar.');
      }
      return;
    }
    if (args.includes('--estado')) {
      if (!e.ligado) { console.log(`BACKUP: não está ligado.${e.religar ? ` (o canal lembra do repositório ${e.repo}: npm run backup -- --ligar continua de onde parou)` : ''}\nPRA IA: npm run backup -- --ligar abre o painel pra pessoa ligar.`); return; }
      console.log(`BACKUP: ligado, no repositório privado ${e.link}.\nÚltimo backup: ${e.ultimo ? quando(new Date(e.ultimo)) : 'nenhum ainda'}. Arquivos mudados desde então: ${e.pendentes}.`);
      return;
    }
    const r = await fazerBackup();
    console.log(`BACKUP FEITO: ${r.mensagem} Fica no repositório privado https://github.com/${r.repo}.`);
    if (r.grandes.length) console.log(`Ficaram de fora, por serem grandes demais pro GitHub (mais de 45 MB): ${r.grandes.join(', ')}.`);
    console.log('PRA IA: conte pra pessoa em uma frase que o backup foi feito (o canal, os roteiros, as cenas e as capas; os vídeos .mp4 ficam só no computador).');
  })().catch((err) => {
    console.log(`O BACKUP NÃO FOI FEITO: ${err.message}`);
    if (err.detalhe) console.log(`Detalhe: ${String(err.detalhe).trim().split('\n').slice(-4).join(' | ')}`);
    console.log('PRA IA: explique pra pessoa em palavras simples e siga a seção "Se travar" de comandos/backup.md.');
    process.exitCode = 1;
  });
}
