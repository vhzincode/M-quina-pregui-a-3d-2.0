// A cola de cada etapa do vídeo: npm run guia -- <etapa> [tema] [página]
//
//   npm run guia -- tema                    escolher o tema (o canal, a pauta, o teste do tema, o caderno dos virais)
//   npm run guia -- roteiro <tema>          escrever o roteiro (a fórmula inteira, as dicas do gancho, do roteiro e do fim)
//   npm run guia -- ficha <tema>            a ficha de cena (as regras de ouro, a câmera, o ritmo, o cardápio de cenas)
//   npm run guia -- cena <tema>             o roteiro.json, o cena.js e a capa (o passo a passo, o kit, os erros comuns)
//   npm run guia -- capa <tema>             só a capa e o título
//   npm run guia -- postar <tema>           o texto de postar, a hora e os cuidados
//   npm run guia -- <etapa> <tema> 2        a página 2 (cada etapa sai em páginas, pra caber no que a IA lê de uma vez)
//   npm run guia -- <etapa> --tudo          todas as páginas de uma vez
//
// Por que existe: a IA lê o que um comando mostra, mesmo quando esquece de abrir um arquivo, lê só o começo dele ou não
// junta o método da Máquina com o que o canal mudou. Aqui sai, de cada guia, só a parte que vale na etapa, com o que o
// canal mudou no painel (canal/metodo.md) já no lugar da parte da Máquina e o que a pessoa ensinou
// (canal/aprendizados.md) junto. Os textos vêm dos próprios guias, na hora: mudou o guia, muda a cola.
const fs = require('fs');
const path = require('path');

const RAIZ = path.join(__dirname, '..');
const lerArq = (...p) => { try { return fs.readFileSync(path.join(RAIZ, ...p), 'utf8').replace(/^﻿/, '').replace(/\r/g, ''); } catch { return null; } };
const tirarComentarios = (t) => String(t || '').replace(/<!--[\s\S]*?-->/g, '');
const semAcento = (t) => String(t).normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().replace(/[`*]/g, '').trim();

// As seções de um markdown no nível pedido (2 = "## ", 3 = "### "): [{ titulo, texto }], o texto com o título e tudo
// até o próximo título do mesmo nível ou mais alto
function secoesDe(txt, nivel = 2) {
  const r = [];
  let atual = null;
  for (const l of String(txt || '').split('\n')) {
    const m = l.match(/^(#{1,6})\s+(.+?)\s*$/);
    if (m && m[1].length <= nivel) {
      if (atual) r.push(atual);
      atual = m[1].length === nivel ? { titulo: m[2], linhas: [l] } : null;
      continue;
    }
    if (atual) atual.linhas.push(l);
  }
  if (atual) r.push(atual);
  return r.map((s) => ({ titulo: s.titulo, texto: s.linhas.join('\n').trim() }));
}
// A seção cujo título começa com o pedido (sem ligar pra acento, maiúscula, crase e negrito)
const acharSecao = (lista, pedido) => lista.find((s) => semAcento(s.titulo).startsWith(semAcento(pedido)));

// O que a pessoa mudou no método pelo painel: { 'Título': texto } (canal/metodo.md, uma seção "## Título" por tópico)
function metodoDoCanal() {
  const r = {};
  for (const s of secoesDe(tirarComentarios(lerArq('canal', 'metodo.md')), 2)) {
    const corpo = s.texto.split('\n').slice(1).filter((l) => !l.startsWith('>')).join('\n').trim();
    if (corpo) r[s.titulo] = corpo;
  }
  return r;
}

// Cada pedaço da cola: { de: 'arquivo', titulo, texto, doCanal }
function pedacos(arquivo, titulos, { nivel = 2, metodo = false } = {}) {
  const txt = lerArq(arquivo);
  if (txt == null) return [];
  const todas = secoesDe(tirarComentarios(txt), nivel);
  const meu = metodo ? metodoDoCanal() : {};
  const r = [];
  for (const t of titulos) {
    const s = acharSecao(todas, t);
    if (!s) continue;
    if (meu[s.titulo] != null) {
      r.push({ de: 'canal/metodo.md', titulo: `${s.titulo} (o jeito do SEU canal, no lugar do da Máquina)`, texto: `${'#'.repeat(nivel)} ${s.titulo}\n\n${meu[s.titulo]}`, doCanal: true });
    } else r.push({ de: arquivo, titulo: s.titulo, texto: s.texto });
  }
  return r;
}

// Os campos do canal que a pessoa deixou em branco ("[Ex: ...]", às vezes em duas linhas e com colchete dentro) viram o
// padrão da Máquina, o mesmo que o painel escreve no campo vazio: a IA tomaria o exemplo do modelo por regra
const POR_SECAO = { 'jeito de falar': 'jeito', 'estilo do video': 'estiloVideo', 'mecanismo unico': 'mecanismo', 'estilo da capa': 'capa', hashtags: 'hashtags' };
const POR_ROTULO = { evitar: 'evitar', fechamento: 'fechamento', chamada: 'chamada' };
function trocarEmBranco(txt) {
  let pad = {};
  try { pad = require('./canal').padroes({}); } catch { /* sem o padrão, o campo em branco só sai */ }
  let out = '';
  for (let i = 0; i < txt.length; i++) {
    if (txt[i] === '[') {
      let d = 0, j = i;
      for (; j < txt.length; j++) { if (txt[j] === '[') d++; else if (txt[j] === ']' && --d === 0) break; }
      if (j < txt.length && /\b(ex|ej|descreva)\b\s*[:.]/i.test(txt.slice(i + 1, j))) {
        const linha = out.slice(out.lastIndexOf('\n') + 1);
        const rotulo = (linha.match(/\*\*([^*]+?):?\*\*:?\s*$/) || [])[1];
        const secao = ((out.match(/^##\s+(.+)$/gm) || []).pop() || '').replace(/^##\s+/, '');
        const chave = rotulo ? POR_ROTULO[Object.keys(POR_ROTULO).find((k) => semAcento(rotulo).startsWith(k))]
          : POR_SECAO[semAcento(secao).replace(/\s*\(.*$/, '')];
        if (chave && pad[chave]) out += `${pad[chave]} (em branco no canal: vale o padrão da Máquina)`;
        i = j;
        continue;
      }
    }
    out += txt[i];
  }
  return out;
}
// Um arquivo do canal inteiro, sem os comentários de instrução, com o padrão da Máquina no que está em branco e sem
// rótulo ou título que ficou vazio (só se sobrar algo escrito)
function doCanal(arquivo, titulo) {
  const linhas = trocarEmBranco(tirarComentarios(lerArq('canal', arquivo))).split('\n')
    .filter((l) => !l.startsWith('>') && !/^\*\*[^*]+\*\*\s*$/.test(l.trim()) && !/^\|\s*\[tema\]/.test(l));
  const proxima = (i) => linhas.slice(i + 1).find((x) => x.trim()) || '';
  const limpas = linhas.filter((l, i) => !/^#{2,3}\s/.test(l) || (proxima(i) && !/^#{1,3}\s/.test(proxima(i))));
  const txt = limpas.join('\n').replace(/\n{3,}/g, '\n\n').trim();
  if (!txt || txt.split('\n').filter((l) => l.trim() && !/^#/.test(l)).length === 0) return [];
  return [{ de: `canal/${arquivo}`, titulo, texto: txt, doCanal: true }];
}

// As seções de canal/aprendizados.md que já têm alguma coisa (o gosto da pessoa vale mais que o padrão do guia)
function aprendizados(titulos) {
  const todas = secoesDe(tirarComentarios(lerArq('canal', 'aprendizados.md')), 2);
  const r = [];
  for (const t of titulos) {
    const s = acharSecao(todas, t);
    if (!s) continue;
    const corpo = s.texto.split('\n').slice(1).filter((l) => l.trim() && !l.startsWith('>') && !/^\s*-\s*\(nada ainda\)\s*$/i.test(l)).join('\n').trim();
    if (corpo) r.push({ de: 'canal/aprendizados.md', titulo: `${s.titulo} (o que a pessoa já te ensinou: vale mais que o guia)`, texto: `## ${s.titulo}\n\n${corpo}`, doCanal: true });
  }
  return r;
}

// O caderno dos virais que a pessoa estudou: o que se repete e o teste da vez
function cadernoDosVirais() {
  try {
    const resumo = require('./estudar').resumoCaderno();
    return resumo ? [{ de: 'estudos/virais-estudados.md', titulo: 'O caderno dos virais que a pessoa estudou', texto: resumo, doCanal: true }] : [];
  } catch { return []; }
}

// O cenário do vídeo: o que está escrito na ficha (**Cenário:** `nome`) ou o padrão do canal
function cenarioDoVideo(tema) {
  const ficha = tema && lerArq('videos', tema, 'roteiro.md');
  const daFicha = ficha && (ficha.match(/\*\*Cen[áa]rio:\*\*\s*`([a-z_]+)`/) || [])[1];
  const doCanal = (tirarComentarios(lerArq('canal', 'identidade.md')).match(/"cenario"\s*:\s*"([a-z_]+)"/) || [])[1];
  const nomes = [...new Set([daFicha, doCanal].filter(Boolean))];
  return nomes.flatMap((n) => pedacos('referencias/cenarios.md', [n], { nivel: 3 }).map((p) => ({ ...p, titulo: `O cenário ${n}${n === daFicha ? ' (o escolhido na ficha)' : ' (o padrão do canal)'}` })));
}

// O cenário com os lugares (e as posições), os objetos que dá pra filmar e o que tem nele (motor/ver-kit.js): a IA não
// precisa abrir o motor/cenarios.js pra saber onde fica a vaca ou o fogão
function cenarioComPosicoes(tema) {
  const nomes = cenarioDoVideo(tema).map((p) => (p.titulo.match(/O cenário (\w+)/) || [])[1]).filter(Boolean);
  const r = [];
  for (const n of [...new Set(nomes)]) {
    let f = null;
    try { f = require('./ver-kit').fichaCenario(n); } catch { /* sem a ficha, sai o do catálogo */ }
    if (f) r.push({ de: 'motor/cenarios.js', titulo: `O cenário ${n}: os lugares com a posição e os objetos`, texto: f });
  }
  return r.length ? r : cenarioDoVideo(tema);
}

// A ficha inteira de cada peça (o que faz, as opções, o que devolve), tirada na hora do motor (npm run kit -- <nome>)
function fichasDoKit(nomes, titulo, de = 'motor/kit.js') {
  let K;
  try { K = require('./ver-kit'); } catch { return []; }
  // cada nome pode vir com o arquivo ({ nome, arq }): a peça do canal que tem o mesmo nome de uma do motor
  const fichas = nomes.map((n) => (typeof n === 'string' ? K.ficha(n, { curta: true }) : K.ficha(n.nome, { curta: true, arq: n.arq }))).filter(Boolean);
  return fichas.length ? [{ de, titulo, texto: fichas.join('\n\n') }] : [];
}
// As peças próprias do canal (canal/pecas/): o personagem, o bicho ou o objeto que a IA já fez em outro vídeo
function pecasDoCanal() {
  let K;
  try { K = require('./ver-kit'); } catch { return []; }
  const defs = K.todas().filter((d) => d.arq.startsWith('canal/pecas/') && d.ind <= 4 && /=\s*(function|\()/.test(d.cabeca));
  const vistos = new Set();
  const lista = defs.filter((d) => !vistos.has(d.nome) && vistos.add(d.nome)).map((d) => ({ nome: d.nome, arq: d.arq }));
  return fichasDoKit(lista, 'As peças próprias deste canal (canal/pecas/): use antes de fazer outra igual', 'canal/pecas/');
}
// As peças que a ficha de cena usa (a coluna "Feito com" da tabela "Objetos do vídeo": K.balde, K.vento...)
const SEMPRE = ['filmar', 'enquadrar', 'boneco'];
function pecasDaTabela(tema) {
  const md = tema && lerArq('videos', tema, 'roteiro.md');
  if (!md) return [];
  const i = md.search(/^###\s+Objetos do v/m);
  if (i < 0) return [];
  const resto = md.slice(i);
  const fim = resto.slice(4).search(/^###\s/m);
  const tabela = fim < 0 ? resto : resto.slice(0, fim + 4);
  const nomes = [...new Set([...tabela.matchAll(/\bK\.([A-Za-z_]\w*)/g)].map((m) => m[1]))].filter((n) => !SEMPRE.includes(n) && n !== 'cenario');
  if (nomes.includes('pecas') && !nomes.includes('peca')) nomes.splice(nomes.indexOf('pecas') + 1, 0, 'peca');
  let K;
  try { K = require('./ver-kit'); } catch { return []; }
  // as peças do canal já saem inteiras em "As peças próprias deste canal"
  const achados = nomes.filter((n) => { const d = K.acharDef(n); return d && !d.arq.startsWith('canal/'); }).slice(0, 16);
  return fichasDoKit(achados, 'As peças da sua ficha (as da tabela "Objetos do vídeo")');
}

const DICAS = 'viralizar/dicas.md', FORMULA = 'metodo/formula-roteiro.md', RITMO = 'metodo/ritmo-e-visual.md';
const GUIA = 'referencias/COMO-FAZER-O-VIDEO.md', CARDAPIO = 'referencias/cardapio-de-cenas.md', KIT = 'referencias/kit-indice.md';

// O que entra em cada etapa, na ordem em que a IA precisa, e a linha PRA IA do fim (o próximo passo)
const ETAPAS = {
  tema: {
    nome: 'escolher o tema',
    partes: () => [
      ...doCanal('canal.md', 'O seu canal (do que ele fala, pra quem, o jeito)'),
      ...doCanal('pauta.md', 'A pauta do canal (os temas que a pessoa já quer fazer)'),
      ...aprendizados(['O que dá resultado', 'Roteiro e narração', 'Jeito de trabalhar']),
      ...cadernoDosVirais(),
      ...pedacos(FORMULA, ['O que faz um vídeo viralizar', 'Como escolher o tema'], { metodo: true }),
      ...pedacos(DICAS, ['1.'])
    ],
    fim: (t) => `Sugira 3 temas pra pessoa (da pauta ou que passem em pelo menos 2 das 3 perguntas do tema), cada um com a pergunta do gancho, e diga qual você escolheria e por quê. Com o tema escolhido, crie a pasta videos/<tema-sem-acento-com-hifen>/ e rode: npm run guia -- roteiro ${t || '<tema>'}`
  },
  roteiro: {
    nome: 'escrever o roteiro',
    partes: () => [
      ...doCanal('canal.md', 'O seu canal (o jeito de falar, o que evitar, a marca registrada, o fechamento e a chamada)'),
      ...aprendizados(['Jeito de trabalhar', 'Roteiro e narração', 'O que dá resultado']),
      ...cadernoDosVirais(),
      ...pedacos(FORMULA, ['Por que prende', 'O esqueleto', 'As regras que fazem funcionar', 'O personagem que sofre',
        'Os temperos', 'Linguagem', 'Tamanho', 'Gancho, título e capa', 'O pedido do fim', 'Checklist'], { metodo: true }),
      ...pedacos(DICAS, ['2.', '3.', '4.', '7.'])
    ],
    fim: (t) => `Escreva o roteiro em videos/${t || '<tema>'}/roteiro.md: a seção "## Roteiro" com uma frase por linha numerada (1. a pergunta do gancho, 2., 3., ...), o total de palavras embaixo e a seção "## Ciência conferida", no formato de referencias/modelo-construcao/roteiro.md. Passe no Checklist (acima) frase por frase. Depois rode: npm run guia -- ficha ${t || '<tema>'}`
  },
  ficha: {
    nome: 'a ficha de cena',
    partes: (t) => [
      ...doCanal('identidade.md', 'A identidade do canal (o personagem, as cores, o cenário e a hora)'),
      ...aprendizados(['Visual', 'Cenas que funcionaram']),
      ...pedacos(GUIA, ['As regras de ouro', 'Passo 1']),
      ...pedacos(RITMO, ['Ritmo', 'Na tela', 'Som'], { metodo: true }),
      ...pedacos(DICAS, ['5.']),
      ...pedacos('referencias/cenarios.md', ['Qual cenário pra cada tema', 'Os lugares']),
      ...cenarioComPosicoes(t),
      ...pedacos(CARDAPIO, ['1.', '2.', '3.', '4.', '5.', '6.', '7.', '8.', '9.', '10.', '11.', '12.', '13.'])
    ],
    fim: (t) => `Escreva a "## Ficha de cena" em videos/${t || '<tema>'}/roteiro.md, no formato desta cola (a tabela e o bloco de exemplo do Passo 1; não precisa abrir o modelo inteiro): o **Cenário:** e a hora, a tabela "### Objetos do vídeo", o "### Teste dos substantivos" e, em "### Cena por cena", um bloco "#### <número> · plano \`<nome>\` · ~<segundos> s" por frase, com a frase entre aspas e as 10 linhas (NA TELA, MOSTRA, CENÁRIO, ENTRA AGORA, OBJETOS SE MEXENDO, PERSONAGEM, INTERAÇÃO, CÂMERA, EFEITOS VISUAIS e SONS), sem pular nenhuma frase. Depois rode: npm run roteiro -- ${t || '<tema>'} e arrume até dar RESULTADO: APROVADO. Só então mostre o roteiro pra pessoa (passo 1 de comandos/novo-video.md)`
  },
  cena: {
    nome: 'o roteiro.json, o cena.js e a capa',
    partes: (t) => [
      ...aprendizados(['Lições técnicas', 'Visual', 'Capa e texto de postar']),
      ...pecasDoCanal(),
      ...pedacos(GUIA, ['Passo 2', 'Passo 3', 'Passo 4', 'Erros comuns', 'Checklist antes do vídeo completo']),
      ...pedacos('referencias/cenarios.md', ['Como usar']),
      ...cenarioComPosicoes(t),
      ...fichasDoKit(SEMPRE, 'A câmera e o personagem, que entram em toda frase (a ficha inteira)'),
      ...pecasDaTabela(t),
      ...pedacos(KIT, ['Direção', 'Efeitos de cena', 'Texto e indicadores', 'Sons', 'Videogame']),
      ...pedacos(FORMULA, ['Gancho, título e capa'], { metodo: true }),
      ...pedacos(RITMO, ['Capa e primeiro segundo'], { metodo: true }),
      ...pedacos(DICAS, ['6.'])
    ],
    fim: (t) => `Copie o roteiro.json e o cena.js do modelo pra videos/${t || '<tema>'}/ e troque tudo o que está marcado com TROQUE (passo 2 de comandos/novo-video.md): uma função em P por bloco da ficha, com as linhas do bloco como comentário e o código embaixo, e o "mostra" de cada frase igual à linha MOSTRA. As opções de outra peça: npm run kit -- <nome> (ou npm run kit -- buscar <palavra>); não abra o código do motor/, que gasta muito e não precisa. Depois rode: node motor/render.js videos/${t || '<tema>'} --voz-teste --revisar e arrume até dar RESULTADO: APROVADO, abrindo a folha (testes/folha.jpg)`
  },
  capa: {
    nome: 'a capa e o título',
    partes: () => [
      ...aprendizados(['Capa e texto de postar']),
      ...pedacos(FORMULA, ['Gancho, título e capa'], { metodo: true }),
      ...pedacos(RITMO, ['Capa e primeiro segundo'], { metodo: true }),
      ...pedacos(DICAS, ['6.'])
    ],
    fim: (t) => `Rode node motor/render.js videos/${t || '<tema>'} --voz-teste --capa, abra a capa.png e compare com videos/exemplo/capa.png: a pergunta grande em cima, o objeto no meio, o personagem com a cara exagerada e o detalhe mais estranho circulado`
  },
  postar: {
    nome: 'o texto de postar, a hora e os cuidados',
    partes: () => [
      ...aprendizados(['Capa e texto de postar', 'O que dá resultado']),
      ...pedacos(DICAS, ['8.', '9.', '10.']),
      ...arquivoInteiro('viralizar/horarios.md', 'Os horários de postar'),
      ...arquivoInteiro('viralizar/cuidados.md', 'Os cuidados (música, aviso de IA, o que derruba o vídeo)')
    ],
    fim: (t) => `Escreva o videos/${t || '<tema>'}/publicacao.md seguindo comandos/publicar.md. Pergunta da pessoa sobre uma rede: o arquivo dela em viralizar/ (youtube.md, instagram.md ou tiktok.md; o viralizar/LEIA-PRIMEIRO.md diz qual)`
  }
};
function arquivoInteiro(arquivo, titulo) {
  const txt = tirarComentarios(lerArq(arquivo)).replace(/\n{3,}/g, '\n\n').trim();
  return txt ? [{ de: arquivo, titulo, texto: txt }] : [];
}

// Páginas de até ~7.500 letras e 150 linhas: é o que as IAs leem inteiro do que um comando mostra. O Claude Code (que
// avisa com CLAUDECODE=1) mostra até 30 mil letras de uma saída: lá a página é de 14 mil, e a IA roda menos comandos
// (cada comando a mais relê a conversa inteira, e é isso que gasta tokens). Não mais que isso: a IA costuma pedir duas
// páginas num comando só, e acima de 30 mil a saída vai pra um arquivo à parte, que ela ainda tem que abrir (teste de 06/11)
const GRANDE = !!process.env.CLAUDECODE;
const MAX_LETRAS = GRANDE ? 14000 : 7500, MAX_LINHAS = GRANDE ? 300 : 150;
function paginar(blocos) {
  const paginas = [];
  let atual = [], letras = 0, linhas = 0;
  const fechar = () => { if (atual.length) paginas.push(atual.join('\n\n')); atual = []; letras = 0; linhas = 0; };
  for (const b of blocos) {
    // um bloco grande demais (uma tabela longa) é quebrado por linhas
    const partes = [];
    if (b.length > MAX_LETRAS || b.split('\n').length > MAX_LINHAS) {
      let p = [];
      for (const l of b.split('\n')) {
        if (p.length && (p.join('\n').length + l.length > MAX_LETRAS * 0.9 || p.length >= MAX_LINHAS * 0.9)) { partes.push(p.join('\n')); p = []; }
        p.push(l);
      }
      if (p.length) partes.push(p.join('\n'));
    } else partes.push(b);
    for (const p of partes) {
      const n = p.split('\n').length;
      if (atual.length && (letras + p.length > MAX_LETRAS || linhas + n > MAX_LINHAS)) fechar();
      atual.push(p); letras += p.length + 2; linhas += n + 1;
    }
  }
  fechar();
  return paginas;
}

function montar(etapa, tema) {
  const e = ETAPAS[etapa];
  const lista = e.partes(tema);
  const blocos = [];
  for (const p of lista) {
    blocos.push(`━━━━ ${p.doCanal ? '★ ' : ''}${p.titulo} · de ${p.de} ━━━━`);
    // os parágrafos de cada pedaço, pra página quebrar entre eles
    for (const par of p.texto.split(/\n{2,}/)) if (par.trim()) blocos.push(par.trim());
  }
  return { e, lista, paginas: paginar(blocos) };
}

function mostrar(etapa, tema, pagina, tudo) {
  const { e, lista, paginas } = montar(etapa, tema);
  const total = paginas.length;
  const cmd = (n) => `npm run guia -- ${etapa}${tema ? ` ${tema}` : ''} ${n}`;
  const fontes = [...new Set(lista.map((p) => p.de))];
  const ver = tudo ? paginas.map((_, i) => i + 1) : [Math.min(Math.max(1, pagina), total)];
  for (const n of ver) {
    const l = [`COLA DA ETAPA "${etapa.toUpperCase()}" (${e.nome}) · página ${n} de ${total}`];
    if (n === 1) {
      l.push(`Tudo o que a Máquina sabe pra esta etapa, tirado na hora de: ${fontes.join(', ')}.`,
        'O que tem ★ é do canal desta pessoa (o que ela mudou no painel e o que ela te ensinou): vale mais que o resto.',
        'Siga esta cola em vez da memória: é ela que a revisão cobra.');
      // A notícia da etapa (regra número 6 do AGENTS.md): a pessoa não vê a IA pensando e acha que travou
      const A = require('./andamento');
      const et = A.ETAPAS[etapa];
      if (et) l.push(`DÊ NOTÍCIA: antes de continuar, escreva pra pessoa uma frase curta dizendo que agora é "${et.nome.toLowerCase()}" e que costuma levar ${A.faixa(et.min, et.max)} (o painel mostra a etapa ao vivo, no alto da tela). Nesta etapa, a cada passo que levar mais de 2 minutos, mais uma linha dizendo o que você está fazendo.`);
    }
    l.push('', paginas[n - 1], '');
    if (n < total) {
      if (!tudo) l.push(`PRA IA: esta é a página ${n} de ${total}. Leia inteira e rode agora a próxima, sem pular e sem cortar com head ou tail (cada página tem regra que a revisão cobra): ${cmd(n + 1)}`);
    } else {
      l.push(`FIM DA COLA DA ETAPA "${etapa.toUpperCase()}" (${total} ${total > 1 ? 'páginas' : 'página'}).`, `PRA IA: ${e.fim(tema)}`);
    }
    console.log(l.join('\n'));
  }
}

// ---------- O jeito por chat: o Prompt B já preenchido ----------
// Quem usa uma IA de chat (que não roda comando) cola o Prompt B, parte 1, de comandos/modo-chat.md e mais 3 arquivos à
// mão. Aqui sai tudo junto: o Prompt B com o tema, o canal (com o padrão da Máquina no que está em branco), o que a IA
// aprendeu e o método do canal, e as regras completas do roteiro, da câmera e da capa antes do "Antes de responder", que
// fica no fim (a IA fraca segue melhor o que vem por último). Vai pra área de transferência e pra canal/pedido-do-video.txt
function pedidoDoChat(tema) {
  const chat = lerArq('comandos', 'modo-chat.md') || '';
  const L = chat.split('\n');
  const i = L.findIndex((l) => /^##\s+Prompt B.*parte 1/i.test(l));
  const a = L.findIndex((l, k) => k > i && /^```/.test(l));
  const b = L.findIndex((l, k) => k > a && /^```/.test(l));
  if (i < 0 || a < 0 || b < 0) return null;
  let p = L.slice(a + 1, b).join('\n');
  const texto = (lista) => lista.map((x) => x.texto).join('\n\n').trim();
  const canal = texto(doCanal('canal.md', ''));
  const aprendeu = texto(aprendizados(['Jeito de trabalhar', 'Roteiro e narração', 'Visual', 'Voz e som', 'Capa e texto de postar', 'Cenas que funcionaram', 'O que dá resultado']));
  const meu = Object.entries(metodoDoCanal()).map(([t, v]) => `## ${t}\n\n${v}`).join('\n\n');
  const linha = (re, valor) => { p = valor ? p.replace(re, (m, rotulo) => `${rotulo}\n${valor}\n`) : p.replace(new RegExp(`${re.source}\\n?`), ''); };
  if (tema) p = p.replace(/^(TEMA:).*$/m, `$1 ${tema.replace(/[-_]+/g, ' ')}`);
  linha(/^(MEU CANAL:).*$/m, canal);
  linha(/^(O QUE EU PREFIRO:).*$/m, aprendeu);
  linha(/^(O MEU MÉTODO:).*$/m, meu);
  if (!meu) p = p.replace(/^\(Se O MEU MÉTODO.*\)\n?/m, '');
  const regras = [
    ...pedacos(FORMULA, ['Por que prende', 'O esqueleto', 'As regras que fazem funcionar', 'O personagem que sofre', 'Os temperos',
      'Linguagem', 'Tamanho', 'Gancho, título e capa', 'O pedido do fim', 'Checklist'], { metodo: true }),
    ...pedacos(RITMO, ['Ritmo', 'Na tela', 'Som', 'Capa e primeiro segundo'], { metodo: true }),
    ...pedacos(DICAS, ['2.', '3.', '4.', '5.', '6.', '7.'])
  ].map((x) => x.texto.replace(/`/g, '')).join('\n\n');
  const bloco = `AS REGRAS COMPLETAS DO MÉTODO (leia tudo antes de escrever; se algo aqui disser diferente de MEU CANAL, O QUE EU PREFIRO ou O MEU MÉTODO, vale o meu):\n\n${regras}\n\n`;
  const k = p.search(/^Antes de responder/m);
  return k >= 0 ? p.slice(0, k) + bloco + p.slice(k) : `${p}\n\n${bloco}`;
}
function copiarTexto(t) {
  const { execSync } = require('child_process');
  try {
    if (process.platform === 'darwin') { execSync('pbcopy', { input: t, env: { ...process.env, LANG: 'en_US.UTF-8' } }); return true; }
    if (process.platform === 'win32') {
      const arq = path.join(require('os').tmpdir(), `pedido-${process.pid}.txt`);
      fs.writeFileSync(arq, t, 'utf8');
      execSync(`powershell -NoProfile -Command "Set-Clipboard -Value ([IO.File]::ReadAllText('${arq.replace(/'/g, "''")}', [Text.Encoding]::UTF8))"`);
      fs.rmSync(arq, { force: true });
      return true;
    }
    try { execSync('wl-copy', { input: t }); } catch { execSync('xclip -selection clipboard', { input: t }); }
    return true;
  } catch { return false; }
}

// ---------- O jeito por chat, parte 2: numa conversa nova, com o roteiro dentro ----------
// Na mesma conversa da parte 1, a IA de chat relê o pedido enorme, o roteiro e as fichas a cada resposta (gasta o limite
// grátis mais rápido e erra mais o JSON, porque o formato fica lá em cima). Aqui: a pessoa copia a resposta da parte 1,
// a Máquina confere as fichas e monta a parte 2 já com o roteiro e as fichas dentro, pra colar numa conversa nova
function areaDeTransferencia() {
  const { execSync, execFileSync } = require('child_process');
  try {
    if (process.platform === 'darwin') return execSync('pbpaste', { encoding: 'utf8' });
    if (process.platform === 'win32') {
      const arq = path.join(require('os').tmpdir(), `preguica3d-guia-${process.pid}.txt`);
      execFileSync('powershell', ['-NoProfile', '-Command',
        `[IO.File]::WriteAllText('${arq.replace(/'/g, "''")}', (Get-Clipboard -Raw), (New-Object Text.UTF8Encoding $false))`]);
      try { return fs.readFileSync(arq, 'utf8'); } finally { fs.rmSync(arq, { force: true }); }
    }
    try { return execSync('wl-paste', { encoding: 'utf8' }); } catch { return execSync('xclip -o -selection clipboard', { encoding: 'utf8' }); }
  } catch { return ''; }
}
// As 10 linhas da ficha do Prompt B, parte 1 (o começo de cada rótulo, sem acento)
const LINHAS_CHAT = [['o que aparece', 'O QUE APARECE'], ['nao pode faltar', 'NÃO PODE FALTAR'], ['cenario', 'CENÁRIO'], ['peca nova', 'PEÇA NOVA'],
  ['o que da errado', 'O QUE DÁ ERRADO'], ['personagem', 'PERSONAGEM'], ['interacao', 'INTERAÇÃO'], ['camera', 'CÂMERA'],
  ['na tela', 'NA TELA, POR CIMA'], ['cara e som', 'CARA E SOM']];
// As cenas da resposta da parte 1: "CENA 3: "a frase"" e as 10 linhas numeradas embaixo
// (a mesma cena pode aparecer duas vezes: no roteiro numerado, "CENA 3 — frase", e na ficha: fica uma só)
function cenasDoChat(txt) {
  const porN = new Map();
  let atual = null;
  for (const bruta of String(txt).replace(/\r/g, '').split('\n')) {
    const l = bruta.replace(/[*_#>]/g, '').trim();
    const cab = l.match(/^cena\s+(\d{1,3})\s*[:.\-–—)]?\s*(.*)$/i);
    if (cab) {
      const n = Number(cab[1]), frase = cab[2].replace(/^["“”']+|["“”']+$/g, '').trim();
      atual = porN.get(n) || { n, frase, linhas: {} };
      if (frase) atual.frase = frase;
      porN.set(n, atual);
      continue;
    }
    if (!atual) continue;
    const m = semAcento(l).match(/^(\d{1,2})[.)]?\s*([a-z ,]+?)\s*:\s*(.*)$/);
    if (!m) continue;
    const rot = LINHAS_CHAT.find(([k]) => m[2].trim().startsWith(k));
    if (rot) atual.linhas[rot[0]] = l.slice(l.indexOf(':') + 1).trim();
  }
  return [...porN.values()].sort((a, b) => a.n - b.n);
}
function conferirChat(txt) {
  const cenas = cenasDoChat(txt);
  const corrigir = [], conferir = [], pedir = [];
  if (cenas.length < 6) {
    corrigir.push(cenas.length ? `achei só ${cenas.length} cenas ("CENA 1:", "CENA 2:"...): toda frase do roteiro tem a sua cena` : 'não achei as cenas ("CENA 1:", "CENA 2:"...): copie a resposta INTEIRA da IA, da primeira à última linha');
    if (cenas.length) pedir.push('Faltaram cenas. Refaz a ficha de TODAS as frases do roteiro, uma "CENA [número]" por frase, com as 10 linhas.');
    return { cenas, corrigir, conferir, pedir };
  }
  const frases = cenas.map((c) => c.frase).filter(Boolean);
  const total = frases.join(' ').split(/\s+/).filter((w) => /[\p{L}\p{N}]/u.test(w)).length;
  if (frases[0] && !/\?\s*$/.test(frases[0])) { corrigir.push(`a cena 1 é o gancho e tem que ser uma pergunta curiosa, terminando com "?" (agora: "${frases[0]}")`); pedir.push('A 1ª frase tem que ser uma pergunta bem curiosa, de até 10 palavras, terminando com "?". Troca o gancho.'); }
  if (total < 150) { corrigir.push(`o roteiro está curto (${total} palavras): o mínimo é 150`); pedir.push(`O roteiro ficou curto (${total} palavras). Aumenta pra umas 250, com mais um ciclo "Mas... Então você... Esse é o...".`); }
  if (total > 560) { corrigir.push(`o roteiro está longo (${total} palavras): com mais de 550, passa de 3:00`); pedir.push(`O roteiro ficou longo (${total} palavras). Corta pra menos de 500.`); }
  const faltam = {}, iguais = [], curtas = [], paradas = [];
  cenas.forEach((c, i) => {
    const sem = LINHAS_CHAT.filter(([k]) => !c.linhas[k]).map(([, nome]) => nome);
    if (sem.length) faltam[c.n] = sem;
    const tudo = semAcento(Object.values(c.linhas).join(' '));
    if (/igual (a|da|ao|do) (cena )?anterior|mesm[ao] (da|que a|cena) anterior/.test(tudo)) iguais.push(c.n);
    const cam = semAcento(c.linhas.camera || ''), antes = i ? semAcento(cenas[i - 1].linhas.camera || '') : '';
    if (cam && cam === antes) iguais.push(c.n);
    if ((c.linhas['o que aparece'] || '').split(/\s+/).length < 6) curtas.push(c.n);
    if (/\bparad[oa]\b/.test(semAcento(c.linhas.personagem || '')) && !/nunca parad/.test(semAcento(c.linhas.personagem || ''))) paradas.push(c.n);
  });
  // "a cena 7" ou "as cenas 5, 9 e 12" (um: o singular; vários: o plural)
  const cenasDe = (ns) => {
    const u = [...new Set(ns.map(Number))].sort((a, b) => a - b);
    return { um: u.length === 1, txt: u.length === 1 ? `a cena ${u[0]}` : `as cenas ${u.slice(0, -1).join(', ')} e ${u[u.length - 1]}` };
  };
  const nas = (c) => `N${c.txt}`; // "Na cena 7", "Nas cenas 5 e 9"
  const nFaltam = Object.keys(faltam);
  if (nFaltam.length) {
    const c = cenasDe(nFaltam);
    corrigir.push(`${c.txt} ${c.um ? 'está' : 'estão'} sem alguma das 10 linhas (${[...new Set(Object.values(faltam).flat())].join(', ')})`);
    pedir.push(`${nas(c)} faltaram linhas da ficha. Refaz ${c.um ? 'essa cena' : 'essas cenas'} com as 10 linhas, escritas por extenso, sem pular nenhuma.`);
  }
  if (iguais.length) {
    const c = cenasDe(iguais);
    corrigir.push(`${c.txt} ${c.um ? 'repete' : 'repetem'} a anterior ("igual à anterior" ou a mesma câmera)`);
    pedir.push(`${c.txt[0].toUpperCase()}${c.txt.slice(1)} ${c.um ? 'repete' : 'repetem'} a cena anterior. Refaz por extenso, com uma câmera diferente da anterior.`);
  }
  if (curtas.length > 2) { const c = cenasDe(curtas); conferir.push(`${c.txt} têm o "O QUE APARECE" curto demais`); pedir.push(`${nas(c)}, o "O QUE APARECE" está curto: escreve tudo o que está na tela e onde fica.`); }
  if (paradas.length) { const c = cenasDe(paradas); conferir.push(`${nas(c).toLowerCase()} o personagem fica parado`); pedir.push(`${nas(c)} o personagem está parado. Põe ele fazendo alguma coisa que combina com a frase.`); }
  return { cenas, corrigir, conferir, pedir, total };
}
// O Prompt B, parte 2, de comandos/modo-chat.md, pra uma conversa nova: com o roteiro e as fichas dentro, antes do
// "Antes de responder" (a IA fraca segue melhor o que vem por último)
function pedidoDoChat2(resposta) {
  const L = (lerArq('comandos', 'modo-chat.md') || '').split('\n');
  const i = L.findIndex((l) => /^##\s+Prompt B.*parte 2/i.test(l));
  const a = L.findIndex((l, k) => k > i && /^```/.test(l));
  const b = L.findIndex((l, k) => k > a && /^```/.test(l));
  if (i < 0 || a < 0 || b < 0) return null;
  let p = L.slice(a + 1, b).join('\n')
    .replace(/^Agora transforme o roteiro e as fichas que você escreveu num bloco JSON/m, 'Transforme o roteiro e as fichas que estão no fim deste pedido num bloco JSON');
  const bloco = `O ROTEIRO E AS FICHAS (já aprovados: não mude nenhuma frase e não pule nenhuma cena):\n\n${resposta.trim()}\n\n`;
  const k = p.search(/^Antes de responder/m);
  return k >= 0 ? p.slice(0, k) + bloco + p.slice(k) : `${p}\n\n${bloco}`;
}

module.exports = { ETAPAS, montar, secoesDe, acharSecao, metodoDoCanal, pedidoDoChat, conferirChat, pedidoDoChat2 };

if (require.main === module) {
  const args = process.argv.slice(2);
  const tudo = args.includes('--tudo');
  const soltos = args.filter((a) => !a.startsWith('--'));
  const etapa = semAcento(soltos[0] || '');
  if (etapa === 'chat') {
    const tema = soltos.slice(1).join(' ').trim();
    const p = pedidoDoChat(tema);
    if (!p) { console.log('Não achei o Prompt B em comandos/modo-chat.md. Use o Prompt B de lá, colando o seu canal/canal.md.'); process.exit(1); }
    const arq = path.join(RAIZ, 'canal', 'pedido-do-video.txt');
    fs.mkdirSync(path.dirname(arq), { recursive: true });
    fs.writeFileSync(arq, p);
    const copiou = copiarTexto(p);
    console.log([
      copiou ? 'Pronto! O pedido do vídeo está copiado.' : 'Pronto! O pedido do vídeo está no arquivo canal/pedido-do-video.txt.',
      `É o Prompt B, parte 1, já com ${tema ? `o tema "${tema.replace(/[-_]+/g, ' ')}", ` : ''}o seu canal, o que a IA aprendeu com você e todas as regras do método.`,
      copiou ? 'Cole na sua IA de chat (Ctrl+V; no Mac, Cmd+V) e mande.' : 'Abra o arquivo, copie tudo (Ctrl+A e Ctrl+C) e cole na sua IA de chat.',
      tema ? '' : 'Antes de mandar, troque a linha TEMA pelo tema do vídeo (ou rode de novo com o tema: npm run guia -- chat como funciona a geladeira).',
      `Ele também fica em canal/pedido-do-video.txt (${Math.round(p.length / 1000)} mil letras).`,
      'A IA disse que o texto é grande demais? Use o Prompt B, parte 1, do arquivo comandos/modo-chat.md (a versão curta, sem as regras completas).',
      `Gostou do roteiro e das cenas? Copie a resposta INTEIRA da IA e rode: npm run guia -- chat2 ${tema ? tema.toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') : '<nome-do-video>'}`
    ].filter(Boolean).join('\n'));
    process.exit(0);
  }
  if (etapa === 'chat2' || etapa === 'parte2') {
    const tema = soltos.slice(1).join(' ').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
    if (!tema) { console.log('Diga o nome do vídeo, sem espaço. Ex.: npm run guia -- chat2 guarda-chuva'); process.exit(1); }
    const pasta = path.join(RAIZ, 'videos', tema);
    const salvo = path.join(pasta, 'roteiro-chat.txt');
    let resp = areaDeTransferencia();
    // Sem a resposta copiada: confere a que ficou guardada da última vez
    if (!cenasDoChat(resp).length && fs.existsSync(salvo)) resp = fs.readFileSync(salvo, 'utf8');
    const c = conferirChat(resp);
    if (c.cenas.length) { fs.mkdirSync(pasta, { recursive: true }); fs.writeFileSync(salvo, resp); }
    const l = [`CONFERÊNCIA DO ROTEIRO E DAS CENAS (jeito por chat): ${c.cenas.length} cenas${c.total ? `, ${c.total} palavras` : ''}.`];
    c.corrigir.forEach((x) => l.push(`[corrigir] ${x}`));
    c.conferir.forEach((x) => l.push(`[conferir] ${x}`));
    if (c.corrigir.length) {
      const pedido = `${c.pedir.join('\n')}\nDepois me manda de novo a resposta inteira: o roteiro, a lista de peças, o cenário e as fichas de TODAS as cenas.`;
      const copiou = copiarTexto(pedido);
      l.push('', 'RESULTADO: CORRIGIR', '', `${copiou ? 'Copiei este pedido pra você' : 'Copie este pedido'}. Cole na MESMA conversa da parte 1 e mande:`, '', pedido, '',
        `Quando a IA responder, copie a resposta inteira e rode de novo: npm run guia -- chat2 ${tema}`);
      console.log(l.join('\n'));
      process.exit(1);
    }
    const p2 = pedidoDoChat2(resp);
    if (!p2) { console.log('Não achei o Prompt B, parte 2, em comandos/modo-chat.md. Use o de lá, na mesma conversa.'); process.exit(1); }
    const arq = path.join(RAIZ, 'canal', 'pedido-do-video-parte2.txt');
    fs.mkdirSync(path.dirname(arq), { recursive: true });
    fs.writeFileSync(arq, p2);
    const copiou = copiarTexto(p2);
    l.push('', `RESULTADO: APROVADO${c.conferir.length ? ' (veja o que conferir acima: se quiser mudar, peça na conversa da parte 1 e rode de novo)' : ''}`, '',
      copiou ? 'Pronto! O Prompt B, parte 2, está copiado, já com o seu roteiro e as cenas dentro.' : 'Pronto! O Prompt B, parte 2, está no arquivo canal/pedido-do-video-parte2.txt, já com o seu roteiro e as cenas dentro.',
      `1. Abra uma conversa NOVA na sua IA (o botão de conversa nova) e ${copiou ? 'cole (Ctrl+V; no Mac, Cmd+V)' : 'cole o arquivo inteiro'}. Na conversa nova ela lê só o que precisa: erra menos e gasta menos do seu limite grátis.`,
      '2. Copie a resposta inteira dela (o bloco que começa com {).',
      `3. Veja as cenas: npm run colar -- ${tema} --voz-teste --revisar`,
      `A resposta da parte 1 ficou guardada em videos/${tema}/roteiro-chat.txt.`);
    console.log(l.join('\n'));
    process.exit(0);
  }
  if (!ETAPAS[etapa]) {
    console.log([
      'Qual etapa? A cola de cada etapa do vídeo, tirada dos guias da Máquina:',
      ...Object.entries(ETAPAS).map(([k, v]) => `  npm run guia -- ${k} <tema>`.padEnd(36) + v.nome),
      '',
      'PRA IA: num vídeo novo, rode na ordem: tema (se a pessoa não deu tema), roteiro, ficha, cena e postar (comandos/novo-video.md).'
    ].join('\n'));
    process.exit(soltos[0] ? 1 : 0);
  }
  const resto = soltos.slice(1);
  const pagina = Number(resto.find((a) => /^\d+$/.test(a)) || 1);
  const tema = (resto.find((a) => !/^\d+$/.test(a)) || '').replace(/^videos[\\/]/, '').replace(/[\\/]+$/, '');
  // A etapa da IA começou: o painel mostra ao vivo em que etapa ela está e há quanto tempo (motor/andamento.js)
  try { require('./andamento').comecar(etapa, { tema }); } catch { /* o painel só não mostra */ }
  mostrar(etapa, tema, pagina, tudo);
}
