// Conquistas: o caminho de quem cresce com a Máquina, em três trilhas (o menu "🏆 Conquistas" do painel, que chama as
// funções daqui, e o npm run conquistas). Cada trilha segue um número só, que só sobe, então nenhuma conquista chega
// antes da anterior: o Ritmo (vídeos postados), o Alcance (as views do vídeo mais visto) e os Seguidores (os inscritos).
// O nível é a soma das três.
//
// Os números vêm sozinhos do YouTube público da pessoa (o "@ nas redes" do Meu canal), com o yt-dlp que a Máquina já
// baixa pro Estudar virais: sem chave, sem login e sem senha. O Instagram e o TikTok não mostram esses números sem login,
// então quem bate um marco lá marca ele com um toque ("Bati esse marco"). Tudo fica em canal/conquistas.json, e as capas
// dos vídeos que bateram marco em canal/conquistas/ (a versão nova não apaga; o npm run importar leva). A estratégia e o
// passo a passo pra IA: viralizar/conquistas.md (os marcos de lá são estes)
//
//   npm run conquistas                       lê o YouTube agora e mostra as três trilhas
//   npm run conquistas -- --sem-ler          só mostra o que já está anotado
//   npm run conquistas -- --marcar <marco>   marca um marco batido no Instagram ou no TikTok (e os de antes, na trilha)
//   npm run conquistas -- --youtube @canal   o @ do YouTube, quando ele for diferente do "@ nas redes"
const fs = require('fs');
const path = require('path');
const https = require('https');
const { RAIZ } = require('./voz');
const C = require('./canal-arquivos');
const E = require('./estudar');

const ARQ = path.join(RAIZ, 'canal', 'conquistas.json');
const PASTA = path.join(RAIZ, 'canal', 'conquistas');
const DE_NOVO = 3 * 60 * 60 * 1000;   // lê o YouTube sozinho no máximo a cada 3 h ("Ler agora" passa por cima)
const APOS_ERRO = 15 * 60 * 1000;     // e, se deu erro, espera 15 min pra tentar sozinho de novo

const TRILHAS = [
  { id: 'ritmo', emoji: '🎬', nome: 'Ritmo', conta: 'vídeos postados', sobre: 'O que depende só de você: postar sempre.' },
  { id: 'alcance', emoji: '👀', nome: 'Alcance', conta: 'views do vídeo mais visto', sobre: 'Até onde um vídeo seu já chegou.' },
  { id: 'seguidores', emoji: '🙋', nome: 'Seguidores', conta: 'inscritos ou seguidores', sobre: 'Gente que quer ver o seu próximo vídeo.' },
];

// Na ordem de cada trilha. print: o que vale mostrar no story. dica: o próximo passo (os números de viralizar/dicas.md)
const MARCOS = [
  { id: 'primeiro-video', trilha: 'ritmo', meta: 1, emoji: '🎬', nome: 'Primeiro vídeo no ar', curto: '1º vídeo',
    porque: 'O mais difícil é começar. Agora é ritmo.', print: 'o vídeo postado, aberto no seu perfil',
    dica: 'Poste o próximo em até 2 dias, no mesmo horário: a rede confia em canal que aparece sempre (dicas 116 e 117).' },
  { id: 'dez-videos', trilha: 'ritmo', meta: 10, emoji: '🔟', nome: '10 vídeos postados', curto: '10 vídeos',
    porque: 'Constância: é ela que faz a rede confiar no canal.', print: 'a grade do seu perfil com os 10 vídeos',
    dica: 'Compare os 10: o tema do que foi melhor é a pista do próximo (dica 7).' },
  { id: 'trinta-videos', trilha: 'ritmo', meta: 30, emoji: '📅', nome: '30 vídeos postados', curto: '30 vídeos',
    porque: 'Um mês de ritmo. A partir daqui, os seus números começam a ensinar.', print: 'a grade do seu perfil',
    dica: 'Peça pra IA comparar os seus vídeos e propor um teste só pro próximo (viralizar/medir-e-testar.md).' },
  { id: 'cem-videos', trilha: 'ritmo', meta: 100, emoji: '💯', nome: '100 vídeos postados', curto: '100 vídeos',
    porque: 'Pouca gente chega aqui. O seu canal já é um acervo que trabalha sozinho.', print: 'o seu perfil com o número de vídeos',
    dica: 'Junte os seus 10 vídeos mais vistos e peça pra IA achar o que eles têm em comum: é a receita do seu canal.' },

  { id: 'mil-views', trilha: 'alcance', meta: 1000, emoji: '👀', nome: '1 mil views num vídeo', curto: '1 mil',
    porque: 'A rede mostrou o seu vídeo pra gente que não te conhece.', print: 'o vídeo com o número de views',
    dica: 'Abra os números e veja quantos pularam nos 3 primeiros segundos. Passou de 35%? Capriche no gancho do próximo (dica 125).' },
  { id: 'dez-mil-views', trilha: 'alcance', meta: 10000, emoji: '🚀', nome: '10 mil views num vídeo', curto: '10 mil',
    porque: 'Um vídeo que espalhou de verdade.', print: 'o vídeo com o número de views',
    dica: 'Estude esse vídeo como se fosse de outro canal: o que ele fez de diferente dos outros? (menu Estudar virais).' },
  { id: 'cem-mil-views', trilha: 'alcance', meta: 100000, emoji: '🔥', nome: '100 mil views num vídeo', curto: '100 mil',
    porque: 'O primeiro grande viral.', print: 'o vídeo com o número de views',
    dica: 'Faça a continuação desse tema enquanto ele está quente: a mesma turma quer mais.' },
  { id: 'milhao-views', trilha: 'alcance', meta: 1000000, emoji: '🌎', nome: '1 milhão de views num vídeo', curto: '1 milhão',
    porque: 'O viral de verdade.', print: 'o vídeo com o número de views',
    dica: 'Responda os comentários desse vídeo por dias: ele vai continuar trazendo gente por semanas.' },
  { id: 'dez-milhoes-views', trilha: 'alcance', meta: 10000000, emoji: '🌌', nome: '10 milhões de views num vídeo', curto: '10 milhões',
    porque: 'Um vídeo que o país inteiro viu. Lenda.', print: 'o vídeo com o número de views',
    dica: 'Fixe um comentário com a pergunta do seu próximo vídeo: quem chegar por esse vai ter pra onde ir.' },

  { id: 'cem-seguidores', trilha: 'seguidores', meta: 100, emoji: '🙋', nome: '100 seguidores', curto: '100',
    porque: 'Gente que quer ver o seu próximo vídeo.', print: 'o seu perfil com o número de seguidores',
    dica: 'Faça uma série: um assunto que rende vários vídeos faz quem gostou de um seguir pra ver o próximo (dica 16).' },
  { id: 'mil-seguidores', trilha: 'seguidores', meta: 1000, emoji: '⭐', nome: '1 mil seguidores', curto: '1 mil',
    porque: 'No YouTube, é o número de inscritos que o programa que paga pelos vídeos pede, junto com as views.', print: 'o seu perfil com o número',
    dica: 'Veja no YouTube Studio, em Ganhar dinheiro, quanto falta pro programa. Pra entrar e ficar: vídeo original e variado, e voz com licença comercial (viralizar/cuidados.md).' },
  { id: 'dez-mil-seguidores', trilha: 'seguidores', meta: 10000, emoji: '💎', nome: '10 mil seguidores', curto: '10 mil',
    porque: 'No TikTok, é o número de seguidores que os guias citam pro Programa de Recompensas.', print: 'o seu perfil com o número',
    dica: 'Confira no TikTok Studio se o canal já pode entrar no Programa de Recompensas (conta pessoal, vídeos com mais de 1 minuto).' },
  { id: 'cem-mil-seguidores', trilha: 'seguidores', meta: 100000, emoji: '🥈', nome: '100 mil seguidores', curto: '100 mil',
    porque: 'No YouTube, é a Placa de Prata.', print: 'o seu perfil com o número',
    dica: 'O YouTube avisa no Studio pra você pedir a Placa de Prata.' },
  { id: 'milhao-seguidores', trilha: 'seguidores', meta: 1000000, emoji: '👑', nome: '1 milhão de seguidores', curto: '1 milhão',
    porque: 'No YouTube, é a Placa de Ouro. Lenda.', print: 'o seu perfil com o número',
    dica: 'Conta pra gente como foi, no Discord da comunidade: a sua história vai ajudar quem está começando.' },
];
const POR_ID = Object.fromEntries(MARCOS.map((m) => [m.id, m]));
const DA_TRILHA = Object.fromEntries(TRILHAS.map((t) => [t.id, MARCOS.filter((m) => m.trilha === t.id)]));

const ID_VIDEO = /^[A-Za-z0-9_-]{6,20}$/;
const relOk = (r) => typeof r === 'string' && /^canal\/conquistas\/[\w.-]+(\/[\w.-]+)?$/.test(r) && !r.includes('..');
const rel = (f) => path.relative(RAIZ, f).split(path.sep).join('/');
const hoje = () => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; };
const num = (n) => (Number.isFinite(n) && n >= 0 ? Math.floor(n) : null);
// O @ do YouTube: aceita "@canal", "canal" ou o link do canal (handles do YouTube: 3 a 30 letras, números, . _ e -)
function limparArroba(a) {
  const t = String(a || '').trim();
  const m = t.match(/youtube\.com\/@([\p{L}\p{N}._-]{3,30})/u) || t.match(/^@?([\p{L}\p{N}._-]{3,30})$/u) || t.match(/@([\p{L}\p{N}._-]{3,30})/u);
  return m ? `@${m[1]}` : '';
}

// ===================================================================== o arquivo
// canal/conquistas.json: { versao: 2, youtube?, leitura, marcos: { id: { em, manual?, compartilhado?, video?, imagens? } } }.
// manual: a pessoa marcou e o YouTube ainda não confirmou. O formato de antes (os números digitados) vira este: tudo que
// estava marcado conta como marcado pela pessoa, e o "monetizado" sai
function lerArquivo() {
  let d = {};
  try { d = JSON.parse(fs.readFileSync(ARQ, 'utf8')); } catch { /* ainda não tem */ }
  return normalizar(d);
}

function normalizar(d) {
  if (!d || typeof d !== 'object') d = {};
  const antigo = d.versao !== 2;
  const feito = {};
  for (const [id, v] of Object.entries((d.marcos && typeof d.marcos === 'object' && d.marcos) || {})) {
    if (!POR_ID[id]) continue;
    const f = v && typeof v === 'object' ? v : {};
    const x = { em: /^\d{4}-\d{2}-\d{2}/.test(String(f.em || '')) ? String(f.em).slice(0, 10) : '' };
    if (antigo || f.manual) x.manual = true;
    if (f.compartilhado) x.compartilhado = true;
    const vi = f.video;
    if (vi && typeof vi === 'object' && ID_VIDEO.test(String(vi.id || ''))) {
      x.video = { id: vi.id, titulo: String(vi.titulo || '').slice(0, 200), url: /^https:\/\/www\.youtube\.com\//.test(vi.url || '') ? vi.url : `https://www.youtube.com/watch?v=${vi.id}`, views: num(vi.views) || 0 };
    }
    if (Array.isArray(f.imagens)) { const im = f.imagens.filter(relOk).slice(0, 6); if (im.length) x.imagens = im; }
    feito[id] = x;
  }
  const l = d.leitura && typeof d.leitura === 'object' ? d.leitura : null;
  const leitura = l ? {
    em: /^\d{4}-/.test(String(l.em || '')) ? String(l.em) : '',
    youtube: limparArroba(l.youtube), canal: String(l.canal || '').slice(0, 120),
    inscritos: num(l.inscritos), videos: num(l.videos),
    melhor: l.melhor && ID_VIDEO.test(String(l.melhor.id || '')) ? { id: l.melhor.id, url: String(l.melhor.url || ''), views: num(l.melhor.views) || 0 } : null,
    ...(l.erro ? { erro: String(l.erro).slice(0, 300), erroTipo: String(l.erroTipo || ''), erroEm: String(l.erroEm || '') } : {}),
  } : null;
  return { feito, leitura, youtube: limparArroba(d.youtube) };
}

function serializar({ feito, leitura, youtube }) {
  const marcos = {};
  for (const m of MARCOS) if (feito[m.id]) marcos[m.id] = feito[m.id];
  return `${JSON.stringify({ versao: 2, ...(youtube ? { youtube } : {}), leitura, marcos }, null, 2)}\n`;
}

function escrever(est) {
  fs.mkdirSync(path.dirname(ARQ), { recursive: true });
  const tmp = `${ARQ}.tmp`;
  fs.writeFileSync(tmp, serializar(est));
  fs.renameSync(tmp, ARQ);
}

// O npm run importar junta as conquistas da Máquina antiga (velho) com as desta (novo), os dois como vieram do JSON: de
// cada marco fica a data mais antiga, o vídeo, as capas e o "story postado" de qualquer um dos dois; a leitura mais nova
function juntar(velho, novo) {
  const A = normalizar(velho), B = normalizar(novo), feito = {};
  for (const m of MARCOS) {
    const x = A.feito[m.id], y = B.feito[m.id];
    if (!x || !y) { if (x || y) feito[m.id] = { ...(x || y) }; continue; }
    const z = { em: [x.em, y.em].filter(Boolean).sort()[0] || '' };
    if (x.manual && y.manual) z.manual = true;
    if (x.compartilhado || y.compartilhado) z.compartilhado = true;
    if (y.video || x.video) z.video = y.video || x.video;
    const im = y.imagens && y.imagens.length ? y.imagens : x.imagens;
    if (im && im.length) z.imagens = im;
    feito[m.id] = z;
  }
  consertar(feito);
  const lidas = [B.leitura, A.leitura].filter((l) => l && l.em).sort((p, q) => q.em.localeCompare(p.em));
  return { feito, leitura: lidas[0] || B.leitura || A.leitura || null, youtube: B.youtube || A.youtube };
}

// Numa trilha, ninguém pula marco: se um está batido, os de antes também estão (com a mesma data)
function consertar(feito) {
  for (const t of TRILHAS) {
    let depois = null;
    for (const m of [...DA_TRILHA[t.id]].reverse()) {
      if (feito[m.id]) depois = feito[m.id];
      else if (depois) feito[m.id] = { em: depois.em, ...(depois.manual ? { manual: true } : {}) };
    }
  }
}

function arrobaDoYoutube(youtube) {
  if (youtube) return youtube;
  let txt = '';
  try { txt = fs.readFileSync(path.join(RAIZ, 'canal', 'canal.md'), 'utf8'); } catch { /* canal ainda em branco */ }
  return limparArroba(C.campo(txt, '@ nas redes'));
}

function avatarAtual() {
  for (const x of ['jpg', 'png', 'webp']) if (fs.existsSync(path.join(PASTA, `canal.${x}`))) return `canal/conquistas/canal.${x}`;
  return null;
}

let lendo = null;

function ler() {
  const { feito, leitura, youtube } = lerArquivo();
  return { ok: true, trilhas: TRILHAS, marcos: MARCOS, feito, leitura, youtube: arrobaDoYoutube(youtube), youtubeProprio: !!youtube,
    nivel: MARCOS.filter((m) => feito[m.id]).length, total: MARCOS.length, avatar: avatarAtual(), lendo: !!lendo, leitor: E.estadoBaixador(),
    arquivo: 'canal/conquistas.json' };
}

// d.marcar: { id } marca (e os de antes, na mesma trilha), { id, feito: false } desmarca (só o que a pessoa marcou, e os
// de depois), { id, compartilhado: true } é o "já postei o story". d.youtube: o @ do YouTube ('' volta pro "@ nas redes")
function salvar(d = {}) {
  const est = lerArquivo();
  const antes = new Set(Object.keys(est.feito));
  if (d.youtube !== undefined) {
    const a = limparArroba(d.youtube);
    if (String(d.youtube || '').trim() && !a) return { ok: false, mensagem: 'Esse @ não parece um canal do YouTube. Escreva assim: @seucanal' };
    if (a !== est.youtube) { est.youtube = a; est.leitura = null; }
  }
  const mc = d.marcar;
  if (mc && POR_ID[mc.id]) {
    const m = POR_ID[mc.id], daTrilha = DA_TRILHA[m.trilha];
    if (mc.feito === false) {
      for (const x of daTrilha.slice(daTrilha.indexOf(m))) if (est.feito[x.id] && est.feito[x.id].manual) delete est.feito[x.id];
    } else if (mc.compartilhado != null) {
      if (est.feito[m.id]) est.feito[m.id].compartilhado = !!mc.compartilhado;
    } else if (!est.feito[m.id]) {
      est.feito[m.id] = { em: hoje(), manual: true };
      consertar(est.feito);
    }
  }
  escrever(est);
  return { ...ler(), novos: MARCOS.filter((m) => est.feito[m.id] && !antes.has(m.id)).map((m) => m.id) };
}

// ===================================================================== a leitura do YouTube
class ErroLeitura extends Error {
  constructor(msg, tipo, detalhe = '') { super(msg); this.tipo = tipo; this.detalhe = detalhe; }
}

function erroDaLeitura(t, arroba) {
  const b = t.toLowerCase();
  if (/http error 404|does not exist|this channel is not available|channel not found/.test(b)) return new ErroLeitura(`Não achei o canal ${arroba} no YouTube.`, 'nao-achei', t.slice(-300));
  if (/not a bot|confirm you|http error 429|too many requests|rate.?limit/.test(b)) return new ErroLeitura('O YouTube pediu pra esperar um pouco. A Máquina tenta de novo mais tarde.', 'espera', t.slice(-300));
  if (/timed out|timeout|getaddrinfo|network|connection|temporary failure|unable to download|name resolution/.test(b)) return new ErroLeitura('Sem internet agora (ou o YouTube demorou demais). A Máquina tenta de novo mais tarde.', 'internet', t.slice(-300));
  return new ErroLeitura('Não consegui ler o seu YouTube agora. A Máquina tenta de novo mais tarde.', 'outro', t.slice(-300));
}

// As abas Shorts e Vídeos do canal, sem baixar vídeo nenhum: os inscritos, cada vídeo com as views e a capa. O YouTube
// arredonda como mostra no app ("29 mil", "1,5 mi"), sempre pra baixo: um marco nunca bate antes da hora. Em português o
// yt-dlp lê "76 mil" como 76, então a leitura é em inglês (os títulos vêm traduzidos; o original vem do oEmbed)
async function lerYoutube(arroba) {
  let bin;
  try { bin = await E.garantirYtdlp(); } catch (e) { throw new ErroLeitura('Não deu pra baixar o leitor do YouTube (é uma vez só). Confira a internet e tente de novo.', 'internet', String(e.message || e)); }
  const base = ['--no-warnings', '--no-color', '--flat-playlist', '-J', '--socket-timeout', '20', '--playlist-end', '1000'];
  const h = encodeURIComponent(arroba.replace(/^@/, ''));
  const aba = async (nome) => {
    const r = await E.rodar(bin, [...base, '--', `https://www.youtube.com/@${h}/${nome}`], { tempo: 150000 });
    if (r.codigo === 0) { try { return JSON.parse(r.saida); } catch { /* cai no erro */ } }
    const t = `${r.erro || ''}\n${r.saida || ''}`.slice(-3000);
    if (/does not have an? \w+ tab/i.test(t)) return { entries: [] };
    throw erroDaLeitura(t, arroba);
  };
  const [s, v] = await Promise.all([aba('shorts'), aba('videos')]);
  const lista = [];
  for (const [d, tipo] of [[s, 'short'], [v, 'video']]) {
    for (const e of (d && d.entries) || []) {
      if (!e || !ID_VIDEO.test(String(e.id || ''))) continue;
      const th = (e.thumbnails || []).filter((x) => x && /^https:\/\//.test(x.url || '')).sort((a, b) => (b.width || 0) * (b.height || 0) - (a.width || 0) * (a.height || 0))[0];
      lista.push({ id: e.id, titulo: String(e.title || '').slice(0, 200), views: num(e.view_count), capa: th ? th.url : '', tipo,
        url: tipo === 'short' ? `https://www.youtube.com/shorts/${e.id}` : `https://www.youtube.com/watch?v=${e.id}` });
    }
  }
  const info = [s, v].find((d) => d && (d.channel || d.uploader_id)) || {};
  const inscritos = [s, v].map((d) => d && num(d.channel_follower_count)).find((x) => x != null) ?? null;
  const fotos = [s, v].flatMap((d) => (d && d.thumbnails) || []).filter((x) => x && /^https:\/\//.test(x.url || ''));
  const quadrada = fotos.filter((x) => x.width && x.width === x.height).sort((a, b) => b.width - a.width).find((x) => x.width <= 1000);
  const crua = fotos.find((x) => x.id === 'avatar_uncropped');
  const melhor = lista.filter((x) => x.views != null).sort((a, b) => b.views - a.views)[0] || null;
  return { canal: String(info.channel || info.uploader || ''), inscritos, videos: lista.length, lista, melhor,
    avatar: quadrada ? quadrada.url : crua ? crua.url.replace(/=s0$/, '=s800') : '' };
}

// O vídeo que bateu um marco de views: o que tem menos views acima da meta (no dia a dia é o que acabou de passar dela;
// num canal que já era grande, cada marco ganha um vídeo diferente, perto do número)
const videoDoMarco = (lista, meta) => lista.filter((x) => x.views != null && x.views >= meta).sort((a, b) => a.views - b.views)[0] || null;
// Os mais novos (pra grade da arte dos marcos de ritmo): os Shorts, ou os vídeos se não tiver Short. A lista do YouTube
// vem do mais novo pro mais antigo, então o último é o primeiro vídeo do canal
const dosShorts = (lista) => { const s = lista.filter((x) => x.tipo === 'short' && x.capa); return s.length ? s : lista.filter((x) => x.capa); };
const recentes = (lista, n) => dosShorts(lista).slice(0, n);
const primeiro = (lista) => dosShorts(lista).slice(-1)[0] || null;

const HOSTS_IMG = /(^|\.)(ytimg\.com|ggpht\.com|googleusercontent\.com)$/;
function baixarImagem(url, base, saltos = 0) {
  return new Promise((ok, falha) => {
    let u;
    try { u = new URL(url); } catch { return falha(new Error('link estranho')); }
    if (u.protocol !== 'https:' || !HOSTS_IMG.test(u.hostname)) return falha(new Error('site estranho'));
    let acabou = false;
    const req = https.get(u, { headers: { 'User-Agent': 'maquina-preguica-3d' }, timeout: 20000 }, (res) => {
      if ([301, 302, 303, 307, 308].includes(res.statusCode) && res.headers.location && saltos < 3) {
        res.resume();
        acabou = true;
        return baixarImagem(new URL(res.headers.location, u).href, base, saltos + 1).then(ok, falha);
      }
      const ext = { 'image/jpeg': 'jpg', 'image/png': 'png', 'image/webp': 'webp' }[String(res.headers['content-type'] || '').split(';')[0].trim()];
      if (res.statusCode !== 200 || !ext) { res.resume(); acabou = true; return falha(new Error(`o site respondeu ${res.statusCode}`)); }
      const partes = [];
      let n = 0;
      res.on('data', (d) => { n += d.length; if (n > 6e6 && !acabou) { acabou = true; req.destroy(); falha(new Error('imagem grande demais')); } else partes.push(d); });
      res.on('end', () => {
        if (acabou) return;
        acabou = true;
        try {
          fs.mkdirSync(path.dirname(base), { recursive: true });
          for (const x of ['jpg', 'png', 'webp']) if (x !== ext) fs.rmSync(`${base}.${x}`, { force: true });
          fs.writeFileSync(`${base}.${ext}`, Buffer.concat(partes));
          ok(rel(`${base}.${ext}`));
        } catch (e) { falha(e); }
      });
      res.on('error', (e) => { if (!acabou) { acabou = true; falha(e); } });
    });
    req.on('timeout', () => req.destroy(new Error('demorou demais')));
    req.on('error', (e) => { if (!acabou) { acabou = true; falha(e); } });
  });
}

// O título original do vídeo (o oEmbed oficial do YouTube, sem chave): a lista vem com o título traduzido pro inglês
function tituloOriginal(link) {
  return new Promise((ok) => {
    const req = https.get(`https://www.youtube.com/oembed?format=json&url=${encodeURIComponent(link)}`, { headers: { 'User-Agent': 'maquina-preguica-3d' }, timeout: 15000 }, (res) => {
      if (res.statusCode !== 200) { res.resume(); return ok(''); }
      let d = '';
      res.setEncoding('utf8');
      res.on('data', (x) => { if (d.length < 1e5) d += x; });
      res.on('end', () => { try { ok(String(JSON.parse(d).title || '').slice(0, 200)); } catch { ok(''); } });
    });
    req.on('timeout', () => req.destroy());
    req.on('error', () => ok(''));
  });
}

// Lê o YouTube e marca o que bateu. Sozinha, só se a última leitura tiver mais de 3 h (forcar: o "Ler agora")
function lerAgora({ forcar = false } = {}) {
  if (lendo) return lendo;
  const est = lerArquivo(), arroba = arrobaDoYoutube(est.youtube), l = est.leitura;
  if (!arroba) return Promise.resolve({ ...ler(), novos: [], semArroba: true });
  const mesmo = l && l.youtube && l.youtube.toLowerCase() === arroba.toLowerCase();
  const recente = mesmo && (l.erro ? Date.now() - Date.parse(l.erroEm || 0) < APOS_ERRO : Date.now() - Date.parse(l.em || 0) < DE_NOVO);
  if (!forcar && recente) return Promise.resolve({ ...ler(), novos: [] });
  lendo = (async () => {
    try {
      const r = await lerYoutube(arroba);
      const valor = { ritmo: r.videos, alcance: r.melhor ? r.melhor.views : r.videos === 0 ? 0 : null, seguidores: r.inscritos };
      const bate = (m) => valor[m.trilha] != null && valor[m.trilha] >= m.meta;
      // 1) o que vai precisar de imagem: a capa do vídeo de cada marco de views e as capas mais novas nos de ritmo
      const agora = lerArquivo(), prova = {};
      for (const m of MARCOS.filter(bate)) {
        const f = agora.feito[m.id];
        if (m.trilha === 'alcance' && !(f && f.video)) { const vid = videoDoMarco(r.lista, m.meta); if (vid) prova[m.id] = { video: vid }; }
        // o primeiro vídeo ganha a capa dele; os outros marcos de ritmo, a grade dos mais novos
        if (m.id === 'primeiro-video' && !(f && f.video)) { const vid = primeiro(r.lista); if (vid) prova[m.id] = { video: vid }; }
        else if (m.trilha === 'ritmo' && !(f && f.imagens && f.imagens.length)) prova[m.id] = { recentes: recentes(r.lista, 6) };
      }
      // 2) baixa (cada capa uma vez só, em canal/conquistas/capas/) e pega o título original de cada vídeo que bateu marco
      const capas = new Map();
      const capaDe = (vid) => {
        if (!vid.capa) return Promise.resolve(null);
        if (!capas.has(vid.id)) capas.set(vid.id, baixarImagem(vid.capa, path.join(PASTA, 'capas', vid.id)).catch(() => null));
        return capas.get(vid.id);
      };
      for (const p of Object.values(prova)) {
        if (p.video) { p.imagens = [await capaDe(p.video)].filter(Boolean); p.video = { ...p.video, titulo: (await tituloOriginal(p.video.url)) || p.video.titulo }; }
        if (p.recentes) p.imagens = (await Promise.all(p.recentes.map(capaDe))).filter(Boolean);
      }
      const foto = avatarAtual();
      let fotoVelha = true;
      try { fotoVelha = !foto || Date.now() - fs.statSync(path.join(RAIZ, foto)).mtimeMs > 7 * 864e5; } catch { /* baixa de novo */ }
      if (r.avatar && fotoVelha && MARCOS.some((m) => m.trilha === 'seguidores' && bate(m))) await baixarImagem(r.avatar, path.join(PASTA, 'canal')).catch(() => null);
      // 3) grava, lendo o arquivo de novo: a pessoa pode ter marcado alguma coisa enquanto a Máquina lia
      const fim = lerArquivo(), dia = hoje(), novos = [];
      for (const m of MARCOS.filter(bate)) {
        let f = fim.feito[m.id];
        if (!f) { f = fim.feito[m.id] = { em: dia }; novos.push(m.id); }
        delete f.manual;
        const p = prova[m.id];
        if (p && p.video && !f.video) { const { id, titulo, url, views } = p.video; f.video = { id, titulo, url, views }; }
        if (p && p.imagens && p.imagens.length && !(f.imagens && f.imagens.length)) f.imagens = p.imagens;
        if (f.video) { const x = r.lista.find((q) => q.id === f.video.id); if (x && x.views > f.video.views) f.video.views = x.views; }
      }
      consertar(fim.feito);
      fim.leitura = { em: new Date().toISOString(), youtube: arroba, canal: r.canal, inscritos: r.inscritos, videos: r.videos,
        melhor: r.melhor ? { id: r.melhor.id, url: r.melhor.url, views: r.melhor.views } : null };
      escrever(fim);
      return { ...ler(), lendo: false, novos };
    } catch (e) {
      // guarda o erro pro painel mostrar; os números da última leitura ficam (se forem deste mesmo @)
      const fim = lerArquivo(), antes = fim.leitura;
      const dele = antes && antes.youtube && antes.youtube.toLowerCase() === arroba.toLowerCase() ? antes : {};
      fim.leitura = { ...dele, youtube: arroba, erro: e.message, erroTipo: e.tipo || 'outro', erroEm: new Date().toISOString() };
      escrever(fim);
      return { ...ler(), lendo: false, novos: [] };
    }
  })().finally(() => {
    lendo = null;
    // o yt-dlp se atualiza a cada 3 dias, sempre depois de uma leitura (nunca no meio dela)
    setImmediate(() => { try { E.atualizarSePrecisar(); } catch { /* fica pra próxima */ } });
  });
  return lendo;
}

module.exports = { ARQ, TRILHAS, MARCOS, ler, salvar, lerAgora, limparArroba, juntar, serializar };

// ===================================================================== na linha de comando
const curto = (n) => (n == null ? '?' : n < 1000 ? String(n)
  : n < 1e6 ? `${(Math.floor(n / 100) / 10).toLocaleString('pt-BR', { maximumFractionDigits: n < 1e4 ? 1 : 0 })} mil`
    : `${(Math.floor(n / 1e5) / 10).toLocaleString('pt-BR', { maximumFractionDigits: 1 })} ${n < 2e6 ? 'milhão' : 'milhões'}`);
const comDe = (n, palavra) => `${curto(n)}${n >= 1e6 ? ' de' : ''} ${palavra}`;
const dataBr = (iso) => (iso ? iso.slice(0, 10).split('-').reverse().join('/') : '');

function mostrar(r, novos = []) {
  const l = r.leitura;
  if (!r.youtube) console.log('Sem o @ do canal: escreva o seu @ em Meu canal (npm run painel -- --canal) pra Máquina ler o YouTube sozinha.');
  else if (l && l.erro) console.log(`${l.erro}${l.erroTipo === 'nao-achei' ? ' Confira o "@ nas redes" em Meu canal, ou rode: npm run conquistas -- --youtube @seu-canal' : ''}`);
  if (l && l.em) {
    const quando = new Date(l.em).toLocaleString('pt-BR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' });
    console.log(`YouTube ${l.youtube} (lido em ${quando}): ${comDe(l.inscritos, 'inscritos')} · ${l.videos} ${l.videos === 1 ? 'vídeo' : 'vídeos'} · o mais visto com ${comDe(l.melhor ? l.melhor.views : 0, 'views')}`);
  }
  console.log(`\nNível ${r.nivel} de ${r.total}`);
  const valor = { ritmo: l && l.videos, alcance: l && (l.melhor ? l.melhor.views : l.videos === 0 ? 0 : null), seguidores: l && l.inscritos };
  for (const t of TRILHAS) {
    console.log(`\n${t.emoji} ${t.nome} (${t.conta})${valor[t.id] != null ? `: ${curto(valor[t.id])}` : ''}`);
    let proximo = true;
    for (const m of DA_TRILHA[t.id]) {
      const f = r.feito[m.id];
      if (f) {
        const extra = [f.em && dataBr(f.em), f.manual && 'marcado por você', f.video && f.video.titulo && `"${f.video.titulo}"`, f.compartilhado && 'story postado'].filter(Boolean).join(' · ');
        console.log(`  ✓ ${m.nome}${extra ? ` (${extra})` : ''}`);
      } else if (proximo) {
        proximo = false;
        const v = valor[t.id];
        console.log(`  ▶ ${m.nome}${v != null ? `: faltam ${curto(m.meta - v)}` : ''}`);
      } else console.log(`  · ${m.nome}`);
    }
  }
  if (novos.length) {
    console.log(`\n🏆 Conquista nova: ${novos.map((id) => POR_ID[id].nome).join(', ')}!`);
    console.log('A arte do story está pronta no painel: npm run painel -- --conquistas');
  }
}

if (require.main === module) {
  (async () => {
    const args = process.argv.slice(2);
    const val = (flag) => { const i = args.indexOf(flag); return i >= 0 ? args[i + 1] || '' : undefined; };
    if (val('--youtube') !== undefined) {
      const r = salvar({ youtube: val('--youtube') });
      if (!r.ok) { console.log(r.mensagem); process.exitCode = 1; return; }
      console.log(r.youtubeProprio ? `O @ do YouTube agora é ${r.youtube}.` : `O @ do YouTube volta a ser o "@ nas redes" do Meu canal${r.youtube ? ` (${r.youtube})` : ''}.`);
    }
    const marcar = val('--marcar');
    if (marcar !== undefined) {
      if (!POR_ID[marcar]) { console.log(`Esse marco não existe. Os nomes: ${MARCOS.map((m) => m.id).join(', ')}`); process.exitCode = 1; return; }
      const r = salvar({ marcar: { id: marcar } });
      console.log(r.novos.length ? `Marcado: ${r.novos.map((id) => POR_ID[id].nome).join(', ')}.` : `${POR_ID[marcar].nome} já estava marcado.`);
      return mostrar(r, r.novos.includes(marcar) ? [marcar] : []);
    }
    if (args.includes('--sem-ler')) return mostrar(ler());
    console.log('Lendo o seu YouTube (uns 20 segundos)...');
    const r = await lerAgora({ forcar: true });
    mostrar(r, r.novos || []);
  })().catch((e) => { console.log(`Não deu: ${e.message}`); process.exitCode = 1; });
}
