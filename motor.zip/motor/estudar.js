// Estudar virais: baixa um vídeo que viralizou pra pasta estudos/, do jeito que a IA consegue estudar: o vídeo, a capa,
// os números (views, curtidas, data), as fotos das cenas e, feita pelo painel no navegador, a transcrição de tudo que é
// falado. Tudo roda no computador da pessoa: o yt-dlp (baixado do GitHub oficial na primeira vez, pra .ferramentas/, e
// conferido pela soma SHA-256 da própria versão) e o ffmpeg que a Máquina já tem. Nenhum servidor nosso no meio.
//
// No painel, é o menu "Estudar virais" (o motor/painel.js chama as funções daqui). Sem o painel:
//   npm run estudar -- "<link>"            baixa o vídeo (até 1080p, no formato que abre em qualquer lugar) e tira as fotos
//   npm run estudar -- "<link>" --audio    só o áudio (o original, em M4A)
//   npm run estudar -- --lista             os estudos que já estão na pasta
// A transcrição é feita no painel (o Whisper roda no navegador): npm run painel -- --estudar abre lá, e ela começa
// sozinha nos vídeos baixados que ainda não têm. Como a IA estuda: comandos/estudar-viral.md e viralizar/estudar-copy.md.
// O caderno (estudos/virais-estudados.md) junta todos os estudos e a conclusão de cada um: a Máquina põe cada vídeo
// novo lá, a IA escreve a conclusão, e a resposta da IA de chat colada no painel entra sozinha (guardarResposta).
const fs = require('fs');
const path = require('path');
const https = require('https');
const crypto = require('crypto');
const { spawn } = require('child_process');
const { RAIZ } = require('./voz');

const PASTA = path.join(RAIZ, 'estudos');
const FERR = path.join(RAIZ, '.ferramentas');
const opcional = (f) => { try { return f(); } catch { return null; } };
const FFMPEG = opcional(() => require('ffmpeg-static')) || 'ffmpeg';
const FFPROBE = opcional(() => require('ffprobe-static').path) || 'ffprobe';
// O YouTube pede um motor de JavaScript pra liberar as qualidades boas: o próprio Node serve, do 22 em diante
const NODE_OK = Number(process.versions.node.split('.')[0]) >= 22;
const ASSET = process.platform === 'darwin' ? 'yt-dlp_macos'
  : process.platform === 'win32' ? (process.arch === 'arm64' ? 'yt-dlp_arm64.exe' : process.arch === 'ia32' ? 'yt-dlp_x86.exe' : 'yt-dlp.exe')
    : process.arch === 'arm64' ? 'yt-dlp_linux_aarch64' : 'yt-dlp_linux';
const YTDLP = process.env.YTDLP || path.join(FERR, process.platform === 'win32' ? 'yt-dlp.exe' : 'yt-dlp');
const ID_OK = /^[a-z0-9][a-z0-9-]{0,80}$/;

class Erro extends Error {
  constructor(msg, detalhe = '') { super(msg); this.detalhe = detalhe; }
}

// ===================================================================== o yt-dlp
function pedirUrl(url, { destino, aoProgresso, seguir = true } = {}, saltos = 0) {
  return new Promise((ok, falha) => {
    const req = https.get(url, { headers: { 'User-Agent': 'maquina-preguica-3d' }, timeout: 30000 }, (res) => {
      if ([301, 302, 303, 307, 308].includes(res.statusCode) && res.headers.location) {
        res.resume();
        if (!seguir) return ok({ local: res.headers.location });
        if (saltos > 6) return falha(new Error('O GitHub redirecionou demais.'));
        return pedirUrl(new URL(res.headers.location, url).href, { destino, aoProgresso }, saltos + 1).then(ok, falha);
      }
      if (res.statusCode !== 200) { res.resume(); return falha(new Error(`O GitHub respondeu ${res.statusCode}.`)); }
      const total = Number(res.headers['content-length']) || 0;
      if (!destino) {
        const partes = [];
        res.on('data', (d) => partes.push(d));
        res.on('end', () => ok({ texto: Buffer.concat(partes).toString('utf8') }));
        res.on('error', falha);
        return;
      }
      const hash = crypto.createHash('sha256');
      const saida = fs.createWriteStream(destino);
      let n = 0;
      res.on('data', (d) => { hash.update(d); n += d.length; if (aoProgresso) aoProgresso(n, total); });
      res.on('error', falha);
      saida.on('error', falha);
      saida.on('finish', () => ok({ sha256: hash.digest('hex'), bytes: n }));
      res.pipe(saida);
    });
    req.on('timeout', () => req.destroy(new Error('A internet demorou demais pra responder.')));
    req.on('error', falha);
  });
}

// Baixa o yt-dlp oficial na primeira vez (uns 25 a 40 MB, conforme o sistema), conferindo a soma da versão
let instalando = null;
const baixador = { pct: 0, erro: null };
function garantirYtdlp(aoProgresso) {
  if (process.env.YTDLP || fs.existsSync(YTDLP)) return Promise.resolve(YTDLP);
  if (instalando) return instalando;
  baixador.pct = 0;
  baixador.erro = null;
  instalando = (async () => {
    fs.mkdirSync(FERR, { recursive: true });
    const { local } = await pedirUrl('https://github.com/yt-dlp/yt-dlp/releases/latest', { seguir: false });
    const versao = (String(local || '').match(/\/tag\/([^/?#]+)/) || [])[1];
    if (!versao) throw new Erro('Não achei a versão do baixador no GitHub. Confira a internet e tente de novo.');
    const base = `https://github.com/yt-dlp/yt-dlp/releases/download/${versao}/`;
    const { texto } = await pedirUrl(base + 'SHA2-256SUMS');
    const linha = texto.split('\n').map((l) => l.trim().split(/\s+/)).find((p) => p[1] === ASSET);
    if (!linha) throw new Erro(`O baixador não tem versão pra este computador (${process.platform}, ${process.arch}).`);
    const tmp = `${YTDLP}.baixando`;
    const { sha256 } = await pedirUrl(base + ASSET, { destino: tmp, aoProgresso: (n, total) => { baixador.pct = total ? (n / total) * 100 : 0; if (aoProgresso) aoProgresso(n, total); } });
    if (sha256 !== linha[0]) {
      fs.rmSync(tmp, { force: true });
      throw new Erro('O baixador veio diferente do oficial (a internet pode ter cortado). Tente de novo.');
    }
    fs.chmodSync(tmp, 0o755);
    fs.renameSync(tmp, YTDLP);
    fs.writeFileSync(path.join(FERR, 'yt-dlp-conferido.txt'), String(Date.now()));
    return YTDLP;
  })().catch((e) => { baixador.erro = e.message; throw e; }).finally(() => { instalando = null; });
  return instalando;
}
// Pro painel: se o baixador já está no computador e, se não, quanto falta pra ele chegar
const estadoBaixador = () => ({ pronto: !!process.env.YTDLP || fs.existsSync(YTDLP), instalando: !!instalando, pct: Math.round(baixador.pct), erro: baixador.erro });
function preparar() {
  if (!estadoBaixador().pronto && !instalando) garantirYtdlp().catch(() => { /* o erro fica no estadoBaixador */ });
  return estadoBaixador();
}

// Os sites mudam e o yt-dlp corre atrás quase toda semana: a cada 3 dias ele se atualiza sozinho (-U), sempre com a
// fila vazia, pra nunca trocar o programa no meio de um download
function atualizarSePrecisar() {
  if (process.env.YTDLP || !fs.existsSync(YTDLP) || rodando || fila.length) return;
  const marca = path.join(FERR, 'yt-dlp-conferido.txt');
  let quando = 0;
  try { quando = Number(fs.readFileSync(marca, 'utf8')) || 0; } catch { /* nunca conferiu */ }
  if (Date.now() - quando < 3 * 864e5) return;
  fs.writeFileSync(marca, String(Date.now()));
  try { spawn(YTDLP, ['-U'], { stdio: 'ignore', windowsHide: true }).on('error', () => {}); } catch { /* fica pra próxima */ }
}

// O yt-dlp acha o ffprobe na mesma pasta do ffmpeg, e os dois da Máquina moram em pastas diferentes: junta numa só
function pastaDoFfmpeg() {
  if (!path.isAbsolute(FFMPEG) || !path.isAbsolute(FFPROBE)) return null; // sem o ffmpeg da Máquina: usa o do sistema
  const dir = path.join(FERR, 'ffmpeg');
  const ext = process.platform === 'win32' ? '.exe' : '';
  try {
    fs.mkdirSync(dir, { recursive: true });
    for (const [de, nome] of [[FFMPEG, `ffmpeg${ext}`], [FFPROBE, `ffprobe${ext}`]]) {
      const para = path.join(dir, nome);
      if (fs.existsSync(para) && fs.statSync(para).size === fs.statSync(de).size) continue;
      fs.rmSync(para, { force: true });
      try { fs.linkSync(de, para); } catch { fs.copyFileSync(de, para); fs.chmodSync(para, 0o755); }
    }
    return dir;
  } catch { return null; }
}

function argsBase() {
  const a = ['--no-warnings', '--no-color', '--no-playlist', '--playlist-items', '1', '--socket-timeout', '20'];
  const ff = pastaDoFfmpeg();
  if (ff) a.push('--ffmpeg-location', ff);
  if (NODE_OK) a.push('--no-js-runtimes', '--js-runtimes', `node:${process.execPath}`);
  return a;
}

// Roda um programa e junta a saída (aoLer recebe linha por linha, pra mostrar o progresso)
function rodar(programa, args, { aoLer, tempo = 0, tarefa } = {}) {
  return new Promise((ok) => {
    let p;
    try { p = spawn(programa, args, { windowsHide: true }); } catch (e) { return ok({ codigo: -1, saida: '', erro: String(e.message) }); }
    if (tarefa) tarefa.proc = p;
    let saida = '', erro = '', resto = '';
    const relogio = tempo ? setTimeout(() => { erro += '\nERROR: timed out'; p.kill(); }, tempo) : null;
    const linhas = (texto) => {
      if (!aoLer) return;
      resto += texto;
      const ls = resto.split(/\r?\n|\r/);
      resto = ls.pop();
      for (const l of ls) if (l.trim()) aoLer(l);
    };
    p.stdout.on('data', (d) => { const t = d.toString('utf8'); if (!aoLer) saida += t; else { saida = (saida + t).slice(-20000); linhas(t); } });
    p.stderr.on('data', (d) => { const t = d.toString('utf8'); erro = (erro + t).slice(-20000); linhas(t); });
    p.on('error', (e) => { erro += `\nERROR: ${e.message}`; });
    p.on('close', (codigo) => { if (relogio) clearTimeout(relogio); if (tarefa) tarefa.proc = null; ok({ codigo, saida, erro }); });
  });
}

// O Instagram (e às vezes o TikTok, o Facebook e o Kwai) recusa por uns minutos quem busca vários vídeos seguidos sem
// login, com um erro que não diz isso. Na gravação do curso (06/11), dois Reels públicos deram "Não consegui pegar esse
// vídeo" e, horas depois, o mesmo link veio normal. Por isso a busca e o download tentam de novo sozinhos (tentarDeNovo)
// e, se ainda assim não vier, a mensagem diz o que é. PERMANENTE: o que não adianta tentar de novo
const SITES_QUE_RECUSAM = /instagram\.com|instagr\.am|tiktok\.com|facebook\.com|fb\.watch|kwai/i;
const PERMANENTE = /private|unsupported url|no suitable extractor|has been removed|no longer available|does not exist|http error 404|drm|age.?restrict|members-only/i;
const RECUSOU = 'O site não liberou esse vídeo agora (o Instagram faz isso por alguns minutos quando a gente busca vários vídeos seguidos). A Máquina já tentou 3 vezes: espere 2 ou 3 minutos e clique em Buscar de novo. Se continuar, abra o link no navegador sem estar logado: se ele pedir login pra mostrar o vídeo, o vídeo não é público.';
function tentarDeNovo(link, r) { return (r.codigo !== 0 || !String(r.saida || '').trim()) && SITES_QUE_RECUSAM.test(link) && !PERMANENTE.test(r.erro || ''); }
async function comNovasTentativas(link, fazer, aoTentar = () => {}, parar = () => false) {
  let r = await fazer();
  for (const espera of [4000, 10000]) {
    if (parar() || !tentarDeNovo(link, r)) break;
    aoTentar(espera);
    await new Promise((ok) => setTimeout(ok, espera));
    if (parar()) break;
    r = await fazer();
  }
  return r;
}

function traduzir(saida, link = '') {
  if (SITES_QUE_RECUSAM.test(link) && !PERMANENTE.test(saida) && /rate.?limit|login|logged.?in|locked behind|empty media|unable to extract|unable to download|429|too many requests|not available|general metadata/i.test(saida)) {
    return new Erro(RECUSOU, saida.split('\n').filter((l) => l.startsWith('ERROR')).pop() || saida.slice(-400));
  }
  const erros = saida.split('\n').filter((l) => l.startsWith('ERROR'));
  const t = (erros.length ? erros[erros.length - 1] : saida.slice(-400)).trim();
  const b = t.toLowerCase();
  const casos = [
    [['unsupported url', 'no suitable extractor'], 'Esse site não é aceito. Funciona com YouTube, Instagram, TikTok, X, Facebook, Kwai, Pinterest e centenas de outros.'],
    [['confirm you', 'not a bot'], 'O YouTube pediu pra confirmar que não é um robô. Espere uns minutos e tente de novo.'],
    [['confirm your age', 'age-restricted', 'age restricted', 'inappropriate for some users'], 'Esse vídeo tem restrição de idade e só abre com login. Não dá pra baixar por aqui.'],
    [['private video', 'video is private', 'this account is private'], 'Esse vídeo é privado. Só dá pra baixar vídeo público.'],
    [['members-only', 'join this channel', 'premium'], 'Esse vídeo é só pra membros ou assinantes. Só dá pra baixar vídeo público.'],
    [['live event will begin', 'premieres in', 'is live', 'live stream'], 'É uma transmissão ao vivo. Espere ela terminar e tente de novo.'],
    [['login required', 'log in', 'login', 'cookies', 'rate-limit reached'], 'O site pediu login pra mostrar esse vídeo. Se ele for público, espere uns minutos e tente de novo (o Instagram faz isso quando muita gente baixa).'],
    [['drm'], 'Esse vídeo é protegido contra cópia. Não dá pra baixar.'],
    [['requested format is not available', 'format is not available'], 'Essa qualidade não está mais disponível. Busque o link de novo e escolha outra.'],
    [['not available in your country', 'geo restrict', 'not available from your location'], 'Esse vídeo é bloqueado no seu país.'],
    [['http error 404', 'not found', 'does not exist', 'no video'], 'Não achei vídeo nesse link. Confira se ele abre no navegador.'],
    [['video unavailable', 'unavailable', 'has been removed', 'no longer available'], 'Esse vídeo não está disponível: pode ter sido apagado ou estar privado.'],
    [['timed out', 'timeout', 'connection reset', 'temporary failure', 'getaddrinfo', 'network'], 'A internet ou o site demoraram demais. Confira a internet e tente de novo.'],
  ];
  for (const [chaves, msg] of casos) if (chaves.some((c) => b.includes(c))) return new Erro(msg, t);
  if (SITES_QUE_RECUSAM.test(link)) return new Erro(RECUSOU, t);
  return new Erro('Não consegui pegar esse vídeo. Confira se o link abre no navegador e se o vídeo é público.', t);
}

// ===================================================================== a busca: o que tem no link
function limparLink(texto) {
  // aceita o link colado com texto em volta, como vem do "compartilhar" do celular
  const m = String(texto || '').match(/https?:\/\/[^\s<>"']+/);
  if (!m) throw new Erro('Cole o link do vídeo, começando com https://');
  return m[0].replace(/[.,;:!?)\]}]+$/, '');
}

const PADRAO = [144, 240, 360, 480, 720, 1080, 1440, 2160, 4320];
const NOMES = { 4320: '8K', 2160: '4K', 1440: '2K', 1080: 'Full HD', 720: 'HD' };
const tem = (c) => c != null && c !== '' && c !== 'none';

function familia(vcodec) {
  const v = String(vcodec || '').toLowerCase();
  if (/^(avc|h264)/.test(v)) return ['H.264', true];
  if (/^(hev|hvc|h265|hevc|bytevc1)/.test(v)) return ['H.265', true];
  if (/^(vp09|vp9)/.test(v)) return ['VP9', false];
  if (/^vp8/.test(v)) return ['VP8', false];
  if (/^av01/.test(v)) return ['AV1', false];
  return [(v.split('.')[0] || '?').toUpperCase(), false];
}

function nivel(f) {
  // O YouTube diz a qualidade no format_note ("1080p60"), até nos cortes estranhos (608x1080 é o "480p" dele)
  const m = /^(\d{3,4})p/.exec(f.format_note || '');
  if (m) return Number(m[1]);
  const n = f.width && f.height ? Math.min(f.width, f.height) : (f.height || f.width);
  for (const p of PADRAO) if (Math.abs(n - p) <= p * 0.04) return p;
  return n;
}

function montarOpcoes(info) {
  const dur = info.duration || 0;
  const fmts = (info.formats || []).filter((f) => f.format_id && f.protocol !== 'mhtml' && !f.has_drm);
  const tam = (f) => {
    if (!f) return 0;
    const s = f.filesize || f.filesize_approx;
    if (s) return Math.round(s);
    const t = f.tbr || ((f.vbr || 0) + (f.abr || 0));
    return t && dur ? Math.round(t * 125 * dur) : null;
  };
  const abr = (f) => f.abr || f.tbr || 0;
  // Os áudios: sem as versões de volume comprimido (DRC) e, quando o site diz, só o idioma original
  // (o YouTube põe a dublagem automática em inglês e espanhol junto)
  let audios = fmts.filter((f) => f.vcodec === 'none' && tem(f.acodec));
  const semDrc = audios.filter((f) => !/drc/i.test(`${f.format_id} ${f.format_note || ''}`));
  if (semDrc.length) audios = semDrc;
  if (audios.some((f) => f.language_preference != null)) {
    const pref = Math.max(...audios.map((f) => f.language_preference ?? -1));
    audios = audios.filter((f) => (f.language_preference ?? -1) === pref);
  }
  const maior = (lista, chave) => lista.reduce((a, b) => (!a || chave(b) > chave(a) ? b : a), null);
  const aac = maior(audios.filter((f) => String(f.acodec).startsWith('mp4a')), abr);
  const melhorAudio = maior(audios, abr);
  const juntar = aac || melhorAudio;

  const grupos = new Map();
  for (const f of fmts) {
    if (!tem(f.vcodec) || !(f.height || f.width)) continue;
    const p = nivel(f);
    if (!grupos.has(p)) grupos.set(p, []);
    grupos.get(p).push(f);
  }
  const nota = (f) => {
    const [nome, compat] = familia(f.vcodec);
    return [compat ? 1 : 0, nome === 'H.264' ? 1 : 0, String(f.protocol || '').includes('m3u8') ? 0 : 1,
      tem(f.acodec) && !audios.length ? 1 : 0, Math.round(f.fps || 0), f.tbr || 0];
  };
  const comparar = (a, b) => { const x = nota(a), y = nota(b); for (let i = 0; i < x.length; i++) if (x[i] !== y[i]) return x[i] - y[i]; return 0; };

  const videos = [];
  for (const p of [...grupos.keys()].sort((a, b) => b - a)) {
    const f = grupos.get(p).reduce((a, b) => (comparar(b, a) > 0 ? b : a));
    const junto = tem(f.acodec);
    const a = junto ? null : juntar;
    const tv = tam(f), ta = tam(a);
    const [codec, compativel] = familia(f.vcodec);
    videos.push({
      id: `v${p}`, tipo: 'video', rotulo: `${p}p`, nome: NOMES[p] || '', altura: p, fps: f.fps ? Math.round(f.fps) : null,
      codec, compativel, tamanho: tv != null && ta != null ? tv + ta : null, sem_som: !junto && !a,
      formato: f.format_id + (a ? `+${a.format_id}` : ''),
    });
  }
  if (!videos.length && fmts.some((f) => f.vcodec !== 'none')) {
    // O site não diz a resolução de nada: fica uma opção só, a melhor que tiver
    videos.push({ id: 'v0', tipo: 'video', rotulo: 'Melhor qualidade', nome: '', altura: 0, fps: null, codec: '', compativel: true, tamanho: null, sem_som: false, formato: 'bv*+ba/b' });
  }

  const fonte = melhorAudio || maior(fmts.filter((f) => tem(f.acodec)), abr);
  // A qualidade que a pessoa vê é a do M4A (o YouTube tem um Opus de 138 e um AAC de 130 kbps, que soam igual)
  const kbps = (aac || fonte) ? Math.round(abr(aac || fonte)) || null : null;
  const audiosOp = [];
  if (aac) {
    audiosOp.push({ id: 'a-m4a', tipo: 'audio', rotulo: 'M4A', kbps: Math.round(abr(aac)) || null, tamanho: tam(aac),
      formato: `${aac.format_id}/ba[acodec^=mp4a]/ba/b`, extrair: 'm4a', nota: 'o áudio original, sem converter' });
  } else if (fonte || videos.length) {
    audiosOp.push({ id: 'a-m4a', tipo: 'audio', rotulo: 'M4A', kbps, tamanho: kbps && dur ? Math.round(kbps * 125 * dur) : null,
      formato: fonte ? `${fonte.format_id}/ba/b` : 'ba/b', extrair: 'm4a', nota: 'o áudio do vídeo, sem perder qualidade' });
  }
  if (fonte || videos.length) {
    for (const k of [320, 192, 128]) {
      audiosOp.push({ id: `mp3-${k}`, tipo: 'audio', rotulo: 'MP3', kbps: k, tamanho: dur ? Math.round(k * 125 * dur) : null,
        formato: fonte ? `${fonte.format_id}/ba/b` : 'ba/b', extrair: 'mp3', qualidade: `${k}K`,
        nota: kbps && k > kbps * 1.15 ? `o original tem ${kbps} kbps: não fica melhor, só maior` : '' });
    }
  }
  return { videos, audios: audiosOp, kbps };
}

const SITES = { Youtube: 'YouTube', YoutubeTab: 'YouTube', Instagram: 'Instagram', TikTok: 'TikTok', Twitter: 'X (Twitter)',
  Facebook: 'Facebook', FacebookReel: 'Facebook', Vimeo: 'Vimeo', Reddit: 'Reddit', TwitchVod: 'Twitch', TwitchClips: 'Twitch',
  Pinterest: 'Pinterest', Kwai: 'Kwai', Dailymotion: 'Dailymotion', Soundcloud: 'SoundCloud', Generic: 'Site' };

function tituloDe(info) {
  let t = String(info.title || '').trim();
  const desc = String(info.description || '').trim();
  if (desc && (!t || /^(Video|Vídeo) (by|de) /.test(t))) t = desc.split('\n')[0]; // o Instagram chama tudo de "Video by fulano"
  t = t.replace(/\s+/g, ' ');
  return t.length > 140 ? `${t.slice(0, 140)}…` : t || 'Vídeo';
}

const CHAVES = new Map(); // o que a busca achou, por 2 horas (os links dos sites vencem)

async function buscar(texto) {
  const url = limparLink(texto);
  const bin = await garantirYtdlp();
  const r = await comNovasTentativas(url, () => rodar(bin, [...argsBase(), '-J', '--', url], { tempo: 120000 }));
  if (r.codigo !== 0 || !r.saida.trim()) throw traduzir(r.erro, url);
  let info, lista = false;
  try { info = JSON.parse(r.saida); } catch { throw new Erro('O site respondeu de um jeito estranho. Tente de novo.'); }
  if (info._type === 'playlist') {
    const entradas = (info.entries || []).filter(Boolean);
    if (!entradas.length) throw new Erro('Esse link é de uma lista ou de um canal. Cole o link de um vídeo só.');
    info = entradas[0];
    lista = true;
  }
  if (info.is_live || ['is_live', 'is_upcoming'].includes(info.live_status)) throw new Erro('É uma transmissão ao vivo. Espere ela terminar e tente de novo.');
  const { videos, audios, kbps } = montarOpcoes(info);
  if (!videos.length && !audios.length) throw new Erro('Achei a página, mas não tem vídeo nem áudio pra baixar nela.');
  const site = SITES[info.extractor_key] || info.extractor_key || '';
  const dados = {
    titulo: tituloDe(info), autor: info.uploader || info.channel || '', site, link: info.webpage_url || url,
    duracao: info.duration || null, publicado: info.upload_date ? `${info.upload_date.slice(0, 4)}-${info.upload_date.slice(4, 6)}-${info.upload_date.slice(6, 8)}` : null,
    views: info.view_count ?? null, curtidas: info.like_count ?? null, comentarios: info.comment_count ?? null,
    seguidores: info.channel_follower_count ?? null, descricao: String(info.description || '').slice(0, 3000),
    vertical: !!(info.width && info.height && info.height > info.width),
  };
  const chave = crypto.randomBytes(12).toString('hex');
  for (const [c, v] of CHAVES) if (Date.now() - v.em > 2 * 3600e3) CHAVES.delete(c);
  CHAVES.set(chave, { dados, opcoes: new Map([...videos, ...audios].map((o) => [o.id, o])), em: Date.now() });
  const tirar = (o) => { const { formato, extrair, qualidade, ...resto } = o; return resto; };
  const avisos = [];
  if (lista) avisos.push('Esse link tem mais de um vídeo. Vem só o primeiro: pra outro, cole o link dele.');
  if (site === 'YouTube' && !NODE_OK) avisos.push(`Pro YouTube liberar todas as qualidades, a Máquina precisa do Node 22 ou mais novo (este computador tem o ${process.versions.node}). Peça pra IA: "atualiza o Node pra versão mais nova".`);
  return { chave, ...dados, miniatura: info.thumbnail || null, kbps_audio: kbps, videos: videos.map(tirar), audios: audios.map(tirar), avisos };
}

// ===================================================================== os downloads (um por vez)
const TAREFAS = new Map();
const fila = [];
let rodando = null;
const ATIVOS = ['fila', 'baixando', 'juntando', 'convertendo', 'fotos'];

const slug = (t) => String(t).normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase()
  .replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 60).replace(/-+$/, '') || 'video';
function pastaLivre(base) {
  let id = base;
  for (let i = 2; fs.existsSync(path.join(PASTA, id)) || [...TAREFAS.values()].some((t) => t.id === id && ATIVOS.includes(t.estado)); i++) id = `${base}-${i}`;
  return id;
}

function baixar({ chave, opcao, converter }) {
  const c = CHAVES.get(String(chave || ''));
  if (!c) throw new Erro('A busca venceu. Cole o link de novo.');
  const op = c.opcoes.get(String(opcao || ''));
  if (!op) throw new Erro('Escolha uma das qualidades da lista.');
  const t = {
    id: pastaLivre(slug(c.dados.titulo)), dados: c.dados, opcao: op,
    converter: !!converter && op.tipo === 'video' && !op.compativel,
    estado: 'fila', etapa: 'Na fila', pct: 0, baixado: null, total: null, velocidade: null, falta: null, erro: null, detalhe: null,
    partes: {}, proc: null, cancelada: false, criado: Date.now(),
  };
  TAREFAS.set(t.id, t);
  fila.push(t);
  processar();
  return publico(t);
}

const publico = (t) => ({ id: t.id, titulo: t.dados.titulo, site: t.dados.site, rotulo: t.opcao ? t.opcao.rotulo : '', tipo: t.opcao ? t.opcao.tipo : 'video',
  estado: t.estado, etapa: t.etapa, pct: Math.round(t.pct * 10) / 10, baixado: t.baixado, total: t.total, velocidade: t.velocidade,
  falta: t.falta, erro: t.erro, detalhe: t.detalhe, aviso: t.aviso || null });

function tarefa(id) { const t = TAREFAS.get(String(id)); return t ? publico(t) : null; }
function tarefas() { return [...TAREFAS.values()].filter((t) => ATIVOS.includes(t.estado) || ['erro', 'pronto'].includes(t.estado)).map(publico); }

function cancelar(id) {
  const t = TAREFAS.get(String(id));
  if (!t) return { ok: true };
  t.cancelada = true;
  const i = fila.indexOf(t);
  if (i >= 0) fila.splice(i, 1);
  if (t.proc) try { t.proc.kill(); } catch { /* já tinha parado */ }
  TAREFAS.delete(t.id);
  setTimeout(() => fs.rmSync(path.join(PASTA, t.id), { recursive: true, force: true }), 800);
  return { ok: true };
}

async function processar() {
  if (rodando) return;
  while (fila.length) {
    const t = fila.shift();
    rodando = t;
    try {
      await executar(t);
      if (!t.cancelada) { t.estado = 'pronto'; t.etapa = 'Pronto'; t.pct = 100; setTimeout(() => TAREFAS.delete(t.id), 60000); }
    } catch (e) {
      if (!t.cancelada) {
        t.estado = 'erro'; t.etapa = '';
        t.erro = e instanceof Erro ? e.message : `Deu um erro: ${e.message}`;
        t.detalhe = e.detalhe || '';
        fs.rmSync(path.join(PASTA, t.id), { recursive: true, force: true });
        setTimeout(() => TAREFAS.delete(t.id), 10 * 60000);
      }
    } finally {
      rodando = null;
    }
  }
  atualizarSePrecisar();
}

const num = (x) => { const n = Number(x); return Number.isFinite(n) ? n : null; };
const PROGRESSO = /^@@ (\S+) (\S+) (\S+) (\S+) (\S+) (\S+) (\S+)/;

async function executar(t) {
  const op = t.opcao;
  const dir = path.join(PASTA, t.id);
  fs.mkdirSync(dir, { recursive: true });
  t.estado = 'baixando'; t.etapa = 'Preparando o baixador';
  const bin = await garantirYtdlp((n, total) => { t.etapa = 'Instalando o baixador (só na primeira vez)'; t.pct = total ? (n / total) * 100 : 0; });
  t.etapa = 'Baixando'; t.pct = 0;
  const base = op.tipo === 'video' ? 'video' : 'audio';
  const molde = '@@ %(progress.status)s %(progress.downloaded_bytes)s %(progress.total_bytes)s %(progress.total_bytes_estimate)s %(progress.speed)s %(progress.eta)s %(info.format_id)s';
  const args = [...argsBase(), '--newline', '--progress', '--progress-template', `download:${molde}`, '--concurrent-fragments', '4',
    '--no-mtime', '--no-part', '-o', path.join(dir, `${base}.%(ext)s`),
    '--write-thumbnail', '--convert-thumbnails', 'jpg', '-o', `thumbnail:${path.join(dir, 'capa.%(ext)s')}`];
  if (op.tipo === 'video') {
    args.push('-f', `${op.formato}/bv*+ba/b`, '--merge-output-format', 'mp4');
    if (op.altura) args.push('-S', `res:${op.altura},vcodec:h264,acodec:aac`);
  } else {
    args.push('-f', op.formato, '-x', '--audio-format', op.extrair);
    if (op.qualidade) args.push('--audio-quality', op.qualidade);
  }
  args.push('--', t.dados.link);
  const esperado = op.tamanho || 0;
  const r = await comNovasTentativas(t.dados.link, () => rodar(bin, args, {
    tarefa: t,
    aoLer: (linha) => {
      const m = PROGRESSO.exec(linha);
      if (m) {
        const [, , feito, total, estimado, vel, falta, fid] = m;
        t.partes[fid] = [num(feito) || 0, num(total) || num(estimado) || 0];
        const somaFeito = Object.values(t.partes).reduce((s, p) => s + p[0], 0);
        const somaTotal = Math.max(Object.values(t.partes).reduce((s, p) => s + p[1], 0), esperado);
        t.baixado = Math.round(somaFeito); t.total = somaTotal ? Math.round(somaTotal) : null;
        t.velocidade = num(vel); t.falta = num(falta);
        if (somaTotal) t.pct = Math.min(99, (somaFeito / somaTotal) * 100);
        if (op.tipo === 'video' && op.formato.includes('+')) t.etapa = Object.keys(t.partes).length > 1 ? 'Baixando o áudio' : 'Baixando o vídeo';
      } else if (linha.startsWith('[Merger]')) { t.estado = 'juntando'; t.etapa = 'Juntando o vídeo e o áudio'; }
      else if (linha.startsWith('[ExtractAudio]')) { t.estado = 'convertendo'; t.etapa = op.extrair === 'mp3' ? 'Convertendo pra MP3' : 'Separando o áudio'; }
      else if (/^\[(VideoRemuxer|FixupM3u8|FixupM4a)\]/.test(linha)) { t.estado = 'juntando'; t.etapa = 'Arrumando o arquivo'; }
    },
  }), (espera) => { t.etapa = `O site não respondeu: tentando de novo em ${Math.round(espera / 1000)} s`; t.pct = 0; }, () => !!t.cancelada);
  if (t.cancelada) return;
  if (r.codigo !== 0) throw traduzir(r.erro, t.dados.link);
  const prontos = fs.readdirSync(dir).filter((f) => f.startsWith(`${base}.`) && !/\.(part|ytdl|temp|tmp)$|\.f[\w-]+\.\w+$/.test(f));
  if (!prontos.length) throw new Erro('O site entregou um arquivo vazio. Tente outra qualidade.');
  let arquivo = prontos.sort((a, b) => fs.statSync(path.join(dir, b)).size - fs.statSync(path.join(dir, a)).size)[0];
  if (t.converter) arquivo = (await converterH264(t, dir, arquivo)) || arquivo;
  if (t.cancelada) return;
  const dur = t.dados.duracao || (await duracaoDe(path.join(dir, arquivo)));
  const estudo = {
    id: t.id, ...t.dados, duracao: dur || t.dados.duracao, arquivo, tipo: op.tipo,
    qualidade: op.tipo === 'video' ? `${op.rotulo}${t.converter ? ' (convertido pra H.264)' : op.codec ? ` (${op.codec})` : ''}` : `${op.rotulo}${op.kbps ? ` ${op.kbps} kbps` : ''}`,
    capa: fs.existsSync(path.join(dir, 'capa.jpg')) ? 'capa.jpg' : null, baixado: new Date().toISOString(), transcrever: 'auto',
  };
  if (op.tipo === 'video') {
    t.estado = 'fotos'; t.etapa = 'Tirando as fotos das cenas'; t.pct = 99;
    Object.assign(estudo, await tirarQuadros(dir, arquivo, dur, t.dados.vertical));
  }
  gravarEstudo(estudo);
}

// VP9 e AV1 (o Instagram manda quase tudo assim) não abrem no QuickTime, no iPhone nem em muito editor: refaz em H.264
async function converterH264(t, dir, arquivo) {
  t.estado = 'convertendo'; t.etapa = 'Convertendo pra abrir em qualquer lugar'; t.pct = 0; t.velocidade = t.falta = null;
  const entrada = path.join(dir, arquivo), saida = path.join(dir, 'video-h264.mp4');
  const dur = t.dados.duracao || (await duracaoDe(entrada)) || 0;
  for (const audio of [['-c:a', 'copy'], ['-c:a', 'aac', '-b:a', '192k']]) { // o áudio já é AAC quase sempre: só copia
    const r = await rodar(FFMPEG, ['-hide_banner', '-nostdin', '-y', '-i', entrada, '-map', '0:v:0', '-map', '0:a:0?',
      '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '20', '-pix_fmt', 'yuv420p', ...audio, '-movflags', '+faststart',
      '-progress', 'pipe:1', '-nostats', saida], {
      tarefa: t,
      aoLer: (l) => { const m = /^out_time_us=(\d+)/.exec(l); if (m && dur) t.pct = Math.min(99, (Number(m[1]) / 1e6 / dur) * 100); },
    });
    if (t.cancelada) return null;
    if (r.codigo === 0) {
      fs.rmSync(entrada, { force: true });
      fs.renameSync(saida, path.join(dir, 'video.mp4'));
      return 'video.mp4';
    }
  }
  t.aviso = 'Não deu pra converter: o vídeo ficou no formato original (abre no navegador e no VLC).';
  return null;
}

async function duracaoDe(f) {
  const r = await rodar(FFPROBE, ['-v', 'error', '-show_entries', 'format=duration', '-of', 'csv=p=0', f], { tempo: 30000 });
  return num(r.saida.trim()) || null;
}
async function temImagem(f) {
  const r = await rodar(FFPROBE, ['-v', 'error', '-select_streams', 'v:0', '-show_entries', 'stream=codec_name,width,height,disposition', '-of', 'json', f], { tempo: 30000 });
  try {
    const s = (JSON.parse(r.saida).streams || [])[0];
    return s && !(s.disposition && s.disposition.attached_pic) ? { vertical: s.height > s.width } : null; // capa de MP3 não é vídeo
  } catch { return null; }
}

const mmss = (s) => `${String(Math.floor(s / 60)).padStart(2, '0')}m${String(Math.round(s % 60)).padStart(2, '0')}s`;

// As fotos das cenas: uma a cada 2 s (vídeo curto) com o tempo no nome, e os mosaicos (20 fotos por imagem, em ordem),
// que a IA lê de uma vez só pra ver o ritmo da edição
async function tirarQuadros(dir, arquivo, dur, vertical) {
  const intervalo = !dur || dur <= 180 ? 2 : dur <= 600 ? 5 : Math.ceil(dur / 120);
  const q = path.join(dir, 'quadros');
  fs.rmSync(q, { recursive: true, force: true });
  fs.mkdirSync(q, { recursive: true });
  const entrada = path.join(dir, arquivo);
  await rodar(FFMPEG, ['-hide_banner', '-nostdin', '-y', '-i', entrada, '-vf', `fps=1/${intervalo},scale=480:-2`, '-q:v', '4', path.join(q, '%04d.jpg')], { tempo: 10 * 60000 });
  const fotos = fs.readdirSync(q).filter((f) => /^\d{4}\.jpg$/.test(f)).sort();
  fotos.forEach((f, i) => fs.renameSync(path.join(q, f), path.join(q, `${mmss(i * intervalo)}.jpg`)));
  for (const f of fs.readdirSync(dir)) if (/^mosaico-\d+\.jpg$/.test(f)) fs.rmSync(path.join(dir, f), { force: true });
  await rodar(FFMPEG, ['-hide_banner', '-nostdin', '-y', '-i', entrada, '-vf',
    `fps=1/${intervalo},scale=${vertical ? 216 : 384}:-2,tile=5x4:padding=6:margin=6:color=white`, '-q:v', '4', path.join(dir, 'mosaico-%d.jpg')], { tempo: 10 * 60000 });
  const mosaicos = fs.readdirSync(dir).filter((f) => /^mosaico-\d+\.jpg$/.test(f)).length;
  return { quadros: fotos.length, intervalo, mosaicos };
}

// ===================================================================== a pasta de cada estudo
const caminho = (id, ...p) => path.join(PASTA, id, ...p);
function lerEstudo(id) {
  if (!ID_OK.test(String(id || ''))) return null;
  try { return JSON.parse(fs.readFileSync(caminho(id, 'estudo.json'), 'utf8')); } catch { return null; }
}

const milhar = (n) => (n == null ? '' : Math.round(n).toLocaleString('pt-BR'));
const dataBr = (iso) => { if (!iso) return ''; const [a, m, d] = iso.slice(0, 10).split('-'); return `${d}/${m}/${a}`; };
const relogio = (s) => (s >= 3600 ? `${Math.floor(s / 3600)}:` : '') + `${String(Math.floor((s % 3600) / 60)).padStart(s >= 3600 ? 2 : 1, '0')}:${String(Math.floor(s % 60)).padStart(2, '0')}`;

function gravarEstudo(e) {
  fs.mkdirSync(caminho(e.id), { recursive: true });
  fs.writeFileSync(caminho(e.id, 'estudo.json'), `${JSON.stringify(e, null, 2)}\n`);
  // A ficha em texto, que a IA lê primeiro
  const dias = e.publicado ? Math.max(1, Math.round((Date.now() - Date.parse(e.publicado)) / 864e5)) : null;
  const l = [`# ${e.titulo}`, ''];
  if (e.link) l.push(`- Link: ${e.link}`);
  if (e.autor) l.push(`- Canal: ${e.autor}${e.seguidores ? ` (${milhar(e.seguidores)} seguidores)` : ''}`);
  if (e.site) l.push(`- Site: ${e.site}`);
  if (e.publicado) l.push(`- Publicado em: ${dataBr(e.publicado)}${dias ? ` (há ${dias} ${dias === 1 ? 'dia' : 'dias'})` : ''}`);
  if (e.duracao) l.push(`- Duração: ${relogio(e.duracao)} (${Math.round(e.duracao)} s)`);
  if (e.views != null) {
    const partes = [`Views: ${milhar(e.views)}`];
    if (dias) partes.push(`${milhar(e.views / dias)} por dia desde que saiu`);
    if (e.curtidas != null) partes.push(`curtidas: ${milhar(e.curtidas)}${e.views ? ` (${((e.curtidas / e.views) * 100).toFixed(1).replace('.', ',')}% das views)` : ''}`);
    if (e.comentarios != null) partes.push(`comentários: ${milhar(e.comentarios)}`);
    l.push(`- ${partes.join(' · ')}`);
    // As contas que dizem se é viral de verdade (o passo 1 do viralizar/estudar-copy.md)
    if (e.views && e.seguidores) l.push(`- Views ÷ seguidores do canal: ${vezes(e.views / e.seguidores)} (acima de 3, foi o vídeo que saiu da base do canal)`);
    if (e.views && e.comentarios != null) l.push(`- Comentários a cada mil views: ${(e.comentarios / e.views * 1000).toFixed(1).replace('.', ',')}`);
  }
  l.push(`- Baixado em: ${new Date(e.baixado).toLocaleString('pt-BR', { dateStyle: 'short', timeStyle: 'short' })}${e.qualidade ? `, ${e.qualidade}` : ''}`);
  if (e.descricao) l.push('', '## Descrição (a legenda do post)', '', e.descricao);
  l.push('', '## O que tem nesta pasta', '');
  l.push(`- ${e.arquivo}: o ${e.tipo === 'audio' ? 'áudio' : 'vídeo'}`);
  if (e.capa) l.push('- capa.jpg: a capa (a thumbnail que aparece antes de clicar)');
  if (e.quadros) {
    l.push(`- quadros/: ${e.quadros} fotos, uma a cada ${e.intervalo} s, com o tempo no nome (00m14s.jpg = aos 14 s)`);
    l.push(`- mosaico-1.jpg${e.mosaicos > 1 ? ` a mosaico-${e.mosaicos}.jpg` : ''}: as mesmas fotos, 20 por imagem, em ordem (da esquerda pra direita, de cima pra baixo; cada uma ${e.intervalo} s depois da anterior)`);
  }
  l.push(e.transcricao ? '- transcricao.txt (o texto corrido), transcricao-com-tempos.txt ([00:12] frase) e legenda.srt: tudo que é falado'
    : '- a transcrição ainda não foi feita: ela é feita no painel, em Estudar virais (npm run painel -- --estudar)');
  if (fs.existsSync(caminho(e.id, 'analise.md'))) l.push('- analise.md: o estudo que a IA já fez');
  l.push('', `O caderno de todos os estudos é o estudos/virais-estudados.md: a conclusão deste vídeo vai no bloco "estudos/${e.id}" de lá.`);
  fs.writeFileSync(caminho(e.id, 'info.md'), `${l.join('\n')}\n`);
}

function listar() {
  let pastas = [];
  try { pastas = fs.readdirSync(PASTA, { withFileTypes: true }).filter((d) => d.isDirectory() && ID_OK.test(d.name)).map((d) => d.name); } catch { return []; }
  const lista = pastas.map(lerEstudo).filter(Boolean).filter((e) => !TAREFAS.has(e.id) || !ATIVOS.includes(TAREFAS.get(e.id).estado))
    .map((e) => ({ ...e, analise: fs.existsSync(caminho(e.id, 'analise.md')), descricao: undefined }))
    .sort((a, b) => String(b.baixado).localeCompare(String(a.baixado)));
  try { garantirCaderno(lista); } catch { /* o caderno é um extra: a lista vem mesmo sem ele */ }
  return lista;
}

function apagar(id) {
  if (!ID_OK.test(String(id || ''))) return { ok: false, mensagem: 'Esse estudo não existe.' };
  if (TAREFAS.has(id)) cancelar(id);
  fs.rmSync(caminho(id), { recursive: true, force: true });
  try { tirarDoCaderno(id); } catch { /* o caderno é um extra */ }
  return { ok: true };
}

// ---------- o caderno dos virais (estudos/virais-estudados.md) ----------
// Um bloco por vídeo, que a Máquina põe sozinha, com os números do dia em que baixou. O título do bloco leva
// "estudos/<pasta>", que é como ela acha o bloco depois. A IA troca a linha da Conclusão pela dela e reescreve "O que
// se repete" e "Pra testar no próximo vídeo"; a resposta da IA de chat, colada no painel, faz o mesmo (guardarResposta).
// Apagar o estudo tira o bloco só se ele ainda não tinha conclusão: o que a IA concluiu fica
const CADERNO = path.join(PASTA, 'virais-estudados.md');
const CADERNO_MODELO = path.join(__dirname, 'estudar', 'caderno-em-branco.md');
const GUIA_COPY = path.join(RAIZ, 'viralizar', 'estudar-copy.md');
const SEM_CONCLUSAO = '- **Conclusão:** ainda não estudado.';
const escRe = (s) => String(s).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
const tituloDoBloco = (id) => new RegExp(`^###\\s.*\\bestudos/${escRe(id)}(?![\\w-])`);
const vezes = (n) => `${n >= 10 ? milhar(n) : n.toFixed(1).replace('.', ',').replace(',0', '')}x`;
const lerTexto = (f) => { try { return fs.readFileSync(f, 'utf8'); } catch { return null; } };

function numerosDoEstudo(e) {
  const dias = e.publicado ? Math.max(1, Math.round((Date.parse(e.baixado || Date.now()) - Date.parse(e.publicado)) / 864e5)) : null;
  const p = [e.site || 'Arquivo do computador'];
  if (e.autor) p.push(`${e.autor}${e.seguidores ? ` (${milhar(e.seguidores)} seguidores)` : ''}`);
  if (e.publicado) p.push(`postado em ${dataBr(e.publicado)}`);
  if (e.duracao) p.push(relogio(e.duracao));
  if (e.views != null) p.push(`${milhar(e.views)} views${dias ? ` (${milhar(e.views / dias)} por dia)` : ''}`);
  if (e.views && e.seguidores) p.push(`${vezes(e.views / e.seguidores)} os seguidores`);
  if (e.views && e.curtidas != null) p.push(`${((e.curtidas / e.views) * 100).toFixed(1).replace('.', ',')}% de curtidas`);
  if (e.views && e.comentarios != null) p.push(`${milhar(e.comentarios)} comentários`);
  if (e.baixado) p.push(`números de ${dataBr(new Date(e.baixado).toISOString())}`);
  return p.join(' · ');
}

function blocoNovo(e) {
  const l = [`### ${String(e.titulo || e.id).replace(/\s+/g, ' ').trim()} · estudos/${e.id}`, `- ${numerosDoEstudo(e)}`];
  if (e.link) l.push(`- Link: ${e.link}`);
  l.push(`${SEM_CONCLUSAO} Peça pra IA: "Estuda o viral da pasta estudos/${e.id}".`);
  return l.join('\n');
}

// O caderno existe (quando já tem a pasta estudos/) e tem um bloco pra cada estudo, até os que vieram antes dele
function garantirCaderno(estudos) {
  if (!fs.existsSync(PASTA)) return null;
  let txt = lerTexto(CADERNO);
  const novo = txt == null;
  if (novo) txt = lerTexto(CADERNO_MODELO) || '# Virais estudados\n\n## Os vídeos\n';
  const faltam = (estudos || []).filter((e) => !txt.split('\n').some((l) => tituloDoBloco(e.id).test(l)))
    .sort((a, b) => String(a.baixado).localeCompare(String(b.baixado)));
  if (!novo && !faltam.length) return txt;
  txt = `${txt.replace(/\s*$/, '\n')}${faltam.map((e) => `\n${blocoNovo(e)}\n`).join('')}`;
  fs.writeFileSync(CADERNO, txt);
  return txt;
}

// Onde começa e termina o bloco de um estudo no caderno (as linhas), ou null
function acharBloco(L, id) {
  const ini = L.findIndex((l) => tituloDoBloco(id).test(l));
  if (ini < 0) return null;
  let fim = ini + 1;
  while (fim < L.length && !/^#{2,3}\s/.test(L[fim])) fim++;
  return { ini, fim };
}

function tirarDoCaderno(id) {
  const txt = lerTexto(CADERNO);
  if (!txt) return;
  const L = txt.split('\n'), b = acharBloco(L, id);
  if (!b) return;
  const corpo = L.slice(b.ini, b.fim);
  if (corpo.some((l) => l.startsWith(SEM_CONCLUSAO))) L.splice(b.ini, b.fim - b.ini);
  else if (!corpo.some((l) => /vídeo foi apagado/.test(l))) L.splice(b.fim, 0, `- (o vídeo foi apagado da pasta em ${dataBr(new Date().toISOString())}; a conclusão ficou)`);
  fs.writeFileSync(CADERNO, `${L.join('\n').replace(/\n{3,}/g, '\n\n').replace(/\s*$/, '')}\n`);
}

// As partes da resposta da IA (o formato do viralizar/estudar-copy.md). Aceita o texto com os ## ou sem eles (quem
// copia do chat às vezes leva só o texto): um título é uma linha com # ou uma linha curta com o nome de uma das partes
const PARTES = ['conclusão', 'os números', 'o gancho', 'a promessa e os laços', 'a promessa', 'os laços abertos', 'a estrutura',
  'as frases', 'a emoção', 'o fim e o pedido', 'o texto em volta', 'o que se repete', 'pra testar no próximo vídeo', 'pra testar'];
const nomeDaLinha = (l) => l.replace(/^\s*#{1,4}\s*/, '').replace(/\*\*/g, '').replace(/^\s*\d+[.)]\s*/, '').replace(/\s*[:：]\s*$/, '').trim().toLowerCase();
const eTitulo = (l) => /^\s*#{1,4}\s+\S/.test(l) || (l.trim().length < 70 && PARTES.some((p) => nomeDaLinha(l) === p || nomeDaLinha(l).startsWith(`${p} (`)));
function parteDa(texto, nome) {
  const L = String(texto).replace(/\r/g, '').split('\n');
  const i = L.findIndex((l) => eTitulo(l) && nomeDaLinha(l).startsWith(nome));
  if (i < 0) return null;
  const itens = [];
  for (let j = i + 1; j < L.length && !eTitulo(L[j]); j++) {
    const l = L[j].trim();
    if (!l || l.startsWith('>') || l.startsWith('```')) continue;
    itens.push(`- ${l.replace(/^([-*•]|\d+[.)])\s+/, '').slice(0, 700)}`);
  }
  return itens.length && !/^- \(?nada/i.test(itens[0]) ? itens : null;
}

function trocarConclusao(txt, e, linhas) {
  const L = txt.split('\n');
  let b = acharBloco(L, e.id);
  if (!b) { L.push('', ...blocoNovo(e).split('\n')); b = acharBloco(L, e.id); }
  // Ficam o título, a linha dos números e a do link (as da Máquina); o resto do bloco vira a conclusão nova
  let k = b.ini + 1;
  if (k < b.fim && /^- (?!\*\*)/.test(L[k]) && !/^- Link:/.test(L[k])) k++;
  if (k < b.fim && /^- Link:/.test(L[k])) k++;
  L.splice(k, b.fim - k, ...linhas, '');
  return L.join('\n').replace(/\n{3,}/g, '\n\n');
}

function trocarParte(txt, nome, linhas) {
  const L = txt.split('\n');
  const i = L.findIndex((l) => /^##\s/.test(l) && l.replace(/^##\s+/, '').trim().toLowerCase().startsWith(nome));
  if (i < 0) return txt;
  let fim = i + 1;
  while (fim < L.length && !/^##\s/.test(L[fim])) fim++;
  let k = i + 1;
  while (k < fim && (L[k].startsWith('>') || !L[k].trim())) k++; // a nota "Pra IA" fica
  L.splice(k, fim - k, ...linhas.slice(0, 25), '');
  return L.join('\n').replace(/\n{3,}/g, '\n\n');
}

// A resposta da IA de chat, colada no painel em "Guardar a resposta da IA": vira o analise.md do estudo, a Conclusão
// vai pro bloco dele no caderno, e o "O que se repete" e o "Pra testar no próximo vídeo", se vierem, trocam os do caderno
function guardarResposta(d) {
  const e = lerEstudo(d && d.id);
  if (!e) return { ok: false, mensagem: 'Esse estudo não existe mais.' };
  const texto = String((d && d.texto) || '').replace(/\r/g, '').trim();
  if (texto.length < 80) return { ok: false, mensagem: 'Cole a resposta inteira da IA: essa veio curta demais.' };
  if (texto.length > 300000) return { ok: false, mensagem: 'Essa resposta é grande demais. Cole só o estudo deste vídeo.' };
  fs.writeFileSync(caminho(e.id, 'analise.md'), `${texto}\n`);
  gravarEstudo(e); // o info.md passa a citar o analise.md
  let conclusao = parteDa(texto, 'conclusão');
  const noFormato = !!conclusao;
  if (!conclusao) {
    conclusao = texto.split('\n').map((l) => l.trim()).filter((l) => l && !l.startsWith('#') && !l.startsWith('```')).slice(0, 6)
      .map((l) => `- ${l.replace(/^([-*•]|\d+[.)])\s+/, '').slice(0, 700)}`);
    conclusao.push(`- (a IA não escreveu no formato do guia: o estudo inteiro está em estudos/${e.id}/analise.md)`);
  }
  let txt = garantirCaderno([e]) || lerTexto(CADERNO_MODELO) || '';
  txt = trocarConclusao(txt, e, conclusao.slice(0, 13));
  const repete = parteDa(texto, 'o que se repete'), testar = parteDa(texto, 'pra testar');
  if (repete) txt = trocarParte(txt, 'o que se repete', repete);
  if (testar) txt = trocarParte(txt, 'pra testar', testar);
  fs.writeFileSync(CADERNO, `${txt.replace(/\s*$/, '')}\n`);
  return { ok: true, noFormato, repete: !!repete, testar: !!testar };
}

// O caderno inteiro (pro painel) e o resumo dele (pro pedido da IA de chat: o que se repete, o teste e uma linha por vídeo)
function caderno() {
  listar(); // põe no caderno os estudos que ainda não estão lá
  const txt = lerTexto(CADERNO);
  return { ok: true, existe: !!txt, texto: txt || '', arquivo: 'estudos/virais-estudados.md' };
}
function resumoCaderno() {
  const txt = lerTexto(CADERNO);
  if (!txt) return '';
  const L = txt.split('\n'), videos = [];
  L.forEach((l, i) => {
    const m = l.match(/^###\s+(.*?)\s+·\s+estudos\/([a-z0-9-]+)\s*$/);
    if (!m) return;
    let por = '';
    for (let j = i + 1; j < L.length && !/^#{2,3}\s/.test(L[j]) && !por; j++) {
      const x = L[j].match(/^- \*\*Por que viralizou:?\*\*:?\s*(.*)/i);
      if (x) por = x[1];
    }
    videos.push(`- ${m[1]}: ${por || '(ainda não estudado)'}`);
  });
  if (!videos.length) return '';
  const repete = parteDa(txt, 'o que se repete'), testar = parteDa(txt, 'pra testar');
  return [repete && ['O que se repete:', ...repete].join('\n'), testar && ['Pra testar no próximo vídeo:', ...testar].join('\n'),
    ['Os vídeos que eu já estudei:', ...videos].join('\n')].filter(Boolean).join('\n\n');
}

// O som em 16 mil amostras por segundo, um canal, em números (Float32): é o que o Whisper do navegador ouve
function audioPcm(id, res) {
  const e = lerEstudo(id);
  if (!e || !fs.existsSync(caminho(id, e.arquivo))) { res.writeHead(404); return res.end(); }
  const p = spawn(FFMPEG, ['-hide_banner', '-nostdin', '-v', 'error', '-i', caminho(id, e.arquivo), '-vn', '-ac', '1', '-ar', '16000', '-f', 'f32le', 'pipe:1'], { windowsHide: true });
  res.writeHead(200, { 'Content-Type': 'application/octet-stream', 'Cache-Control': 'no-store' });
  p.stdout.pipe(res);
  p.on('error', () => res.end());
  res.on('close', () => { try { p.kill(); } catch { /* já acabou */ } });
}

// ---------- a transcrição (feita no navegador; aqui só grava) ----------
function paragrafos(segs) {
  const r = [];
  let atual = '', fimAnterior = null;
  for (const s of segs) {
    const t = s.texto.trim();
    if (!t) continue;
    const pausa = fimAnterior !== null && s.ini - fimAnterior > 1.5;
    const grande = atual.length > 650 && /[.!?…]["”»)]?$/.test(atual);
    if (atual && (pausa || grande)) { r.push(atual); atual = ''; }
    atual = atual ? `${atual} ${t}` : t;
    fimAnterior = s.fim;
  }
  if (atual) r.push(atual);
  return r.join('\n\n');
}
function hora(seg, { horas = false, ms = false } = {}) {
  const t = Math.max(0, seg), h = Math.floor(t / 3600), m = Math.floor((t % 3600) / 60), s = Math.floor(t % 60);
  const dd = (n) => String(n).padStart(2, '0');
  return (horas || h ? `${dd(h)}:` : '') + `${dd(m)}:${dd(s)}` + (ms ? `,${String(Math.floor((t * 1000) % 1000)).padStart(3, '0')}` : '');
}
function srt(segs) {
  return segs.filter((s) => s.texto.trim()).map((s, i) => `${i + 1}\n${hora(s.ini, { horas: true, ms: true })} --> ${hora(Math.max(s.fim, s.ini + 0.3), { horas: true, ms: true })}\n${s.texto.trim()}\n`).join('\n');
}

function salvarTranscricao(d) {
  const e = lerEstudo(d && d.id);
  if (!e) return { ok: false, mensagem: 'Esse estudo não existe mais.' };
  const segs = (Array.isArray(d.segmentos) ? d.segmentos : []).slice(0, 20000)
    .map((s) => ({ ini: Number(s.ini) || 0, fim: Number(s.fim) || 0, texto: String(s.texto || '').slice(0, 2000) }))
    .filter((s) => s.texto.trim());
  const horas = segs.length && segs[segs.length - 1].fim >= 3600;
  fs.writeFileSync(caminho(e.id, 'transcricao.txt'), `${paragrafos(segs)}\n`);
  fs.writeFileSync(caminho(e.id, 'transcricao-com-tempos.txt'), `${segs.map((s) => `[${hora(s.ini, { horas })}] ${s.texto.trim()}`).join('\n')}\n`);
  fs.writeFileSync(caminho(e.id, 'legenda.srt'), srt(segs));
  const palavras = segs.reduce((n, s) => n + s.texto.trim().split(/\s+/).length, 0);
  e.transcricao = { modelo: String(d.modelo || ''), idioma: String(d.idioma || ''), palavras, em: new Date().toISOString(),
    palavras_por_minuto: e.duracao ? Math.round(palavras / (e.duracao / 60)) : null };
  delete e.transcrever;
  gravarEstudo(e);
  return { ok: true, estudo: e };
}

function textos(id) {
  const e = lerEstudo(id);
  if (!e) return { ok: false, mensagem: 'Esse estudo não existe mais.' };
  const ler = (f) => { try { return fs.readFileSync(caminho(id, f), 'utf8'); } catch { return ''; } };
  return { ok: true, info: ler('info.md'), tempos: ler('transcricao-com-tempos.txt'), texto: ler('transcricao.txt'), analise: ler('analise.md'),
    guia: lerTexto(GUIA_COPY) || '', caderno: resumoCaderno() };
}

// ---------- um arquivo do computador da pessoa ----------
const EXT_OK = /\.(mp4|mov|m4v|mkv|webm|avi|wmv|flv|3gp|mp3|m4a|wav|aac|flac|ogg|oga|opus|wma|amr|caf)$/i;
async function receberArquivo(req, nome) {
  nome = path.basename(String(nome || 'arquivo')).slice(0, 160);
  const ext = (path.extname(nome) || '').toLowerCase();
  if (!EXT_OK.test(ext)) return { ok: false, mensagem: 'Esse arquivo não é de áudio nem de vídeo.' };
  const titulo = nome.slice(0, -ext.length) || 'arquivo';
  const id = pastaLivre(slug(titulo));
  fs.mkdirSync(caminho(id), { recursive: true });
  const tmp = caminho(id, `recebendo${ext}`);
  const ok = await new Promise((fim) => {
    const s = fs.createWriteStream(tmp);
    req.pipe(s);
    s.on('finish', () => fim(true));
    s.on('error', () => fim(false));
    req.on('aborted', () => fim(false));
  });
  if (!ok || !fs.existsSync(tmp) || !fs.statSync(tmp).size) { fs.rmSync(caminho(id), { recursive: true, force: true }); return { ok: false, mensagem: 'O arquivo não chegou inteiro. Tente de novo.' }; }
  const imagem = await temImagem(tmp);
  const arquivo = `${imagem ? 'video' : 'audio'}${ext}`;
  fs.renameSync(tmp, caminho(id, arquivo));
  const dur = await duracaoDe(caminho(id, arquivo));
  const e = { id, titulo, autor: '', site: 'Arquivo do computador', link: null, duracao: dur, arquivo, tipo: imagem ? 'video' : 'audio', vertical: imagem ? imagem.vertical : null,
    qualidade: '', capa: null, baixado: new Date().toISOString(), transcrever: 'auto' };
  if (imagem) Object.assign(e, await tirarQuadros(caminho(id), arquivo, dur, imagem.vertical));
  gravarEstudo(e);
  return { ok: true, estudo: e };
}

module.exports = { PASTA, CADERNO, NODE_OK, estadoBaixador, preparar, buscar, baixar, tarefa, tarefas, cancelar, listar, apagar, audioPcm, salvarTranscricao, textos, receberArquivo, lerEstudo,
  caderno, guardarResposta, resumoCaderno, Erro,
  // as Conquistas (motor/conquistas.js) leem o YouTube da pessoa com o mesmo yt-dlp
  garantirYtdlp, rodar, atualizarSePrecisar };

// ===================================================================== na linha de comando
if (require.main === module) {
  (async () => {
    const args = process.argv.slice(2);
    if (args.includes('--lista')) {
      const l = listar();
      if (!l.length) return console.log('Ainda não tem nenhum estudo em estudos/.');
      for (const e of l) console.log(`estudos/${e.id}  ${e.site} · ${e.titulo}${e.views != null ? ` · ${milhar(e.views)} views` : ''}${e.transcricao ? ' · transcrito' : ' · sem transcrição'}${e.analise ? ' · estudado' : ''}`);
      return;
    }
    const link = args.find((a) => /https?:\/\//.test(a));
    if (!link) return console.log('Uso: npm run estudar -- "<link do vídeo>" [--audio]   ou   npm run estudar -- --lista');
    console.log('Procurando o vídeo...');
    const info = await buscar(link);
    for (const a of info.avisos) console.log(`Atenção: ${a}`);
    const bons = info.videos.filter((o) => o.compativel && (!o.altura || o.altura <= 1080));
    const op = args.includes('--audio') || !info.videos.length ? info.audios.find((o) => o.id === 'a-m4a') || info.audios[0] : bons[0] || info.videos[0];
    console.log(`${info.site} · ${info.titulo}${info.views != null ? ` · ${milhar(info.views)} views` : ''}\nBaixando: ${op.rotulo}${op.codec ? ` (${op.codec})` : ''}`);
    const t = baixar({ chave: info.chave, opcao: op.id, converter: true });
    let ultima = '';
    for (;;) {
      await new Promise((r) => setTimeout(r, 700));
      const x = tarefa(t.id);
      if (!x) break;
      const linha = `${x.etapa} ${Math.floor(x.pct)}%`;
      if (linha !== ultima && (x.estado !== 'baixando' || Math.floor(x.pct) % 10 === 0)) { console.log(`  ${linha}`); ultima = linha; }
      if (x.estado === 'erro') { console.log(`Não deu: ${x.erro}${x.detalhe ? `\n(${x.detalhe})` : ''}`); process.exitCode = 1; return; }
      if (x.estado === 'pronto') break;
    }
    const e = lerEstudo(t.id);
    console.log(`\nPronto: estudos/${t.id}/ (${e.arquivo}${e.quadros ? `, ${e.quadros} fotos das cenas e ${e.mosaicos} mosaico(s)` : ''}).`);
    console.log('Falta a transcrição, que é feita no painel: npm run painel -- --estudar (ela começa sozinha lá).');
  })().catch((e) => { console.log(`Não deu: ${e.message}${e.detalhe ? `\n(${e.detalhe})` : ''}`); process.exitCode = 1; });
}
