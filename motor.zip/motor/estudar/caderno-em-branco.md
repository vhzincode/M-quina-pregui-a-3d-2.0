# Virais estudados

> O caderno de tudo que você estudou no menu **Estudar virais**: cada vídeo, o que a IA concluiu dele, o que se repete
> entre eles e o próximo teste. A Máquina põe cada vídeo novo aqui sozinha, com os números; a IA escreve a conclusão
> quando estuda (o jeito está em `viralizar/estudar-copy.md`). Pode abrir e editar quando quiser. Apagar o vídeo no
> painel não apaga o que está aqui.

## O que se repete

> Pra IA: o que aparece em mais de um vídeo. Reescreva esta parte a cada vídeo estudado.
> Formato: `- o padrão, curto (em quais vídeos) · pista, padrão ou regra`
> Pista: 1 ou 2 vídeos. Padrão: 3 ou mais, de canais diferentes. Regra: testado no canal e deu número (vai também pro
> `canal/aprendizados.md`, com o OK da pessoa).

- (nada ainda: estude pelo menos 2 vídeos)

## Pra testar no próximo vídeo

> Pra IA: um teste por vez, o padrão mais forte que o canal ainda não usa, e o número que vai dizer se deu certo.
> Formato: `- o que testar · em qual vídeo · o número que decide · resultado: (esperando)`

- (nada ainda)

## Os vídeos

> Pra IA: um bloco por vídeo, na ordem em que entraram. Não mude a linha do título (a que tem `estudos/<pasta>`) nem
> as linhas dos números e do link: a Máquina usa. Troque só a linha da Conclusão pelas linhas da sua Conclusão.
