# O que vem de fora no Estudar virais

- `transformers.min.js`: o [Transformers.js](https://github.com/huggingface/transformers.js) 4.3.1, do Hugging Face
  (licença Apache 2.0), sem mudança nenhuma. Roda o Whisper no navegador.
- O motor ONNX Runtime Web 1.31.0-dev.20260914 (Microsoft, licença MIT) não vem no zip: o navegador baixa do jsDelivr na
  primeira transcrição e guarda (`whisper.worker.js` diz a versão).
- Os modelos [Whisper](https://github.com/openai/whisper) (OpenAI, licença MIT), convertidos pela comunidade ONNX do
  Hugging Face: o navegador baixa do Hugging Face na primeira transcrição e guarda.
- O [yt-dlp](https://github.com/yt-dlp/yt-dlp) (Unlicense, domínio público) também não vem no zip: o `motor/estudar.js`
  baixa a versão oficial do GitHub na primeira vez, pra `.ferramentas/`, e confere a soma SHA-256 publicada junto.
- O `whisper.worker.js` é nosso: veio do Preguiça Transcreve, das Ferramentas da Preguiça.
