// A revisão do roteiro e da ficha de cena, antes de qualquer código: npm run roteiro -- <tema>
//
// Lê videos/<tema>/roteiro.md e confere o que a IA mais esquece (o formato é o de referencias/modelo-construcao/roteiro.md):
//   - no roteiro: o gancho é uma pergunta, o tamanho, frase longa demais, os "Mas", os "É por isso que", o número, o
//     fechamento do canal, um pedido só no fim, as palavras que o método proíbe e o roteiro do modelo esquecido ali
//   - na ficha: o cenário, a tabela dos objetos, o teste dos substantivos e, em cada frase, o bloco com as 10 linhas
//     escritas por extenso, o personagem com duas ações (nunca parado), a câmera diferente da frase anterior e o
//     "mostra" com nomes que estão na tabela dos objetos
// Termina com RESULTADO: APROVADO ou CORRIGIR e a linha PRA IA. A revisão das cenas (render --revisar) roda esta também
// e não deixa o vídeo completo sair com o roteiro.md pra corrigir.
const fs = require('fs');
const path = require('path');

const RAIZ = path.join(__dirname, '..');
const lerArq = (f) => { try { return fs.readFileSync(f, 'utf8').replace(/^﻿/, '').replace(/\r/g, ''); } catch { return null; } };
const semAcento = (t) => String(t || '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase();
const palavras = (t) => String(t || '').replace(/[*_`"“”]/g, '').split(/\s+/).filter((w) => /[\p{L}\p{N}]/u.test(w));

const ROTULOS = [
  ['NA TELA', 'na tela'], ['MOSTRA', 'mostra'], ['CENÁRIO', 'cenario'], ['ENTRA AGORA', 'entra agora'],
  ['OBJETOS SE MEXENDO', 'objetos se mexendo'], ['PERSONAGEM', 'personagem'], ['INTERAÇÃO', 'interacao'],
  ['CÂMERA', 'camera'], ['EFEITOS VISUAIS', 'efeitos visuais'], ['SONS', 'sons']
];
// O mínimo de palavras das linhas que fazem a cena (a IA fraca escreve uma frase curta e a cena sai pobre)
const MINIMO = { 'na tela': 8, personagem: 6, camera: 6, interacao: 4, 'objetos se mexendo': 3 };
const MOVIMENTOS = ['chegando', 'afastando', 'girando', 'subindo', 'descendo', 'passando', 'parado', 'mergulho', 'revelando'];
const PLANOS = ['aberto', 'medio', 'perto', 'detalhe'];
const PROIBIDAS = ['basicamente', 'e importante ressaltar', 'voce sabia que', 'fala galera', 'neste video', 'nesse video vamos', 'vamos juntos', 'kkk', 'hahaha'];
const PEDIDOS = /\b(segue|siga|seguir|comenta|comente|curte|curta|compartilha|compartilhe|manda pra|link na bio|inscreve|inscreva)\b/;
const GANCHO_DO_MODELO = 'por que todo predio tem ferro escondido dentro do concreto';

// O texto de uma seção "## Título" (até o próximo "## ")
function secao(txt, titulo) {
  const L = txt.split('\n');
  const i = L.findIndex((l) => /^##\s/.test(l) && semAcento(l.replace(/^##\s+/, '')).startsWith(semAcento(titulo)));
  if (i < 0) return null;
  let j = i + 1;
  while (j < L.length && !/^##\s/.test(L[j])) j++;
  return L.slice(i + 1, j).join('\n');
}
// As frases numeradas do "## Roteiro", sem as marcas (*negrito*, *(gancho)*)
function frasesDoRoteiro(txt) {
  const s = secao(txt, 'Roteiro');
  if (s == null) return null;
  const r = [];
  for (const l of s.split('\n')) {
    const m = l.match(/^\s*(\d{1,3})[.)]\s+(.+?)\s*$/);
    if (!m) continue;
    const texto = m[2].replace(/\*\((gancho|cauda|fim)[^)]*\)\*/gi, '').replace(/\*\*?([^*]+)\*\*?/g, '$1').replace(/~([^~]+)~/g, '$1').trim();
    r.push({ n: Number(m[1]), texto });
  }
  return r;
}
// Os nomes da 1ª coluna de uma tabela markdown (só os que estão entre crases, ou a célula inteira)
function tabela(trecho) {
  const linhas = String(trecho || '').split('\n').filter((l) => /^\s*\|/.test(l) && !/^\s*\|\s*-{2,}/.test(l));
  return linhas.slice(1).map((l) => l.split('|').map((c) => c.trim()).filter((_, i, a) => i > 0 && i < a.length - 1));
}
// Os nomes da linha MOSTRA: `["coluna", "personagem"]` (com ou sem crase), ou "coluna, personagem"
function nomesDoMostra(v) {
  const t = String(v || '').replace(/`/g, '').trim();
  const lista = t.match(/\[[^\]]*\]/);
  if (lista) {
    try { const a = JSON.parse(lista[0]); if (Array.isArray(a)) return a.map((s) => String(s).trim()).filter(Boolean); } catch { /* sem aspas: vai pela vírgula */ }
    return lista[0].slice(1, -1).split(',').map((s) => s.replace(/["']/g, '').trim()).filter(Boolean);
  }
  const aspas = t.match(/"([^"]+)"/g);
  if (aspas) return aspas.map((s) => s.slice(1, -1).trim()).filter(Boolean);
  return t.split(/,|\be\b/).map((s) => s.replace(/[."']/g, '').trim()).filter((s) => s && s.split(/\s+/).length <= 3);
}
const nomesDaCelula = (c) => { const m = String(c).match(/`([^`]+)`/g); return m ? m.map((x) => x.slice(1, -1).trim()) : String(c).split(/,\s*/).map((x) => x.trim()).filter(Boolean); };
// Os blocos "#### N · plano `nome` · ~X s", cada um com a frase e as linhas "- **RÓTULO:** texto"
function blocos(ficha) {
  const L = ficha.split('\n'), r = [];
  let atual = null, rotulo = null;
  for (const l of L) {
    const cab = l.match(/^####\s+(\d{1,3})\b(.*)$/);
    if (cab) {
      atual = { n: Number(cab[1]), plano: ((cab[2].match(/`([^`]+)`/) || [])[1] || ''), frase: '', linhas: {} };
      r.push(atual); rotulo = null; continue;
    }
    if (!atual) continue;
    if (/^#{1,3}\s/.test(l)) { atual = null; continue; }
    const q = l.match(/^>\s*"?(.+?)"?\s*$/);
    if (q && !atual.frase) { atual.frase = q[1]; continue; }
    const m = l.match(/^\s*[-*]\s+\*\*([^*:]+?):?\*\*:?\s*(.*)$/);
    if (m) { rotulo = semAcento(m[1]).trim(); atual.linhas[rotulo] = m[2].trim(); continue; }
    if (rotulo && /^\s{2,}\S/.test(l)) atual.linhas[rotulo] += ' ' + l.trim();
    else if (!l.trim()) rotulo = null;
  }
  return r;
}

function conferir(pasta) {
  const arq = path.join(pasta, 'roteiro.md');
  const txt = lerArq(arq);
  const out = { existe: txt != null, temFicha: false, corrigir: [], conferir: [], porFrase: {}, frases: 0, palavras: 0 };
  if (txt == null) { out.corrigir.push(`não achei o ${path.relative(RAIZ, arq)}: escreva o roteiro e a ficha de cena nele (npm run guia -- roteiro)`); return out; }
  const pf = (n) => (out.porFrase[n] = out.porFrase[n] || { corrigir: [], conferir: [] });

  // ---------- o roteiro ----------
  const frases = frasesDoRoteiro(txt);
  if (!frases || !frases.length) {
    out.corrigir.push('não achei as frases do roteiro: a seção "## Roteiro" com uma frase por linha numerada (1. a pergunta do gancho, 2., 3., ...), como em referencias/modelo-construcao/roteiro.md');
  } else {
    out.frases = frases.length;
    const total = frases.reduce((n, f) => n + palavras(f.texto).length, 0);
    out.palavras = total;
    const doCanal = lerArq(path.join(RAIZ, 'canal', 'metodo.md')) || '';
    const tamanhoDoCanal = /^##\s+Tamanho/m.test(doCanal);
    const tam = (msg) => (tamanhoDoCanal ? out.conferir : out.corrigir).push(msg);
    if (semAcento(frases[0].texto).includes(GANCHO_DO_MODELO)) out.corrigir.push('o roteiro ainda é o do modelo (o concreto armado): escreva o roteiro do tema deste vídeo');
    if (total < 150) tam(`o roteiro está curto demais (${total} palavras): o mínimo é 150 (uns 50 segundos); o vídeo pra crescer tem de 220 a 550 (metodo/formula-roteiro.md, "Tamanho")`);
    if (total > 560) tam(`o roteiro está longo demais (${total} palavras): com mais de 550, o vídeo passa de 3:00 e o YouTube Shorts corta (metodo/formula-roteiro.md, "Tamanho")`);
    if (!/\?\s*$/.test(frases[0].texto)) out.corrigir.push(`a 1ª frase é o gancho e tem que ser uma pergunta curiosa, terminando com "?" (agora: "${frases[0].texto}")`);
    else if (palavras(frases[0].texto).length > 14) out.conferir.push(`o gancho tem ${palavras(frases[0].texto).length} palavras: a pergunta que prende é curta, de até uns 10 (dica 2 de viralizar/dicas.md)`);
    const longas = frases.filter((f) => palavras(f.texto).length > 15);
    if (longas.length > 4) out.conferir.push(`${longas.length} frases com mais de 15 palavras (o máximo é 4: a legenda entra palavra por palavra). Quebre as frases ${longas.map((f) => f.n).join(', ')}`);
    frases.filter((f) => palavras(f.texto).length > 28).forEach((f) => pf(f.n).corrigir.push(`frase longa demais (${palavras(f.texto).length} palavras): quebre em duas`));
    const comeca = (re) => frases.filter((f) => re.test(semAcento(f.texto))).length;
    if (comeca(/^mas\b/) < 2) out.conferir.push('menos de 2 frases começando com "Mas" (o problema que dá pra ver quebrando): cada ciclo é "Mas..." → "Então você..." → "Esse é o..."');
    if (comeca(/\be por isso que\b/) < 2) out.conferir.push('menos de 2 "É por isso que..." (o detalhe da vida real que todo mundo já reparou): o Checklist pede pelo menos 2');
    if (!frases.some((f) => /\d|\b(dez|vinte|trinta|cem|cento|mil|milhao|milhoes|metade|dobro|triplo|vezes|graus|metros|quilos|litros|por cento)\b/.test(semAcento(f.texto)))) out.conferir.push('nenhum número concreto no roteiro: o Checklist pede pelo menos 1 ("um chuveiro puxa o mesmo que 600 lâmpadas")');
    // o fechamento do canal: se é o da Máquina ("Coloque... Agora é só..."), ele tem que estar perto do fim
    const canal = semAcento(lerArq(path.join(RAIZ, 'canal', 'canal.md')) || '');
    const fech = (canal.match(/\*\*fechamento:\*\*\s*(.*)/) || [])[1] || '';
    const fechPadrao = !fech.trim() || /\[ex:/.test(fech) || /^"?coloque/.test(fech.trim());
    const fim = frases.slice(-6).map((f) => semAcento(f.texto));
    if (fechPadrao && frases.length >= 8) {
      if (!fim.some((t) => /^coloque\b/.test(t))) out.conferir.push('o fechamento do canal começa com "Coloque [2 ou 3 detalhes, o último com uma piada]." perto do fim, e não achei (canal/canal.md, "Fechamento")');
      if (!fim.some((t) => /\bagora e so\b/.test(t))) out.conferir.push('falta o "Agora é só [usar]." do fechamento, perto do fim');
    }
    const pedidos = frases.slice(-3).filter((f) => PEDIDOS.test(semAcento(f.texto))).length;
    if (pedidos > 1) out.conferir.push(`${pedidos} pedidos nas últimas frases (seguir, comentar, compartilhar...): um pedido só no fim, curto (metodo/formula-roteiro.md, "O pedido do fim")`);
    for (const f of frases) {
      const t = semAcento(f.texto);
      const achou = PROIBIDAS.find((p) => t.includes(p));
      if (achou) pf(f.n).conferir.push(`"${achou}" está na lista do que não se fala (metodo/formula-roteiro.md, "Linguagem")`);
    }
  }
  if (/\bTROQUE\b/.test(txt.replace(/^>.*$/gm, ''))) out.corrigir.push('ainda tem "TROQUE" no roteiro.md: é o lugar que o modelo marca pra trocar pelo deste vídeo');

  // ---------- a ficha de cena ----------
  const ficha = secao(txt, 'Ficha de cena');
  if (ficha == null) {
    out.corrigir.push('falta a "## Ficha de cena" no roteiro.md: o cenário, a tabela dos objetos, o teste dos substantivos e um bloco por frase com as 10 linhas (npm run guia -- ficha)');
    return out;
  }
  out.temFicha = true;
  const cen = (ficha.match(/\*\*Cen[áa]rio:\*\*\s*`([a-z_]+)`/) || [])[1];
  let cenarios = [];
  try { cenarios = require('./canal-arquivos').cenariosDoMotor(); } catch { /* sem a lista, só confere se tem */ }
  if (!cen) out.corrigir.push('falta o cenário na ficha: a linha **Cenário:** `nome` (um dos 17 prontos de referencias/cenarios.md), com o porquê e as peças dele que entram nas frases');
  else if (cenarios.length && !cenarios.includes(cen)) out.corrigir.push(`o cenário \`${cen}\` não existe: escolha um destes: ${cenarios.join(', ')}`);

  const L = ficha.split('\n');
  const trecho = (titulo) => {
    const i = L.findIndex((l) => /^###\s/.test(l) && semAcento(l).includes(semAcento(titulo)));
    if (i < 0) return null;
    let j = i + 1;
    while (j < L.length && !/^#{2,3}\s/.test(L[j])) j++;
    return L.slice(i + 1, j).join('\n');
  };
  const objetos = tabela(trecho('Objetos do v'));
  const nomes = new Set(['personagem']);
  objetos.forEach((linha) => nomesDaCelula(linha[0]).forEach((n) => nomes.add(semAcento(n))));
  if (objetos.length < 2) out.corrigir.push('falta a tabela "### Objetos do vídeo" (tudo o que a câmera vai mostrar: o nome que vai no código, do que é feito, o tamanho e a cor, onde fica e em que frase aparece)');
  if (tabela(trecho('Teste dos substantivos')).length < 1) out.corrigir.push('falta o "### Teste dos substantivos" (toda coisa que a narração cita e a frase em que ela aparece): é ele que acha o objeto esquecido');

  const bs = blocos(ficha);
  const porNumero = new Map(bs.map((b) => [b.n, b]));
  let anterior = null, abertos = 0;
  const lista = frases && frases.length ? frases : bs.map((b) => ({ n: b.n, texto: b.frase }));
  const ultimo = lista.length ? lista[lista.length - 1].n : 0;
  for (const f of lista) {
    const b = porNumero.get(f.n);
    if (!b) { pf(f.n).corrigir.push('esta frase não tem bloco na ficha de cena: escreva o "#### ' + f.n + ' · plano `nome` · ~N s" com as 10 linhas'); anterior = null; continue; }
    const x = pf(f.n);
    if (b.frase && f.texto) {
      const a = new Set(palavras(semAcento(f.texto))), c = palavras(semAcento(b.frase));
      const iguais = c.filter((w) => a.has(w)).length;
      if (c.length && iguais / Math.max(a.size, c.length) < 0.5) x.conferir.push(`o bloco ${f.n} da ficha está com outra frase ("${b.frase.slice(0, 50)}"): o bloco de cada número é da frase de mesmo número do roteiro`);
    }
    for (const [nome, chave] of ROTULOS) {
      const v = b.linhas[chave];
      if (v == null) { x.corrigir.push(`falta a linha ${nome}`); continue; }
      const limpo = v.replace(/[`*"]/g, '').trim();
      if (!limpo) { x.corrigir.push(`a linha ${nome} está vazia`); continue; }
      if (/^(igual|idem|mesm[oa]|repete|o mesmo|a mesma|ver (a )?anterior|como (na|a) anterior)/i.test(semAcento(limpo)) || /igual (a|à) (frase |cena )?anterior/.test(semAcento(limpo))) {
        x.corrigir.push(`a linha ${nome} manda olhar a frase anterior: escreva por extenso, como pra quem vai desenhar a cena sem ouvir a narração`);
        continue;
      }
      if (MINIMO[chave] && palavras(limpo).length < MINIMO[chave] && !(chave === 'interacao' && /^(nenhuma|nada)\b/i.test(semAcento(limpo)))) {
        const n = palavras(limpo).length;
        const dica = { camera: 'o alvo no centro, o movimento, o plano, o lado e a altura', personagem: 'onde ele está, pra onde olha e as duas ações (uma no começo e outra numa palavra da frase)',
          interacao: 'quem mexe em quê, e em que palavra (ele segura, empurra, aponta; ou a peça molha, assusta, derruba ele)', 'objetos se mexendo': 'cada coisa que se mexe, de onde pra onde, quanto e em que palavra' }[chave] || 'tudo o que aparece e onde está na tela';
        x.corrigir.push(`a linha ${nome} está curta demais (${n} ${n === 1 ? 'palavra' : 'palavras'}): detalhe ${dica}`);
      }
    }
    const pers = semAcento(b.linhas.personagem || '');
    if (/\b(parad[oa]|so observa|observando|so olhando|apenas olha|so assiste|assistindo)\b/.test(pers) && !/nunca parado|nao fica parado/.test(pers)) x.corrigir.push('o personagem está parado ou só olhando: dê uma ação e uma interação (aponta, segura, empurra, leva um susto, comemora)');
    else if (pers) {
      // duas ações: "começo: x · na palavra y: z", "quando...", "depois...", "na 2ª metade..."
      const marcas = (pers.match(/\b(comeco|na palavra|quando|depois|metade|no fim|em seguida|e entao)\b/g) || []).length;
      const acoes = (b.linhas.personagem.match(/`[^`]+`/g) || []).length;
      if (marcas < 2 && !(marcas >= 1 && acoes >= 2)) x.conferir.push('o PERSONAGEM tem uma ação só? São duas: uma no começo e outra numa palavra da frase (começo: `surpreso` · na palavra "ferro": aponta)');
    }
    if (semAcento(b.linhas.interacao || '').match(/^(nenhuma|nada)\b/)) x.conferir.push('sem INTERAÇÃO: o personagem mexe em alguma coisa, ou alguma coisa mexe com ele (molha, assusta, derruba)');
    const cam = semAcento(b.linhas.camera || '');
    const mov = MOVIMENTOS.find((m) => new RegExp(`\\b${m}\\b`).test(cam));
    const plano = PLANOS.find((p) => new RegExp(`\\b${p}\\b`).test(cam));
    if (cam && !mov) x.conferir.push(`a CÂMERA não diz o movimento (${MOVIMENTOS.filter((m) => m !== 'parado').join(', ')})`);
    if (cam && !plano) x.conferir.push('a CÂMERA não diz o plano (aberto, medio, perto ou detalhe)');
    if (plano === 'aberto') abertos++;
    const lado = (cam.match(/\b(frente|direita|esquerda|perfil|tras|costas|de cima|de baixo)\b/g) || []).join(' ');
    const altura = (cam.match(/\b(alto|olho|baixo|chao)\b/) || [])[1] || '';
    if (anterior && cam && cam === anterior.cam) x.corrigir.push('a CÂMERA é igual à da frase anterior: mude o movimento, o plano, o lado ou a altura');
    else if (anterior && mov && mov === anterior.mov && plano && plano === anterior.plano && lado === anterior.lado && altura === anterior.altura) {
      x.conferir.push(`a câmera repete a da frase anterior (${mov}, ${plano}${lado ? `, ${lado}` : ''}): mude o movimento, o plano, o lado ou a altura`);
    }
    if (plano === 'aberto' && f.n !== lista[0].n && f.n < ultimo - 1 && !/revel/.test(cam)) x.conferir.push('câmera "aberto" no meio do vídeo: aberto só no gancho, numa revelação e no fim (câmera longe deixa o cenário vazio)');
    const itens = nomesDoMostra(b.linhas.mostra);
    if (b.linhas.mostra != null && !itens.length) x.corrigir.push('o MOSTRA está vazio: a lista do que tem que aparecer na tela, com os nomes da tabela dos objetos, ex. ["coluna", "personagem"]');
    const fora = itens.filter((n) => !nomes.has(semAcento(n)));
    if (objetos.length >= 2 && fora.length) x.corrigir.push(`no MOSTRA, ${fora.map((n) => `"${n}"`).join(', ')} não ${fora.length > 1 ? 'estão' : 'está'} na tabela dos objetos: use o nome da 1ª coluna (é o mesmo do cena.js) ou ponha na tabela`);
    anterior = { cam, mov, plano, lado, altura };
  }
  bs.filter((b) => !lista.some((f) => f.n === b.n)).forEach((b) => out.conferir.push(`a ficha tem o bloco ${b.n}, que não é de nenhuma frase do roteiro`));
  if (lista.length >= 6 && abertos / lista.length > 0.3) out.conferir.push(`${abertos} de ${lista.length} câmeras em "aberto": use mais "medio" e "perto", com o personagem ocupando pelo menos 1/3 da altura`);

  // ---------- o roteiro.json, se já existe: tem que bater com a ficha ----------
  try {
    const j = JSON.parse(lerArq(path.join(pasta, 'roteiro.json')) || 'null');
    const fr = j && Array.isArray(j.frases) ? j.frases.filter((f) => f && f.texto) : null;
    if (fr && frases && frases.length && fr.length !== frases.length) out.conferir.push(`o roteiro.json tem ${fr.length} frases e o roteiro.md tem ${frases.length}: os dois têm que ter as mesmas frases, na mesma ordem`);
    if (fr) fr.forEach((f, i) => {
      const b = porNumero.get(i + 1);
      if (!b || !Array.isArray(f.mostra)) return;
      const daFicha = nomesDoMostra(b.linhas.mostra).map((s) => semAcento(s)).sort();
      const doJson = f.mostra.map((s) => semAcento(s)).sort();
      if (daFicha.length && daFicha.join('|') !== doJson.join('|')) pf(i + 1).conferir.push(`o "mostra" do roteiro.json (${f.mostra.join(', ')}) não é igual à linha MOSTRA da ficha (${daFicha.join(', ')})`);
    });
  } catch { /* roteiro.json quebrado: o render já explica */ }
  return out;
}

function relatorio(pasta) {
  const c = conferir(pasta);
  const rel = path.relative(RAIZ, pasta) || pasta;
  const nC = c.corrigir.length + Object.values(c.porFrase).reduce((n, x) => n + x.corrigir.length, 0);
  const nF = c.conferir.length + Object.values(c.porFrase).reduce((n, x) => n + x.conferir.length, 0);
  const l = [`REVISÃO DO ROTEIRO E DA FICHA DE CENA: ${rel}/roteiro.md`];
  const seg = Math.round((c.palavras / 190) * 60); // a ~190 palavras por minuto, o ritmo dos vídeos curtos que prendem
  if (c.frases) l.push(`${c.frases} frases, ${c.palavras} palavras (uns ${Math.floor(seg / 60)}:${String(seg % 60).padStart(2, '0')} de vídeo)`);
  l.push('');
  if (c.corrigir.length || c.conferir.length) {
    l.push('NO ROTEIRO TODO:');
    c.corrigir.forEach((x) => l.push(`   [corrigir] ${x}`));
    c.conferir.forEach((x) => l.push(`   [conferir] ${x}`));
  }
  for (const n of Object.keys(c.porFrase).map(Number).sort((a, b) => a - b)) {
    const x = c.porFrase[n];
    if (!x.corrigir.length && !x.conferir.length) continue;
    l.push(`FRASE ${n}:`);
    x.corrigir.forEach((y) => l.push(`   [corrigir] ${y}`));
    x.conferir.forEach((y) => l.push(`   [conferir] ${y}`));
  }
  const tema = path.basename(pasta);
  l.push('', nC
    ? `RESULTADO: CORRIGIR (${nC} ${nC > 1 ? 'coisas' : 'coisa'} pra corrigir, ${nF} pra conferir).`
    : `RESULTADO: APROVADO${nF ? ` (${nF} ${nF > 1 ? 'coisas' : 'coisa'} pra conferir: veja se foram de propósito)` : ''}.`);
  l.push(nC
    ? `PRA IA: arrume cada [corrigir] no roteiro.md (as regras: npm run guia -- ${c.temFicha ? 'ficha' : 'roteiro'} ${tema}) e rode de novo: npm run roteiro -- ${tema}. Não mostre o roteiro pra pessoa nem comece o cena.js antes do APROVADO.`
    : `PRA IA: mostre o roteiro pra pessoa como manda o passo 1 de comandos/novo-video.md (o texto e cada cena em 2 linhas simples) e espere o ok. Depois: npm run guia -- cena ${tema}`);
  return { texto: l.join('\n'), nCorrigir: nC, nConferir: nF, ...c };
}

module.exports = { conferir, relatorio };

if (require.main === module) {
  const arg = (process.argv.slice(2).find((a) => !a.startsWith('--')) || '').replace(/[\\/]+$/, '');
  if (!arg) { console.log('Qual vídeo? npm run roteiro -- <tema> (a pasta de videos/)'); process.exit(1); }
  const pasta = fs.existsSync(path.join(RAIZ, 'videos', arg)) ? path.join(RAIZ, 'videos', arg) : path.resolve(arg);
  if (!fs.existsSync(pasta)) { console.log(`Não achei a pasta videos/${arg}.\nPRA IA: crie a pasta videos/${arg}/ e escreva o roteiro.md nela (npm run guia -- roteiro ${arg}).`); process.exit(1); }
  // O painel mostra a conferência e, aprovado, que é a vez da pessoa ler o roteiro (motor/andamento.js)
  const A = require('./andamento');
  A.comecar('conferir-roteiro', { tema: path.basename(pasta) });
  const r = relatorio(pasta);
  A.terminar('conferir-roteiro', r.nCorrigir
    ? { ia: 'ficha', estado: 'andando', mensagem: `A conferência do roteiro pediu pra arrumar ${r.nCorrigir} ${r.nCorrigir > 1 ? 'coisas' : 'coisa'}: a IA está arrumando.` }
    : { ia: 'ficha', estado: 'sua-vez', mensagem: 'O roteiro e a descrição de cada cena estão prontos: leia na conversa com a IA e responda "pode seguir" ou o que quer mudar.' });
  console.log(r.texto);
}
