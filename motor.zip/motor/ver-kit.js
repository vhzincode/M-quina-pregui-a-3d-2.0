// A ficha de uma peça do motor, sem abrir o código: npm run kit -- <nome> [<nome> ...]
//
//   npm run kit -- boneco                 o que o K.boneco faz, as opções (op.*), o que ele devolve e um exemplo de uso
//   npm run kit -- filmar enquadrar       várias de uma vez (com ou sem o "K.")
//   npm run kit -- boneco.reagir          um método só, com o código dele (as reações que existem estão lá)
//   npm run kit -- buscar vaca fogão      procura pelo nome e pelo que faz: o kit, os bichos, os cenários, os modelos 3D
//                                         e as peças do canal (canal/pecas/)
//   npm run kit -- cenario fazenda        um cenário pronto: os lugares, com as posições, e os objetos que dá pra filmar
//   npm run kit -- <nome> --codigo        o código inteiro da função (até 150 linhas)
//
// Por que existe: o referencias/kit-indice.md tem uma linha por peça, cortada no meio. Pra saber as opções, a IA abria o
// motor/kit.js (4 mil linhas) e lia pedaços dele: na gravação do curso (06/11), foram 24 leituras do motor num vídeo só,
// 15% de todo o gasto de tokens, porque cada leitura fica na conversa e é relida a cada passo. Aqui sai só a ficha da
// peça pedida, tirada na hora dos comentários e do código do motor: mudou o motor, muda a ficha.
const fs = require('fs');
const path = require('path');

const RAIZ = path.join(__dirname, '..');
const lerArq = (rel) => { try { return fs.readFileSync(path.join(RAIZ, rel), 'utf8').replace(/^﻿/, '').replace(/\r/g, ''); } catch { return null; } };
const semAcento = (t) => String(t).normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase();
const cortar = (t, n) => (t.length > n ? t.slice(0, n - 1).trimEnd() + '…' : t);

// Onde procurar: o motor e as peças próprias do canal (que o render carrega depois do motor)
function arquivos() {
  const r = ['motor/kit.js', 'motor/bichos.js', 'motor/cenarios.js'];
  try {
    for (const f of fs.readdirSync(path.join(RAIZ, 'canal', 'pecas')).sort()) if (f.endsWith('.js')) r.push(`canal/pecas/${f}`);
  } catch { /* sem peças do canal */ }
  return r.filter((f) => lerArq(f) != null);
}
const EXEMPLOS = ['referencias/modelo-construcao/cena.js', 'referencias/modelo-natureza/cena.js', 'referencias/modelo-de-cena/cena.js', 'videos/exemplo/cena.js'];

// Do caractere i (um "{", "(" ou "["), acha onde ele fecha, pulando texto entre aspas, template, comentário e regex
function fecha(txt, i) {
  const abre = txt[i], fechaCom = { '{': '}', '(': ')', '[': ']' }[abre];
  let d = 0;
  const pilhaTpl = [];
  let ultimo = '';
  for (let k = i; k < txt.length; k++) {
    const c = txt[k], n = txt[k + 1];
    if (c === '/' && n === '/') { k = txt.indexOf('\n', k); if (k < 0) return txt.length; continue; }
    if (c === '/' && n === '*') { k = txt.indexOf('*/', k + 2) + 1; if (k <= 0) return txt.length; continue; }
    if (c === '"' || c === "'") { for (k++; k < txt.length && txt[k] !== c; k++) if (txt[k] === '\\') k++; ultimo = c; continue; }
    if (c === '`' || (c === '}' && pilhaTpl.length && pilhaTpl[pilhaTpl.length - 1] === d)) {
      if (c === '}') pilhaTpl.pop();
      // dentro do template até o fim dele ou um ${
      for (k++; k < txt.length; k++) {
        if (txt[k] === '\\') { k++; continue; }
        if (txt[k] === '`') break;
        if (txt[k] === '$' && txt[k + 1] === '{') { k++; pilhaTpl.push(d); break; }
      }
      ultimo = '`';
      continue;
    }
    if (c === '/' && /[(,=:[!&|?{};]|^$/.test(ultimo)) { // regex
      for (k++; k < txt.length && txt[k] !== '/' && txt[k] !== '\n'; k++) { if (txt[k] === '\\') k++; else if (txt[k] === '[') { while (k < txt.length && txt[k] !== ']') k++; } }
      ultimo = '/';
      continue;
    }
    if (c === abre) d++;
    else if (c === fechaCom) { d--; if (d === 0) return k; }
    if (!/\s/.test(c)) ultimo = c;
  }
  return txt.length;
}

// Todas as definições "K.nome = ..." de um arquivo: { nome, arq, linha, doc, cabeca, corpo }
const cacheDefs = {};
function definicoes(arq) {
  if (cacheDefs[arq]) return cacheDefs[arq];
  const txt = lerArq(arq) || '';
  const linhas = txt.split('\n');
  const inicioDa = [];
  let pos = 0;
  for (const l of linhas) { inicioDa.push(pos); pos += l.length + 1; }
  const r = [];
  linhas.forEach((l, i) => {
    const m = l.match(/^(\s*)K\.([A-Za-z_$][\w$]*)\s*=(?!=)\s*(.*)$/);
    if (!m) return;
    const doc = [];
    // o comentário fica logo acima; às vezes, umas linhas de código (const ...) entre ele e a definição
    let j0 = i - 1;
    for (let pulou = 0; pulou < 3 && j0 >= 0 && !/^\s*\/\//.test(linhas[j0]) && /^\s*(const|let|var)\s/.test(linhas[j0]); pulou++) j0--;
    if (!/^\s*\/\//.test(linhas[j0] || '')) j0 = i - 1;
    for (let j = j0; j >= 0 && /^\s*\/\//.test(linhas[j]); j--) {
      const d = linhas[j].replace(/^\s*\/\/\s?/, '');
      if (/^-{3,}/.test(d.trim())) break;
      doc.unshift(d);
    }
    const ini = inicioDa[i] + m[1].length;
    const resto = m[3];
    let fim = inicioDa[i] + l.length;
    // o corpo: a função inteira, o objeto inteiro ou só a linha
    const deFuncao = resto.match(/^(?:function\b[^(]*|async\s+)?\(/) || /^\w+\s*=>/.test(resto);
    if (deFuncao) {
      const a = txt.indexOf('(', inicioDa[i] + l.indexOf(resto));
      const fp = /^\w+\s*=>/.test(resto) ? inicioDa[i] + l.indexOf(resto) : fecha(txt, a);
      const depois = txt.slice(fp + 1, fp + 200);
      const chave = depois.match(/^\s*(=>)?\s*\{/);
      if (chave) fim = fecha(txt, txt.indexOf('{', fp + 1));
      else { const pv = txt.indexOf(';\n', fp); fim = pv < 0 ? fim : pv + 1; }
    } else if (/^[{[]/.test(resto.trim())) fim = fecha(txt, txt.indexOf(resto.trim()[0], inicioDa[i] + l.indexOf(resto)));
    let docTxt = doc.join('\n').trim();
    // peça do canal sem comentário em cima: vale o comentário do começo do arquivo (é lá que o LEIA-ME pede pra explicar)
    if (!docTxt && arq.startsWith('canal/pecas/')) docTxt = (txt.match(/^(?:\s*\/\/.*\n)+/) || [''])[0].replace(/^\s*\/\/\s?/gm, '').trim();
    r.push({ nome: m[2], arq, linha: i + 1, doc: docTxt, cabeca: l.trim(), corpo: txt.slice(ini, fim + 1), ind: m[1].length });
  });
  return (cacheDefs[arq] = r);
}
const todas = () => arquivos().flatMap(definicoes);

// A assinatura: K.nome(args) ou só K.nome
function assinatura(d) {
  const resto = d.cabeca.replace(/^K\.[\w$]+\s*=\s*/, '');
  const a = resto.indexOf('(');
  if (/^\w+\s*=>/.test(resto)) return `K.${d.nome}(${resto.match(/^(\w+)/)[1]})`;
  if (a >= 0 && /^(function\b[^(]*|async\s*)?\(/.test(resto)) {
    const f = fecha(resto, a);
    return `K.${d.nome}(${resto.slice(a + 1, f).trim()})`;
  }
  return `K.${d.nome}`;
}

// As opções que a função lê do último parâmetro (op = {}), com o padrão quando o código diz
function opcoes(d) {
  const sig = assinatura(d);
  const m = sig.match(/(\w+)\s*=\s*\{\s*\}\s*\)$/);
  const nomeOp = m ? m[1] : (/\bop\b/.test(sig) ? 'op' : null);
  if (!nomeOp) return [];
  const r = new Map();
  const re = new RegExp(`\\b${nomeOp}\\.(\\w+)(\\s*(\\?\\?|\\|\\|)\\s*([^,;)\\]}\\n]+)|\\s*!==\\s*false)?`, 'g');
  let x;
  while ((x = re.exec(d.corpo))) {
    const nome = x[1];
    if (/^(length|hasOwnProperty)$/.test(nome)) continue;
    let pad = x[2] ? (x[2].includes('false') ? 'ligado (false desliga)' : x[4].trim()) : null;
    // padrão que é um objeto, uma conta ou ficou cortado no meio: não ajuda, sai só o nome
    if (pad && (/^[{[(]/.test(pad) || (pad.match(/[([{]/g) || []).length !== (pad.match(/[)\]}]/g) || []).length)) pad = null;
    if (pad) pad = cortar(pad, 40);
    if (!r.has(nome) || (pad && !r.get(nome))) r.set(nome, pad);
  }
  const des = d.corpo.match(new RegExp(`(?:const|let)\\s*\\{([^}]+)\\}\\s*=\\s*${nomeOp}\\b`));
  if (des) des[1].split(',').forEach((p) => { const [n, v] = p.split('=').map((s) => s.trim()); if (n && !r.has(n)) r.set(n, v ? cortar(v, 40) : null); });
  return [...r].map(([n, v]) => (v ? `${n} (padrão ${v})` : n));
}

// Os métodos do que a função devolve (b.acenar = function ...), com o comentário de cada um
function metodos(d) {
  const ret = [...d.corpo.matchAll(/\breturn\s+(\w+)\s*;/g)].map((x) => x[1]);
  const L = d.corpo.split('\n');
  const porVar = {};
  L.forEach((l, i) => {
    const m = l.match(/^\s*(\w{1,14})\.(\w+)\s*=\s*(function\s*\w*\s*\(([^)]*)\)|\(([^)]*)\)\s*=>|(\w+)\s*=>|(\w+)\s*;)/);
    if (!m || m[1] === 'K' || m[1] === 'this') return;
    // as propriedades do Three.js (visible, position...) e os valores soltos não são ações: só os métodos e o que tem comentário
    if (/^(visible|name|position|rotation|scale|userData|renderOrder|castShadow|receiveShadow|material|geometry)$/.test(m[2])) return;
    if (m[7] && !/^\s*\/\//.test(L[i - 1] || '')) return;
    const args = m[4] ?? m[5] ?? m[6] ?? null;
    const doc = [];
    for (let j = i - 1; j >= 0 && /^\s*\/\//.test(L[j]); j--) doc.unshift(L[j].replace(/^\s*\/\/\s?/, ''));
    (porVar[m[1]] = porVar[m[1]] || []).push({ nome: m[2], args: args == null ? null : args.trim(), doc: doc.join(' ').trim(), linha: i });
  });
  const escolhidas = Object.keys(porVar).filter((v) => ret.includes(v) || porVar[v].length >= 4);
  const r = [];
  for (const v of escolhidas) for (const x of porVar[v]) if (!r.some((y) => y.nome === x.nome)) r.push({ ...x, v });
  // os métodos escritos dentro do objeto devolvido (return K.componente({ em(ponto, tempo, op) {...} })), os de fora
  if (/return\s+(K\.componente\(\s*)?\{/.test(d.corpo)) {
    const cand = [];
    L.forEach((l, i) => {
      const m = l.match(/^(\s+)(\w+)\s*\(([^)]*)\)\s*\{/);
      if (!m || /^(if|for|while|switch|catch|function|return)$/.test(m[2])) return;
      const doc = [];
      for (let j = i - 1; j >= 0 && /^\s*\/\//.test(L[j]); j--) doc.unshift(L[j].replace(/^\s*\/\/\s?/, ''));
      cand.push({ ind: m[1].length, nome: m[2], args: m[3].trim(), doc: doc.join(' ').trim(), linha: i });
    });
    const menor = Math.min(...cand.map((c) => c.ind));
    for (const c of cand) if (c.ind === menor && !r.some((y) => y.nome === c.nome)) r.push({ ...c, v: 'x' });
  }
  return r;
}

// Onde os modelos e o exemplo usam a peça (até 3 linhas)
function exemplos(padrao, max = 3) {
  const r = [];
  for (const f of EXEMPLOS) {
    const txt = lerArq(f);
    if (!txt) continue;
    for (const l of txt.split('\n')) {
      if (padrao.test(l) && !r.some((x) => x.l === l.trim())) r.push({ f, l: l.trim() });
      if (r.length >= max) return r;
    }
  }
  return r;
}

function acharDef(nome, arq) {
  const n = nome.replace(/^K\./, '').replace(/\(.*$/, '');
  const defs = arq ? [...definicoes(arq), ...todas()] : todas();
  return defs.find((d) => d.nome === n) || defs.find((d) => semAcento(d.nome) === semAcento(n)) || null;
}

// A ficha de uma peça. curta: sem o exemplo e com a descrição de cada método mais curta (pra cola da etapa)
function ficha(nome, { curta = false, codigo = false, arq = null } = {}) {
  const [base, metodo] = nome.replace(/^K\./, '').split('.');
  const d = acharDef(base, arq);
  if (!d) return null;
  const doMotor = d.arq.startsWith('canal/') && todas().some((x) => x.nome === d.nome && !x.arq.startsWith('canal/'));
  const l = [`━━ ${assinatura(d)} · ${d.arq}${d.arq.startsWith('canal/') ? (doMotor ? ' (peça do canal que muda a do motor)' : ' (peça própria do canal)') : ''} ━━`];
  if (metodo) {
    const ms = metodos(d), x = ms.find((m) => m.nome === metodo);
    if (!x) return `${l[0]}\nNão achei o método "${metodo}". Os que existem: ${ms.map((m) => m.nome).join(', ')}`;
    const L = d.corpo.split('\n');
    const ini = L.findIndex((s, i) => i >= x.linha && new RegExp(`(\\.${metodo}\\s*=|^\\s+${metodo}\\s*\\()`).test(s));
    const txtDali = L.slice(ini).join('\n');
    // a chave que abre o corpo vem depois dos parênteses (o "op = {}" dos argumentos não conta)
    const pa = txtDali.indexOf('('), fp = pa >= 0 ? fecha(txtDali, pa) : -1;
    const a = txtDali.indexOf('{', fp >= 0 ? fp : 0), linha1 = txtDali.split('\n')[0];
    const fim = a >= 0 && (linha1.includes('{') || /=>\s*$/.test(linha1)) ? fecha(txtDali, a) : txtDali.indexOf('\n');
    const cod = txtDali.slice(0, fim + 1).split('\n');
    l.push(`.${x.nome}(${x.args ?? ''})${x.doc ? `: ${x.doc}` : ''}`, '', ...cod.slice(0, 80).map((s) => s.replace(/^ {4}/, '')));
    if (cod.length > 80) l.push(`… (mais ${cod.length - 80} linhas)`);
    return l.join('\n');
  }
  if (d.doc) l.push(d.doc);
  if (codigo) {
    const cod = d.corpo.split('\n');
    l.push('', ...cod.slice(0, 150));
    if (cod.length > 150) l.push(`… (mais ${cod.length - 150} linhas)`);
    return l.join('\n');
  }
  const op = opcoes(d);
  if (op.length) l.push(`Opções: ${op.join(', ')}`);
  const ms = metodos(d);
  if (ms.length) {
    l.push('O que ele devolve tem:');
    for (const m of ms) {
      const desc = m.doc ? `: ${cortar(m.doc, curta ? 170 : 400)}` : '';
      l.push(`  .${m.nome}${m.args != null ? `(${m.args})` : ''}${desc}`);
    }
  }
  if (!curta) {
    const ex = exemplos(new RegExp(`K\\.${d.nome}\\b`));
    if (ex.length) l.push('Uso nos modelos:', ...ex.map((x) => `  ${cortar(x.l, 170)}   (${x.f})`));
    l.push(`Mais: npm run kit -- ${d.nome}.<método> (o código de um método) ou npm run kit -- ${d.nome} --codigo`);
  }
  return l.join('\n');
}

// ---------- O cenário pronto: os lugares (com a posição) e os objetos ----------
const CENARIOS_MD = 'referencias/cenarios.md';
function fichaCenario(nome) {
  const txt = lerArq('motor/cenarios.js') || '';
  const apelidos = {};
  for (const m of txt.matchAll(/(\w+):\s*'(\w+)'/g)) apelidos[m[1]] = m[2];
  const chave = /CENARIOS\.(\w+)\s*=/.test(txt) && new RegExp(`CENARIOS\\.${nome}\\s*=`).test(txt) ? nome : apelidos[nome] || nome;
  const i = txt.search(new RegExp(`CENARIOS\\.${chave}\\s*=\\s*function`));
  if (i < 0) return null;
  const corpo = txt.slice(i, fecha(txt, txt.indexOf('{', i)) + 1);
  const l = [`━━ O cenário "${chave}" (K.cenario('${chave}')) · motor/cenarios.js ━━`];
  const md = lerArq(CENARIOS_MD) || '';
  const sec = md.split('\n### ').find((s) => s.startsWith(`\`${chave}\``));
  if (sec) l.push(sec.split('\n').slice(1).join('\n').trim());
  // os lugares que todo cenário tem (o padrão) e os que este muda
  const padrao = { centro: '[0, 0, 0]', personagem: '[1.6, 0, 0.9]', entrada: '[-3, 0, 4.5]', esquerda: '[-2.6, 0, 0.4]', direita: '[2.9, 0, 0.3]', fundo: '[0, 3, -12]' };
  const ini = txt.match(/const C = \{([\s\S]*?)\n\s*\};/);
  if (ini) for (const m of ini[1].matchAll(/(\w+):\s*(\[[^\]]*\])/g)) if (padrao[m[1]]) padrao[m[1]] = m[2];
  for (const m of corpo.matchAll(/C\.(centro|personagem|entrada|esquerda|direita|fundo)\s*=\s*(\[[^\]]*\])/g)) padrao[m[1]] = m[2];
  l.push('Lugares (x, y, z): ' + Object.entries(padrao).map(([k, v]) => `C.${k} ${v}`).join(' · '));
  const vista = corpo.match(/C\.vista\s*=\s*(\{[^}]*\})/);
  if (vista) l.push(`C.vista ${vista[1]}`);
  const lug = [];
  for (const m of corpo.matchAll(/C\.lugares\.(\w+)\s*=\s*(\[[^\]]*\])/g)) lug.push(`${m[1]} ${m[2]}`);
  const oa = corpo.match(/Object\.assign\(C\.lugares,\s*\{([\s\S]*?)\}\)/);
  if (oa) for (const m of oa[1].matchAll(/(\w+):\s*(\[[^\]]*\])/g)) lug.push(`${m[1]} ${m[2]}`);
  if (lug.length) l.push('C.lugares: ' + lug.join(' · '));
  const obj = [];
  for (const m of corpo.matchAll(/C\.objetos\.(\w+)\s*=\s*([^;\n]+)/g)) {
    const pos = (m[2].match(/\[(-?[\d.]+),\s*(-?[\d.]+),\s*(-?[\d.]+)\]/) || [])[0];
    const varios = /^\[/.test(m[2].trim()) || /\.map\(/.test(m[2]);
    obj.push(`${m[1]}${varios ? ' (lista)' : ''}${pos ? ` em ${pos}` : ''}`);
  }
  if (obj.length) l.push('C.objetos (dá pra filmar, pôr etiqueta e fazer falhar; o nome já vale no "mostra"): ' + obj.join(' · '));
  const notas = [...corpo.matchAll(/^\s*\/\/\s?(.+)$/gm)].map((m) => m[1].trim()).filter((s) => !/^-{3,}/.test(s));
  if (notas.length) l.push('O que tem nele: ' + cortar(notas.join(' · '), 700));
  l.push(`Mais: npm run kit -- cenario (a lista de todos) · as fotos em referencias/cenarios/${chave}.jpg`);
  return l.join('\n');
}

// ---------- Procurar ----------
function buscar(palavras) {
  const ps = palavras.map(semAcento).filter((p) => p.length > 1);
  const nota = (texto, nome = '') => ps.reduce((a, p) => a + (semAcento(nome).includes(p) ? 3 : 0) + (semAcento(texto).includes(p) ? 1 : 0), 0);
  const r = [];
  for (const d of todas()) {
    const n = nota(d.doc, d.nome);
    if (n) r.push({ n, t: `${assinatura(d)} · ${d.arq}${d.doc ? ` — ${cortar(d.doc.replace(/\s+/g, ' '), 170)}` : ''}` });
    for (const m of metodos(d)) { const nm = nota(m.doc, m.nome); if (nm >= 3) r.push({ n: nm - 1, t: `${m.v}.${m.nome}(${m.args ?? ''}) (do K.${d.nome}) — ${cortar(m.doc, 140)}` }); }
  }
  const md = lerArq(CENARIOS_MD) || '';
  for (const s of md.split('\n### ').slice(1)) {
    const chave = (s.match(/^`(\w+)`/) || [])[1];
    for (const lin of s.split('\n')) { const n = nota(lin); if (chave && n && /Lugares|Objetos/.test(lin)) r.push({ n, t: `cenário ${chave}: ${cortar(lin.replace(/^-\s*/, ''), 170)} (npm run kit -- cenario ${chave})` }); }
  }
  try {
    const cat = JSON.parse(lerArq('referencias/modelos/catalogo.json') || '{}');
    for (const it of cat.itens || []) { const n = nota(`${it.nome} ${it.pedir || ''}`, it.chave); if (n && it.categoria !== 'cenarios') r.push({ n, t: `${it.nome}: ${it.uso}` }); }
  } catch { /* sem catálogo */ }
  r.sort((a, b) => b.n - a.n);
  return [...new Set(r.map((x) => x.t))].slice(0, 25);
}

module.exports = { ficha, fichaCenario, buscar, acharDef, todas };

if (require.main === module) {
  const args = process.argv.slice(2);
  const codigo = args.includes('--codigo');
  const nomes = args.filter((a) => !a.startsWith('--'));
  const ajuda = [
    'A ficha de uma peça do motor (o que faz, as opções, o que ela devolve e um exemplo), sem abrir o código:',
    '  npm run kit -- boneco               uma peça (com ou sem o "K.")',
    '  npm run kit -- filmar enquadrar     várias de uma vez',
    '  npm run kit -- boneco.reagir        um método, com o código dele',
    '  npm run kit -- buscar vaca fogão    procurar pelo nome ou pelo que faz',
    '  npm run kit -- cenario fazenda      os lugares e os objetos de um cenário pronto',
    '  npm run kit -- boneco --codigo      o código inteiro da função',
    'A lista de tudo, por assunto: referencias/kit-indice.md.'
  ].join('\n');
  if (!nomes.length) { console.log(ajuda); process.exit(0); }
  if (semAcento(nomes[0]) === 'buscar' || semAcento(nomes[0]) === 'procurar') {
    const r = buscar(nomes.slice(1));
    console.log(r.length ? `Achei (do mais parecido pro menos):\n${r.map((x) => `- ${x}`).join('\n')}\n\nPRA IA: a ficha de um deles: npm run kit -- <nome>` : 'Não achei nada com essas palavras. Tente outra palavra (sem acento também vale), ou monte a peça com K.pecas (npm run kit -- pecas).');
    process.exit(0);
  }
  if (semAcento(nomes[0]) === 'cenario') {
    if (!nomes[1]) {
      const txt = lerArq('motor/cenarios.js') || '';
      console.log(`Os cenários prontos: ${[...txt.matchAll(/CENARIOS\.(\w+)\s*=\s*function/g)].map((m) => m[1]).join(', ')}\nPRA IA: npm run kit -- cenario <nome>`);
      process.exit(0);
    }
    const f = fichaCenario(nomes[1]);
    console.log(f || `Não achei o cenário "${nomes[1]}". npm run kit -- cenario mostra os que existem.`);
    process.exit(f ? 0 : 1);
  }
  let falhou = false;
  const saida = nomes.map((n) => {
    const f = ficha(n, { codigo });
    if (f) return f;
    falhou = true;
    const parecidos = buscar([n.replace(/^K\./, '')]).slice(0, 6);
    return `Não achei "${n}" no motor nem em canal/pecas/.${parecidos.length ? `\nParecidos:\n${parecidos.map((x) => `- ${x}`).join('\n')}` : ''}`;
  });
  console.log(saida.join('\n\n'));
  process.exit(falhou && saida.length === 1 ? 1 : 0);
}
