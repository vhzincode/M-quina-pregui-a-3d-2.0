// O que a IA e a Máquina estão fazendo agora: npm run andamento
//
//   npm run andamento                       a etapa de agora, há quanto tempo e quanto ela costuma levar (pra IA
//                                           responder "travou?" e dar notícia com o número certo)
//   npm run andamento -- --ia-trabalhando   a pessoa mandou mensagem: a IA começou a trabalhar (o Claude Code roda
//                                           sozinho, num gancho; as outras IAs não precisam)
//   npm run andamento -- --ia-parou         a IA terminou de responder: a vez é da pessoa (o Claude Code roda sozinho)
//
// Por que existe: um vídeo leva de 30 minutos a 1 hora, e a maior parte é a IA lendo, pensando e escrevendo, sem nada
// mudar na tela. Quem não sabe o que está acontecendo acha que travou (aconteceu na gravação do curso, em 06/11). Cada
// comando da Máquina conta aqui o que está fazendo: a cola de cada etapa (npm run guia), a revisão do roteiro, o render
// (a voz, os quadros, a junção do vídeo), o backup e a instalação. O painel mostra ao vivo, no alto de toda tela: a
// etapa, há quanto tempo, quanto costuma levar e, quando é a Máquina trabalhando, a barra com quanto falta.
//
// Fica em .andamento.json, na raiz da pasta (fora do backup e do zip). Nunca atrapalha quem chamou: se não der pra
// gravar, só não grava.
const fs = require('fs');
const path = require('path');

const RAIZ = path.join(__dirname, '..');
const ARQ = path.join(RAIZ, '.andamento.json');

// As etapas, na ordem de um vídeo. min e max: quanto cada uma costuma levar, em minutos (medido nos vídeos da gravação
// do curso, com o Claude Code; IA grátis e computador mais fraco levam mais). marco: entra na lista do que já foi feito
const ETAPAS = {
  instalar: { nome: 'Instalando a Máquina', quem: 'maquina', min: 3, max: 15, marco: true },
  canal: { nome: 'Configurando o canal', quem: 'ia', min: 5, max: 20, marco: true },
  tema: { nome: 'Escolhendo o tema', quem: 'ia', min: 1, max: 5, marco: true },
  roteiro: { nome: 'Escrevendo o roteiro', quem: 'ia', min: 4, max: 15, marco: true },
  ficha: { nome: 'Descrevendo cada cena (a ficha de cena)', quem: 'ia', min: 5, max: 15, marco: true },
  'conferir-roteiro': { nome: 'Conferindo o roteiro e a ficha de cena', quem: 'maquina', min: 0, max: 1 },
  cena: { nome: 'Montando as cenas em 3D (o código do vídeo)', quem: 'ia', min: 10, max: 30, marco: true },
  capa: { nome: 'Fazendo a capa e o título', quem: 'ia', min: 2, max: 8, marco: true },
  revisar: { nome: 'Tirando uma foto de cada cena pra conferir', quem: 'maquina', min: 1, max: 4 },
  previa: { nome: 'Tirando fotos de conferência', quem: 'maquina', min: 0, max: 2 },
  'desenhar-capa': { nome: 'Desenhando a capa', quem: 'maquina', min: 0, max: 1 },
  video: { nome: 'Fazendo o vídeo: a voz, os quadros e o som', quem: 'maquina', min: 3, max: 15, marco: true },
  postar: { nome: 'Escrevendo o texto de postar', quem: 'ia', min: 1, max: 4, marco: true },
  backup: { nome: 'Guardando o backup no GitHub', quem: 'maquina', min: 0, max: 3 },
  trabalhando: { nome: 'Trabalhando no seu pedido', quem: 'ia', min: 1, max: 10 }
};

function ler() { try { return JSON.parse(fs.readFileSync(ARQ, 'utf8')); } catch { return null; } }
// Um comando chamado por dentro de outro (o teste do vídeo de exemplo, no instalar) não mexe no andamento de quem chamou
const DESLIGADO = process.env.PREGUICA_SEM_ANDAMENTO === '1';
let ultimaGravacao = 0;
function gravar(a, { forcar = true } = {}) {
  if (DESLIGADO) return a;
  const agora = Date.now();
  if (!forcar && agora - ultimaGravacao < 800) return a; // a barra do render não precisa de mais que isso
  ultimaGravacao = agora;
  try {
    const tmp = `${ARQ}.${process.pid}.tmp`;
    fs.writeFileSync(tmp, JSON.stringify(a));
    fs.renameSync(tmp, ARQ);
  } catch { /* sem gravar: o painel só não mostra */ }
  return a;
}
const vivo = (pid) => { if (!pid) return false; try { process.kill(pid, 0); return true; } catch (e) { return e.code === 'EPERM'; } };

// Uma etapa começou. tema: a pasta de videos/ (vazio fora de um vídeo). Tema novo zera a lista do que foi feito.
// Uma etapa da Máquina no meio de uma da IA (o --revisar enquanto a IA monta as cenas) guarda a da IA pra voltar a ela
function comecar(etapa, { tema = '', detalhe = '' } = {}) {
  const et = ETAPAS[etapa] || { quem: 'maquina' };
  const agora = Date.now();
  const a = ler() || {};
  const mesmoTema = (a.tema || '') === (tema || '') || !tema;
  const feitas = mesmoTema && Array.isArray(a.feitas) ? a.feitas : [];
  const n = { tema: tema || (mesmoTema ? a.tema || '' : ''), etapa, quem: et.quem, detalhe, feito: null, total: null, falta: null,
    estado: 'andando', em: agora, desde: agora, pid: et.quem === 'maquina' ? process.pid : null, feitas, ia: a.ia || null, volta: null };
  const continua = mesmoTema && a.etapa === etapa && ['andando', 'sua-vez'].includes(a.estado);
  if (continua) n.desde = a.desde || agora;
  // A etapa da IA que estava andando: vira "feita" quando outra etapa da IA começa, ou fica guardada pra voltar
  if (mesmoTema && a.etapa && a.etapa !== etapa && a.quem === 'ia' && a.estado !== 'pronto') {
    if (et.quem === 'maquina') n.volta = { etapa: a.etapa, desde: a.desde, estado: a.estado === 'sua-vez' ? 'sua-vez' : 'andando' };
    else marcarFeita(n, a.etapa, a.desde, agora);
  } else if (mesmoTema && a.volta && et.quem === 'maquina') n.volta = a.volta;
  else if (mesmoTema && a.volta && et.quem === 'ia' && a.volta.etapa !== etapa) marcarFeita(n, a.volta.etapa, a.volta.desde, agora);
  return gravar(n);
}
function marcarFeita(a, etapa, desde, ate) {
  if (!(ETAPAS[etapa] || {}).marco) return;
  a.feitas = [...(a.feitas || []).filter((f) => f.etapa !== etapa), { etapa, desde, ate }].slice(-12);
}

// Quanto já foi (o render chama a cada quadro: grava no máximo umas vezes por segundo). falta: em segundos
function progresso({ feito = null, total = null, detalhe, falta = null } = {}) {
  const a = ler();
  if (!a || a.pid !== process.pid) return;
  // Só o número da barra mudou: grava no máximo umas vezes por segundo. Passo novo (outro detalhe) grava na hora
  const novoPasso = detalhe != null && detalhe !== a.detalhe;
  Object.assign(a, { feito, total, falta, em: Date.now() }, detalhe != null ? { detalhe } : {});
  gravar(a, { forcar: novoPasso || (feito != null && total != null && feito >= total) });
}

// A etapa acabou. Uma etapa da Máquina que interrompeu uma da IA (o --revisar enquanto a IA monta as cenas) volta pra
// da IA, com estado 'andando' (a IA continua dali: a revisão pediu pra corrigir) ou 'sua-vez' (a IA mostra o resultado
// e espera a pessoa: a revisão aprovou). voltar: false fecha tudo ali, com estado 'pronto' (o vídeo) ou 'erro'
// ia: a etapa da IA pra voltar quando nenhuma estava guardada (a IA rodou a revisão sem rodar a cola antes).
// estado 'volta': o mesmo estado de antes (a capa e as fotos de conferência não mudam de quem é a vez)
function terminar(etapa, { estado = 'andando', mensagem = '', voltar = true, ia = '' } = {}) {
  const a = ler();
  if (!a || a.etapa !== etapa) return;
  const agora = Date.now();
  const base = { feito: null, total: null, falta: null, pid: null, volta: null, em: agora };
  if (voltar && estado !== 'erro' && !(a.volta && a.volta.etapa) && ia) a.volta = { etapa: ia, desde: a.desde };
  if (estado === 'volta') estado = (a.volta && a.volta.estado) || 'pronto';
  if (voltar && estado !== 'erro' && a.volta && a.volta.etapa) {
    // A etapa da Máquina não conta como feita aqui (o vídeo barrado pela conferência das cenas volta pra IA sem ter saído)
    const v = ETAPAS[a.volta.etapa] || {};
    return gravar({ ...a, ...base, etapa: a.volta.etapa, quem: v.quem || 'ia', desde: a.volta.desde || agora, estado, detalhe: mensagem, mensagem });
  }
  if (a.volta && a.volta.etapa && estado !== 'erro') marcarFeita(a, a.volta.etapa, a.volta.desde, a.desde);
  if (estado !== 'erro') marcarFeita(a, etapa, a.desde, agora);
  const fim = estado === 'andando' ? 'pronto' : estado;
  return gravar({ ...a, ...base, estado: fim, mensagem, detalhe: mensagem || a.detalhe, fim: agora, feito: fim === 'pronto' ? a.total : a.feito });
}

// Os ganchos do Claude Code: quando a pessoa manda mensagem e quando a IA termina de responder. Com eles o painel sabe
// se a IA está trabalhando ou se é a vez da pessoa, mesmo fora de uma etapa de vídeo
function iaTrabalhando() {
  const agora = Date.now();
  const a = ler() || {};
  const n = { ...a, ia: { trabalhando: true, desde: agora, em: agora } };
  // A etapa estava esperando a pessoa: ela respondeu, a IA continua (ou passa pra próxima, que a cola marca)
  if (a.estado === 'sua-vez') Object.assign(n, { estado: 'andando', em: agora, detalhe: '' });
  // Fora de uma etapa (ou a última já acabou faz tempo): "trabalhando no seu pedido"
  // (um pedido novo, sem vídeo nenhum: esquece o vídeo de antes e o que foi feito nele)
  else if (!a.etapa || (a.estado !== 'andando' && agora - (a.em || 0) > 60000)) Object.assign(n, { tema: '', feitas: [], etapa: 'trabalhando', quem: 'ia', estado: 'andando', desde: agora, em: agora, detalhe: '', mensagem: '', feito: null, total: null, falta: null, pid: null, volta: null });
  gravar(n);
}
function iaParou() {
  const agora = Date.now();
  const a = ler();
  if (!a) return;
  const n = { ...a, ia: { trabalhando: false, desde: (a.ia && a.ia.desde) || agora, em: agora } };
  // A Máquina ainda está trabalhando (um render que a IA deixou rodando): não é a vez da pessoa
  const maquinaAndando = a.quem === 'maquina' && a.estado === 'andando' && vivo(a.pid);
  // O vídeo já saiu e a IA terminou a entrega (o texto de postar, o backup): o vídeo está pronto
  const videoPronto = (a.feitas || []).some((f) => f.etapa === 'video') && ['postar', 'backup'].includes(a.etapa);
  if (!maquinaAndando && a.estado === 'andando') {
    if (videoPronto) { marcarFeita(n, a.etapa, a.desde, agora); Object.assign(n, { estado: 'pronto', etapa: 'video', quem: 'maquina', mensagem: 'O vídeo ficou pronto.', detalhe: 'O vídeo ficou pronto.' }); }
    else Object.assign(n, { estado: a.etapa === 'trabalhando' ? 'pronto' : 'sua-vez' });
    Object.assign(n, { em: agora, fim: agora, pid: null });
  }
  gravar(n);
}

// Pro painel e pra IA: a etapa de agora com as contas feitas, ou null (nada acontecendo, ou acabou faz tempo)
function agora() {
  const a = ler();
  if (!a || !a.etapa) return null;
  const t = Date.now();
  const et = ETAPAS[a.etapa] || { nome: a.etapa, min: 0, max: 0 };
  let estado = a.estado;
  // A Máquina parou sem terminar: o processo não existe mais (fechado, erro sem aviso, computador dormiu)
  if (estado === 'andando' && a.quem === 'maquina' && a.pid && !vivo(a.pid)) estado = 'parou';
  const semNoticia = t - (a.em || t);
  // A Máquina segue aberta, mas sem dar notícia faz 20 minutos: travou (o render manda notícia a cada quadro, e cada
  // ffmpeg tem tempo máximo; isto pega o que escapar). Sem isto, depois de 3 horas dizia "nada rodando"
  if (estado === 'andando' && a.quem === 'maquina' && a.pid && semNoticia > 20 * 60000) estado = 'travou';
  if (['pronto', 'erro', 'parou'].includes(estado) && semNoticia > 20 * 60000) return null;
  // Uma foto de conferência ou a capa, fora de uma etapa da IA: o aviso de pronto some logo
  if (estado === 'pronto' && !et.marco && semNoticia > 2 * 60000) return null;
  if (estado === 'sua-vez' && semNoticia > 3 * 3600e3) return null;
  if (estado === 'andando' && semNoticia > 3 * 3600e3) return null;
  return {
    tema: a.tema || '', etapa: a.etapa, nome: et.nome, quem: a.quem, estado, detalhe: a.detalhe || '', mensagem: a.mensagem || '',
    feito: a.feito, total: a.total, falta: a.falta, min: et.min, max: et.max,
    ha: Math.max(0, Math.round((t - (a.desde || t)) / 1000)), semNoticia: Math.round(semNoticia / 1000),
    ia: a.ia ? { trabalhando: !!a.ia.trabalhando, ha: Math.round((t - (a.ia.em || t)) / 1000) } : null,
    feitas: (a.feitas || []).map((f) => ({ etapa: f.etapa, nome: (ETAPAS[f.etapa] || {}).nome || f.etapa, minutos: Math.max(1, Math.round((f.ate - f.desde) / 60000)) })),
    pid: a.pid || null,
    agora: t
  };
}

// Fecha a Máquina que travou (npm run andamento -- --fechar): só o comando da Máquina que está no andamento
function fechar() {
  const a = ler();
  const at = agora();
  if (!a || !at || at.estado !== 'travou' || !vivo(a.pid)) return false;
  try { process.kill(a.pid, 'SIGTERM'); } catch { /* já tinha fechado */ }
  const fim = Date.now() + 3000;
  while (vivo(a.pid) && Date.now() < fim) { /* espera ele fechar */ }
  if (vivo(a.pid)) try { process.kill(a.pid, 'SIGKILL'); } catch { /* já fechou */ }
  gravar({ ...a, estado: 'erro', pid: null, em: Date.now(), fim: Date.now(), mensagem: 'A Máquina travou e foi fechada. A IA vai rodar o mesmo comando de novo.', detalhe: 'A Máquina travou e foi fechada.' });
  return true;
}

const minutos = (s) => (s < 60 ? 'menos de 1 minuto' : s < 120 ? '1 minuto' : `${Math.round(s / 60)} minutos`);
// "quanto costuma levar": "de 4 a 15 minutos", "até 1 minuto"
const faixa = (min, max) => (!max ? '' : min ? `de ${min} a ${max} minutos` : `até ${max} ${max > 1 ? 'minutos' : 'minuto'}`);

module.exports = { ETAPAS, comecar, progresso, terminar, iaTrabalhando, iaParou, agora, fechar, faixa, minutos, ARQ };

// ===================================================================== na linha de comando
if (require.main === module) {
  const args = process.argv.slice(2);
  if (args.includes('--ia-trabalhando')) { iaTrabalhando(); process.exit(0); }
  if (args.includes('--ia-parou')) { iaParou(); process.exit(0); }
  if (args.includes('--fechar')) {
    console.log(fechar() ? 'ANDAMENTO: a Máquina que tinha travado foi fechada.\nPRA IA: rode de novo o mesmo comando que travou (o que já foi feito não se perde) e conte o resultado pra pessoa.'
      : 'ANDAMENTO: nada travado pra fechar (rode npm run andamento pra ver o que está acontecendo).');
    process.exit(0);
  }
  const a = agora();
  if (!a) {
    console.log('ANDAMENTO: nada rodando agora (nenhuma etapa de vídeo começou nos últimos minutos).');
    console.log('PRA IA: se a pessoa perguntou "travou?", diga em uma frase o que você estava fazendo e continue de onde parou.');
    process.exit(0);
  }
  const pct = a.total ? ` (${a.feito || 0} de ${a.total}, ${Math.floor(((a.feito || 0) / a.total) * 100)}%${a.falta ? `, falta ${a.falta < 60 ? 'menos de 1 minuto' : `uns ${minutos(a.falta)}`}` : ''})` : '';
  const quem = a.quem === 'maquina' ? 'a Máquina' : 'a IA';
  const linhas = [`ANDAMENTO: ${a.nome}${a.tema ? ` (videos/${a.tema})` : ''}: ${quem}, há ${minutos(a.ha)}${a.detalhe ? `. ${a.detalhe.replace(/[.!?]+$/, '')}` : ''}${pct}.`];
  if (a.max) linhas.push(`Costuma levar ${faixa(a.min, a.max)}.`);
  if (a.feitas.length) linhas.push(`Já feito: ${a.feitas.map((f) => `${f.nome.toLowerCase()} (${minutos(f.minutos * 60)})`).join(', ')}.`);
  if (a.estado === 'travou') linhas.push(`ESTADO: TRAVOU. A Máquina está aberta, mas há ${minutos(a.semNoticia)} sem andar.`, 'PRA IA: rode npm run andamento -- --fechar, diga pra pessoa em uma frase que a Máquina travou e foi fechada, e rode de novo o mesmo comando (o que já foi feito não se perde). Não fique esperando.');
  else if (a.estado === 'parou') linhas.push('ESTADO: a Máquina parou no meio (o comando não está mais rodando).', 'PRA IA: diga pra pessoa em uma frase que o comando parou no meio, rode de novo o mesmo comando (o que já foi feito não se perde) e conte o resultado.');
  else if (a.estado === 'erro') linhas.push(`ESTADO: deu erro${a.mensagem ? `: ${a.mensagem.replace(/[.!?]+$/, '')}` : ''}.`, 'PRA IA: explique o erro pra pessoa em palavras simples e resolva.');
  else if (a.estado === 'sua-vez') linhas.push('ESTADO: esperando a pessoa responder.');
  else if (a.estado === 'pronto') linhas.push('ESTADO: pronto.');
  else if (a.quem === 'maquina') linhas.push('ESTADO: rodando (não travou).', 'PRA IA: diga pra pessoa em uma frase o que a Máquina está fazendo e quanto falta, e que a barra aparece no alto do painel.');
  else linhas.push('PRA IA: diga pra pessoa em uma frase em que etapa você está, o que falta nela e quanto ainda leva, e continue.');
  console.log(linhas.join('\n'));
}
