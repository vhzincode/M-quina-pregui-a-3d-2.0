# TikTok

> Pra você e pra sua IA: como o TikTok escolhe quem vê, o tipo de conta, o dinheiro, o que marcar na hora de postar,
> os números e os cuidados. Conferido em novembro de 2026. As redes mudam: se o app estiver diferente, vale o app.

## Como o TikTok decide quem vê

- O TikTok mostra cada vídeo pra um grupo pequeno e vai abrindo conforme a reação: **assistir até o fim, assistir de
  novo, compartilhar, comentar, curtir e seguir**
- Ele também lê a legenda, o texto da tela e a fala pra saber de que assunto é o vídeo e mostrar na busca
- **Vídeo sem nada original não entra no "Pra você":** "conteúdo não original ou reutilizado, sem nada de novo" fica
  de fora (Diretrizes da Comunidade do TikTok). Vale pra repostar o vídeo dos outros e pra cópia quase igual
- O TikTok é a rede que mais varia de um vídeo pro outro. No canal feito com este método, um vídeo só teve mais da
  metade de todas as views do TikTok. Julgue a semana, não um vídeo

## O formato

- Vertical, 9:16. A Máquina já sai no formato certo. Envie o arquivo original, sem marca d'água de outro app
- **Mais de 1 minuto** é o que conta pro Programa de Recompensas (abaixo). Os vídeos da Máquina já passam disso

## Conta pessoal ou comercial?

- **Pessoal** (o padrão): pode entrar no Programa de Recompensas e usar as músicas da biblioteca do TikTok
- **Comercial:** tem as ferramentas de empresa (as mensagens automáticas, como o ManyChat, só funcionam nela), mas
  **não entra no Programa de Recompensas** e só usa a biblioteca de músicas comerciais
- Canal que quer ganhar com as views do TikTok: fique na pessoal

## Ganhar dinheiro (o Programa de Recompensas para Criadores)

- O que o TikTok pede (confira no app, em TikTok Studio → Monetização, porque muda): 18 anos ou mais, conta pessoal e
  morar num país atendido (o Brasil está na lista). Os guias citam também 10 mil seguidores e 100 mil views nos
  últimos 30 dias
- Paga só vídeo **original com mais de 1 minuto**, postado depois de entrar no programa
- O vídeo da Máquina (de 1 a 3 minutos, com roteiro e cenas próprios) é o tipo que conta

## Na hora de postar

1. **Capa:** em "Editar capa", envie a `capa.png` (ou escolha o 1º quadro). O perfil corta em 3:4
2. **Legenda curta com as palavras de busca** ("como funciona o chuveiro elétrico") e até 5 hashtags
3. **O texto da tela e a fala também contam pra busca:** a pergunta escrita no começo do vídeo ajuda
4. **Rótulo de conteúdo gerado por IA:** o TikTok pede em cena ou pessoa que parece real. Animação com cara de desenho
   não precisa. Na dúvida, marque: marcar não é castigo, e o TikTok põe o rótulo sozinho quando detecta
5. **Som:** o da Máquina ("som original"). Música famosa em conta comercial é derrubada
6. **Comentários, dueto e costura liberados:** conversa e resposta em vídeo ajudam
7. Pelo app do celular ou pelo TikTok Studio no computador, sempre o arquivo original

## Onde o vídeo não pode ter nada

- Os botões ficam na direita e o texto do post embaixo: deixe o importante no meio da tela. A legenda da Máquina já
  fica no centro, e a capa já guarda o importante entre 1/8 e 7/8 da altura

## Os números (TikTok Studio)

- **Tempo médio assistido** e **% que assistiu o vídeo inteiro**
- **Retenção** (o gráfico): onde a pessoa sai
- **Origem do tráfego:** "Pra você" alto é sinal de que o algoritmo gostou; "Pesquisa" alto é sinal de que o tema é
  buscado, e o vídeo vai continuar trazendo gente por muito tempo
- **Novos seguidores** que vieram do vídeo
- **Atividade dos seguidores:** os horários (`horarios.md`)
- **Se o vídeo não pode ser recomendado,** o TikTok avisa nos números do vídeo

## O que já vimos no TikTok (um canal feito com este método)

- O TikTok foi a rede mais difícil: ~569 mil views em 20 vídeos, 55% deles num vídeo só, o de pesca
- O tema de dinheiro não pegou lá (de 0,9% a 3,6% das views do mesmo vídeo no YouTube). Já um vídeo de bicho que foi
  mal em envios no Instagram foi o 2º do TikTok, com 113 mil. Cada rede tem o seu gosto
- Ideia em teste: a capa parada no 1º quadro pode fazer quem rola o feed passar direto no TikTok. Teste um vídeo com
  a cena já em movimento no começo

## Cuidados no TikTok

- Não reposte o vídeo dos outros, nem o seu várias vezes
- Muitos vídeos de uma vez parecem spam: espace
- Pedir presente, curtida ou seguidor em troca de algo tira o vídeo do "Pra você"
- Comprar seguidor ou curtida: o TikTok apaga os falsos e o alcance cai junto
- Link na legenda e no comentário não é clicável
- Informação errada sobre saúde, eleição ou crise tira o vídeo do "Pra você"

## De onde vem

- TikTok, Diretrizes da Comunidade: "Integridade e autenticidade" (conteúdo não original, conteúdo gerado por IA,
  engajamento falso) e "Padrões de elegibilidade do Pra você"
- TikTok, central de ajuda: Programa de Recompensas para Criadores (país, idade, conta pessoal). Os números de
  seguidores e de views vêm de guias (Toptal, Brandwatch, Manychat) e podem mudar
- ManyChat, central de ajuda: as mensagens automáticas só funcionam em conta comercial (conferido em 02/11/2026)
- Os números do canal: TikTok Studio, 04/11/2026
