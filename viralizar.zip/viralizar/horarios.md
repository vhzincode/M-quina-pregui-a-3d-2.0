# Horários e quantos vídeos postar

> Pra você e pra sua IA. Conferido em novembro de 2026.

## Pra começar

| Rede | Pra começar (horário de Brasília) | O que os estudos grandes acharam (no horário do público) |
|---|---|---|
| YouTube Shorts | 12h e das 18h às 20h | 16h (Buffer, 52 milhões de posts, 2026) |
| Instagram (Reels) | das 11h às 13h e das 18h às 21h | 9h (Buffer); quinta 9h, quarta 12h e quarta 18h (Later, 9,6 milhões de posts) |
| TikTok | 12h e das 18h às 21h | 18h (Buffer); das 18h às 20h (Metricool, 2 milhões de posts) |

- Os estudos discordam entre si, e o horário que vale é **o do seu público**. Use a tabela nas primeiras semanas e
  troque pelo seu
- De segunda a sexta costuma render mais que fim de semana e madrugada nos estudos. O seu público pode ser diferente
- O vídeo pesa mais que a hora. Um vídeo bom num horário ruim cresce; um fraco no horário bom, não. O horário ajuda
  a largada, a primeira hora
- Um canal feito com este método posta às 12h30 e às 20h, nas 3 redes

## Como achar o horário do seu público

- **YouTube:** Studio → Análise → Público → "Quando seus espectadores estão no YouTube"
- **Instagram:** Insights → Total de seguidores → "Horários mais ativos" (precisa de conta profissional, que é de
  graça: Configurações → Tipo de conta)
- **TikTok:** TikTok Studio → Análise → Seguidores → "Atividade dos seguidores"
- Poste **1 a 2 horas antes do pico**: o vídeo já está rodando quando o seu público chega
- Com poucos seguidores, esses números ainda não aparecem ou mudam muito. Até lá, use a tabela de cima

## O teste do horário (2 semanas)

1. Escolha 2 horários e poste sempre neles por 2 semanas
2. Anote, de cada vídeo, as views da 1ª hora e das primeiras 24 horas
3. Troque um dos horários e repita por mais 2 semanas
4. Compare só vídeos parecidos (o mesmo tipo de tema): o tema pesa mais que a hora
5. Peça pra IA anotar o resultado no `canal/aprendizados.md` ("O que dá resultado nas redes")

## Quantos vídeos

- **Constância vale mais que quantidade.** No Instagram, quem posta de 3 a 5 vezes por semana cresce mais rápido e
  alcança mais por post do que quem posta 1 ou 2 (Buffer, 2 milhões de posts, 2026)
- Comece com o que dá pra manter: 1 por dia, ou 3 por semana. Um ritmo que você mantém por 3 meses vale mais que 3
  por dia por uma semana
- Na mesma rede, deixe umas 4 a 6 horas entre um vídeo e outro. Vários de uma vez: um come o alcance do outro, e o
  TikTok pode achar que é spam
- Faça os vídeos antes e deixe prontos: assim a semana corrida não quebra o ritmo. O YouTube e o TikTok deixam
  agendar na própria tela de postar

## O mesmo vídeo nas 3 redes

- Pode postar o mesmo vídeo nas 3 redes, no mesmo dia, cada uma com o seu texto e a sua capa (o que marcar em cada
  uma: `youtube.md`, `instagram.md` e `tiktok.md`)
- Cada rede tem o seu gosto: um vídeo que foi mal numa pode ir bem noutra

## Canal em outro idioma

Poste no horário do país do público, não no do Brasil. Os mesmos 18h às 21h de lá são:

| Público | 18h às 21h de lá são, em Brasília |
|---|---|
| Estados Unidos (Nova York) | 20h às 23h (de novembro a março) ou 19h às 22h (de março a novembro) |
| México (Cidade do México) | 21h à meia-noite |
| Argentina, Chile e Uruguai | 18h às 21h (quase o mesmo horário) |
| Espanha (Madri) | 14h às 17h (de outubro a março) ou 13h às 16h (de março a outubro) |
| Portugal (Lisboa) | 15h às 18h (de outubro a março) ou 14h às 17h (de março a outubro) |

## De onde vem

- Buffer, "Best time to post on social media" (52 milhões de posts, 2026) e "How often should you post on Instagram"
  (2 milhões de posts, 2026)
- Later, "Best time to post on social media" (9,6 milhões de posts no Instagram, 2026)
- Metricool, estudo do TikTok (2 milhões de posts, 2026)
- O canal feito com este método: os horários de postagem desde 26/10/2026
