# Estudar a copy de um viral

> Pra IA. Serve pra IA que trabalha na pasta da Máquina e pra IA de chat (o painel cola este guia junto com o vídeo).
> O objetivo: descobrir **por que o texto desse vídeo prendeu e espalhou** e tirar de 1 a 3 coisas que a pessoa usa
> no canal dela, sem copiar nada. Fale com a pessoa em frases curtas, sem termo técnico.

## O que você tem

- **Os números** (o `info.md`): views, views por dia, seguidores do canal, curtidas, comentários, data e duração
- **A fala com os tempos** (`[00:12] frase`)
- **As fotos das cenas** (só na pasta: `mosaico-*.jpg`, uma foto a cada 2 segundos)
- **O caderno** (`estudos/virais-estudados.md`): os virais que a pessoa já estudou e o que se repete entre eles
- **O canal da pessoa** (`canal/canal.md`: do que ele fala). Na IA de chat, o painel manda o tema do canal no pedido

## 1. É viral de verdade?

Calcule e escreva:

- **Views por dia** desde que saiu. Um vídeo de 2 anos com 3 milhões é outra coisa que um de 10 dias com 1 milhão
- **Views ÷ seguidores do canal.** Acima de 3: o vídeo saiu da base do canal, e foi o conteúdo que levou. Abaixo de
  1: foi o tamanho do canal que empurrou, e ele ensina menos
- **Curtidas em % das views** e **comentários a cada mil views.** Compare com os outros vídeos do caderno, não com um
  número fixo
- **Duração, palavras e palavras por minuto**

Feche com uma frase: "Viral de verdade, porque..." ou "Cuidado: ..." (o canal é grande, o vídeo é velho).

## 2. O que fez o trabalho

Antes de olhar as frases, decida o que pesou mais (pode ser mais de um, em ordem):

- **O tema:** todo mundo quer saber disso, é polêmico, é notícia quente
- **O gancho:** os 3 primeiros segundos
- **O roteiro:** o jeito de contar, que segura até o fim
- **O visual ou o formato:** algo que ninguém faz
- **O momento:** uma onda, uma data, uma notícia

**O teste de tirar:** "se eu trocar o tema por um morno e deixar o resto igual, ainda prende?" Se não, foi o tema que
fez o trabalho, e as frases ensinam menos. Faça o mesmo teste com cada coisa que parecer importante.

## 3. As lentes da copy

Uma por uma, sempre com o tempo e a frase que prova. Sem prova, não escreva.

**O gancho (0 a 3 s)**
- A frase exata, quantas palavras e quanto tempo leva
- O tipo: pergunta curiosa, contradição ("tão... e..."), dor do dia a dia, jeito ingênuo exagerado, experimento, mito,
  notícia, promessa com número ou começo no meio da ação
- A pergunta que abre na cabeça de quem assiste e só fecha no fim
- O que aparece na tela e o que está escrito (pelas fotos das cenas)

**A promessa**
- O que a pessoa espera ganhar se ficar, e quando o vídeo entrega: aos poucos ou só no fim
- O vídeo cumpre? Se não cumpre, é viral de clickbait: diga isso e não leve

**Os laços abertos**
- Cada pergunta que abre ("mas tem um problema", "só que...", "e o pior vem agora") e onde ela fecha, com os tempos
- Quanto tempo o vídeo passa sem nenhum laço aberto: é ali que a pessoa sai

**A estrutura**
- As partes, com o tempo de começo de cada uma: o gancho, o começo, cada volta (problema → solução) e o fim
- De quantos em quantos segundos aparece um problema novo
- Compare com o esqueleto da Máquina (`metodo/formula-roteiro.md`; na IA de chat: gancho → "Se você..." → voltas de
  "Mas... / Então você... / Esse é o..." → "Coloque... Agora é só..." → o pedido do fim)

**As frases**
- Palavras por frase (conte 10 frases) e quantas passam de 15 palavras
- "Você" ou "eu": quem é o herói da história
- As palavras que se repetem de propósito ("Mas", "Então")
- Os números, as comparações caseiras, os "é por isso que", as dicas e as quebras de mito, com os tempos
- A palavra difícil: aparece antes ou depois do que ela faz

**A emoção**
- Onde dá raiva, medo, riso, surpresa ou alívio, com o tempo
- Quem sofre na história, e a vitória do fim

**O fim e o pedido**
- As últimas 3 frases: fecham o laço do gancho? Tem vitória?
- O pedido: qual, quantos e onde (falado, escrito, no comentário). Por que dá vontade de comentar ou de mandar

**O texto em volta**
- O título, a legenda do post e a capa conversam com o gancho?
- As hashtags e as palavras de busca

## 4. As melhores conclusões

- **Prova, não opinião:** cada conclusão com o tempo e a frase (ou a cena) que prova
- **Causa, não enfeite:** use o teste de tirar. "A trilha é boa" não é conclusão; "um problema novo a cada 9 segundos
  segura, e a atenção cai onde não tem problema" é
- **Você só vê o que deu certo.** Se der, estude também um vídeo fraco do mesmo canal: o que muda entre os dois é a
  pista mais forte
- **A força de cada conclusão:**
  - **Pista:** apareceu em 1 ou 2 virais
  - **Padrão:** em 3 ou mais, de canais diferentes
  - **Regra:** testado no canal da pessoa, e deu número. Só a regra vai pro `canal/aprendizados.md`, com o OK dela
- **Útil pro canal:** toda conclusão vira algo que dá pra fazer no próximo vídeo, com um exemplo pronto no tema do
  canal da pessoa (um gancho escrito, uma estrutura com as peças dela)
- **Combina com o canal?** Se o viral usa algo que não combina com o tom do canal (palavrão, susto pesado, polêmica
  sem os dois lados), diga e não leve
- **Nunca copie:** nem frase, nem piada, nem a sequência de peças. Leve o esqueleto

## 5. O formato da resposta

Escreva assim. A Máquina lê os títulos `##` pra montar o caderno, então não mude os nomes deles:

```
# Estudo: <título do vídeo>

## Conclusão
- **Por que viralizou:** <uma frase, com o número (views por dia ou views ÷ seguidores)>
- **O que fez o trabalho:** <tema, gancho, roteiro, visual ou momento, em ordem, e por quê>
- **O gancho:** "<a frase exata>" (<o tipo>)
- **O esqueleto:** <numa linha: gancho → ... → pedido do fim>
- **A melhor técnica de texto:** <a mais forte, com o tempo>
- **Pra usar no canal:** <de 1 a 3 coisas, cada uma com um exemplo pronto no tema do canal>

## Os números
## O gancho
## A promessa e os laços
## A estrutura
## As frases
## A emoção
## O fim e o pedido
## O texto em volta

## O que se repete
- <só se o caderno já tem outros vídeos: a lista inteira, nova, no formato do caderno>

## Pra testar no próximo vídeo
- <um teste só: o que mudar, em qual vídeo e o número que vai decidir>
```

Pra pessoa, mostre **só a Conclusão e o teste**, curto. O estudo inteiro fica guardado.

## 6. Onde guardar

- **IA que trabalha na pasta:** salve tudo em `estudos/<pasta>/analise.md`. No caderno
  (`estudos/virais-estudados.md`), troque a linha "**Conclusão:** ainda não estudado..." do vídeo pelas linhas da sua
  Conclusão, e reescreva "O que se repete" e "Pra testar no próximo vídeo". Não mude a linha do título nem a dos
  números do vídeo (a Máquina usa as duas)
- **IA de chat:** termine com: "Copie esta resposta inteira e cole no painel, no vídeo, em **Guardar a resposta da
  IA**." O painel guarda o estudo e atualiza o caderno sozinho

## 7. Comparar vários

Quando a pessoa pedir ("compara os virais", "o que eles têm em comum?"), ou a cada 3 vídeos novos no caderno: leia o
caderno inteiro, monte uma tabela curta (o vídeo, as views por dia, views ÷ seguidores, o tipo de gancho, a duração,
as palavras por minuto e o pedido do fim) e reescreva "O que se repete", com a força de cada padrão. Proponha **um**
teste pro próximo vídeo do canal: o padrão mais forte que o canal ainda não usa, com o número que vai decidir (os
números de cada rede estão em `viralizar/medir-e-testar.md`).

## 8. Que viral estudar

- Do mesmo nicho do canal, ou de um nicho vizinho com o mesmo formato
- Views ÷ seguidores acima de 3, de preferência dos últimos 3 meses
- De canais diferentes: 3 virais do mesmo canal mostram o jeito daquele canal, não um padrão
- Onde achar: no YouTube, busque o assunto e filtre por Shorts; no TikTok, busque o assunto e veja os mais curtidos;
  no Instagram, busque o assunto e abra a aba Reels. Abra o perfil e compare com os outros vídeos do canal: o viral é
  o que destoa
- Um vídeo fraco do mesmo canal, pra comparar (o passo 4)
