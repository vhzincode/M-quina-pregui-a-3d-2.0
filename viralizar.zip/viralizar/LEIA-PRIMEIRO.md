# Viralizar: tudo num lugar só

> Pra você e pra sua IA. Aqui fica tudo que a Máquina sabe sobre fazer vídeo curto viralizar: as dicas, cada rede
> social, os horários, as configurações, os cuidados, os números e como estudar os virais dos outros. No painel, é o
> menu **Estudar virais**, com uma aba pra cada assunto, e o menu **🏆 Conquistas**.

## O que tem aqui

| Arquivo | O que tem | Quando a IA lê |
|---|---|---|
| `dicas.md` | Todas as dicas, numeradas, do tema ao que fazer depois de postar | Antes de escolher o tema e de escrever o roteiro, e quando a pessoa pergunta "como faço viralizar?" |
| `estudar-copy.md` | Como estudar a copy (o texto) de um viral e tirar as melhores conclusões | Quando a pessoa pede pra estudar um viral (o passo a passo é o `comandos/estudar-viral.md`) |
| `youtube.md` | YouTube Shorts: como ele escolhe quem vê, o que marcar ao postar, música, dinheiro, os números e os cuidados | Na hora de postar no YouTube e nas dúvidas dele |
| `instagram.md` | Instagram (Reels): o mesmo, pro Instagram | Na hora de postar no Instagram e nas dúvidas dele |
| `tiktok.md` | TikTok: o mesmo, pro TikTok, e conta pessoal ou comercial | Na hora de postar no TikTok e nas dúvidas dele |
| `horarios.md` | Os horários que mais rendem, quantos vídeos por semana e como achar o horário do seu público | Quando a pessoa pergunta a hora de postar ou quantos vídeos fazer |
| `cuidados.md` | O que derruba o alcance, tira o dinheiro ou faz perder a conta (IA, música, crianças, golpes) | Antes de postar algo diferente, e quando a pessoa pergunta "pode?" |
| `medir-e-testar.md` | Que números olhar em cada rede e como testar uma mudança de cada vez | Quando a pessoa traz os números de um vídeo |
| `conquistas.md` | As três trilhas de conquistas (ritmo, alcance e seguidores) e o que fazer a cada conquista | Quando a pessoa conta que bateu um número |

E três lugares que são da pessoa (a versão nova da Máquina não apaga):

- `estudos/virais-estudados.md`: **o caderno dos virais**, com cada viral estudado, a conclusão de cada um, o que se
  repete entre eles e o próximo teste
- `canal/aprendizados.md`: o que já deu certo no canal dela
- `canal/conquistas.json`: as conquistas que ela já bateu (a Máquina lê o YouTube e marca; `npm run conquistas`)

## Quem vale mais quando dois arquivos discordam

1. O que a pessoa pediu na conversa
2. `canal/aprendizados.md` (o gosto dela e o que deu resultado no canal dela)
3. `canal/metodo.md` (o que ela mudou no método, no painel em Meu canal → Os roteiros)
4. `metodo/formula-roteiro.md` e `metodo/ritmo-e-visual.md` (as regras do roteiro e do ritmo)
5. Os arquivos desta pasta

## Pra IA

- Não leia tudo de uma vez: leia o arquivo do assunto que a pessoa perguntou
- Responda curto: a dica, o motivo e o número quando tiver (a fonte está no fim de cada arquivo)
- Regra de rede muda. O que tem data aqui foi conferido nessa data: se a pessoa disser que no app dela está diferente,
  vale o app
- Toda ideia nova entra como teste num vídeo e só vira regra com número (`medir-e-testar.md`)
- Facebook: o mesmo vídeo do Instagram, com "Compartilhar no Facebook" ligado na hora de postar o Reel
