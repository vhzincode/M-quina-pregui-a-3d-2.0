# Instagram (Reels)

> Pra você e pra sua IA: como o Instagram escolhe quem vê, o que marcar na hora de postar, os números e os cuidados.
> Conferido em novembro de 2026. As redes mudam: se o app estiver diferente, vale o app.

## Como o Instagram decide quem vê

- O chefe do Instagram disse quais sinais mais pesam pra mostrar um Reel: **o tempo que a pessoa assiste, as
  curtidas e os envios** (quantos mandam o vídeo pra alguém pelo direct). E mandou olhar 3 números: o tempo médio
  assistido, as curtidas por alcance e os **envios por alcance** (Adam Mosseri, janeiro de 2025)
- **O envio é o que leva o vídeo pra quem não segue o perfil.** No canal feito com este método, o vídeo mais enviado
  (53 mil envios) foi o mais visto do canal. E o vídeo que menos gente pulou no começo foi um dos que menos foram
  enviados: a pessoa ficou, mas não tinha pra quem mandar
- **O original vem na frente:** quando o mesmo vídeo aparece em mais de uma conta, o Instagram recomenda o original e
  troca a cópia por ele, e a conta que vive de repostar sai das recomendações (atualização de abril de 2024)
- **Marca d'água de outro app** (o logo do TikTok, de um editor) deixa o vídeo menos recomendado

## O formato

- Vertical, 9:16. Reels de **até 3 minutos** podem ser recomendados (antes era até 90 segundos)
- A Máquina já sai no formato certo. Envie o `video.mp4` original, nunca um baixado do TikTok ou do YouTube
- No app: Configurações → Uso de dados e qualidade da mídia → ligue **"Carregar com a qualidade mais alta"**. Sem
  isso, o Instagram aperta o vídeo e ele fica borrado (o nome muda um pouco de celular pra celular)

## Na hora de postar

1. **Capa:** em "Editar capa", envie a `capa.png` ("Adicionar da galeria"). A grade do perfil corta em 3:4: depois de
   postar, confira se a pergunta e o rosto ficaram dentro
2. **Legenda:** a descrição do `publicacao.md`. Só a primeira linha aparece sem tocar: comece pela pergunta
3. **Hashtags: no máximo 5.** O Instagram não aceita mais que 5 desde dezembro de 2025. O tema, 2 do nicho e a do
   canal; #reels, #viral e #explore não ajudam
4. **Áudio:** o da Máquina, que já está no vídeo ("áudio original"). Não troque por música famosa: conta
   profissional tem uma biblioteca de músicas limitada, e música sem direito tira o som ou derruba o vídeo
5. **Rótulo de IA:** a Meta pede o aviso em vídeo que parece real e em **áudio realista feito por IA**. Animação com
   cara de desenho fica fora da regra. Voz de IA que soa como gente pode cair nela: na dúvida, marque o rótulo (nas
   configurações avançadas, antes de postar). O castigo é pra quem esconde, e a Meta pode pôr o rótulo sozinha
6. **Compartilhar no Facebook:** ligue, se você tiver uma Página. É alcance a mais, de graça
7. **Comentário:** fixe o comentário do `publicacao.md` logo depois de postar

## Reels de teste

- Com 1.000 seguidores e a conta pública, dá pra postar um **Reel de teste**: ele aparece primeiro só pra quem não
  segue. Se for bem, você compartilha com os seguidores
- Serve pra testar duas capas ou dois ganchos do mesmo vídeo sem cansar quem segue. Mas costuma ter menos alcance que
  o Reel normal: use pra testar, não em todo vídeo

## Os números (Insights do Reel)

- **A % que pulou nos 3 primeiros segundos:** passou de 35%, o gancho ou a capa falharam
- **Tempo médio assistido** e quantos chegaram ao fim
- **Envios** (divida pelas views e multiplique por mil): o que espalha. No canal, os melhores ficaram entre 45 e 60
  envios a cada mil views; o pior, 2,2
- **Salvamentos:** vídeo com dica que dá pra usar é salvo
- **Alcance de quem não segue** e **seguidores que vieram do Reel**
- **Horários mais ativos:** Insights → Total de seguidores → Horários mais ativos (`horarios.md`)
- **Status da conta** (Configurações → Status da conta): diz se os seus posts podem ser recomendados. Com um aviso lá,
  o alcance cai até você resolver

## O que já vimos no Instagram (um canal feito com este método)

- Dinheiro e sociedade foi o tema mais forte no Instagram (61 mil views de média), mesmo perdendo mais gente no
  começo (41% pulam nos 3 s): quem fica vai até o fim
- O gancho com contradição perdeu 26% nos 3 primeiros segundos; os outros, 31%; o "Como funciona X?", 40%
- Pedir no vídeo pra comentar uma palavra e mandar o link no direct (com uma resposta automática, como o ManyChat)
  trouxe 30 vendas em 3 dias, contra 17 do link da bio no mesmo período. Só funcionou com o pedido falado no vídeo:
  escrito só no comentário, quase ninguém pediu
- O vídeo mais caprichado no visual foi o pior em envios (2,2 a cada mil): visual é o mínimo, o tema e o roteiro
  espalham

## Cuidados no Instagram

- Repostar vídeo dos outros tira a conta das recomendações
- Marca d'água de outro app derruba o alcance
- Mais de 5 hashtags não entra
- Comprar seguidor ou curtida, ou entrar em "grupo de engajamento", derruba o alcance
- A mesma mensagem mandada pra muita gente no direct é tratada como spam
- Link na legenda não é clicável: use a bio ou o direct

## De onde vem

- Adam Mosseri (chefe do Instagram), vídeo de janeiro de 2025 sobre os sinais que mais pesam; o limite de 5
  hashtags, anunciado por ele em 19/12/2025 (noticiado por Social Media Today e Business Today)
- Instagram, recomendações que dão preferência ao conteúdo original (30/04/2024, noticiado por Engadget e Gigazine)
- Reels de 3 minutos e Reels de teste: anúncios do Instagram (noticiados por Engadget e Social Media Today)
- Meta, central de ajuda: o rótulo de IA
- Os números do canal: API do Instagram, de 26/10 a 05/11/2026
