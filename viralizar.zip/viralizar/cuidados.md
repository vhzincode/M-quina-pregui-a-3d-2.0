# Cuidados e riscos

> Pra você e pra sua IA: o que derruba o alcance, tira o dinheiro ou faz perder a conta, nas 3 redes. Conferido em
> novembro de 2026. Antes de postar algo diferente do normal, a IA confere aqui.

## O que mais derruba (e é fácil evitar)

1. **Repostar vídeo dos outros**, mesmo editado, mesmo com crédito, mesmo com permissão: o YouTube não paga
   ("conteúdo reutilizado"), o Instagram troca pelo original e tira a conta das recomendações, e o TikTok tira do
   "Pra você". Os vídeos que você baixa no **Estudar virais** são pra estudar, nunca pra postar
2. **Vídeo feito em série, tudo igual:** o YouTube não paga canal de vídeos repetitivos, "com cara de feito com
   molde" e com pouca variação. Cada vídeo da Máquina com um tema, um roteiro e cenas próprios. A mesma abertura e o
   mesmo fim podem
3. **Música famosa:** no YouTube, Short com mais de 1 minuto que recebe uma reivindicação de direito autoral fica
   bloqueado no mundo inteiro. Use só os sons da Máquina, música sua ou da Biblioteca de áudio do YouTube
4. **Marca d'água de outro app:** poste sempre o arquivo original da Máquina
5. **Engajamento falso:** comprar seguidor, curtida ou view, "sub4sub", grupo de engajamento. As redes apagam o falso
   e o alcance cai junto
6. **Pedir curtida, presente ou seguidor em troca de algo:** o TikTok tira o vídeo do "Pra você"
7. **Muitos pedidos no mesmo vídeo** (curte, segue, comenta, manda, link): o vídeo com cara de anúncio é menos
   mostrado. Um pedido só

## IA: o que pode e o que não pode

- **Pode:** usar IA no roteiro, na voz e nas cenas. Animação com cara de desenho não precisa do aviso de IA no
  YouTube, no Instagram nem no TikTok
- **Marque o aviso de IA** quando o vídeo parece real: uma pessoa, um lugar ou um acontecimento de verdade, mostrado
  fazendo o que não fez ou acontecendo o que não aconteceu. No Instagram e no Facebook, a regra também vale pra
  **áudio realista feito por IA**: com voz de IA que soa como gente, na dúvida, marque. Marcar não é castigo; o
  castigo é pra quem esconde
- **Nunca:** imitar a voz ou o rosto de uma pessoa real (um famoso, um político, alguém da sua família) sem
  autorização, nem fazer parecer que alguém disse o que não disse
- **No YouTube, não ganha dinheiro:** personagem de IA dando conselho de saúde, dinheiro, lei ou política como se
  fosse especialista
- **A licença da voz:** canal que ganha dinheiro (monetização, publi, venda de produto) é uso comercial. Na
  ElevenLabs, a licença comercial começa no plano Starter: o plano grátis não tem (página de preços da ElevenLabs,
  novembro de 2026). Pra aprender e testar, o grátis serve; antes de monetizar, narre os vídeos num plano pago. Usa
  outra voz? Confira a licença dela do mesmo jeito

## Saúde, dinheiro, notícia e polêmica

- Confira o número antes de falar. Simplificar pode, inventar não
- **Saúde:** nada de "cura", dose de remédio ou promessa. Informação errada de saúde tira o vídeo do "Pra você" no
  TikTok e pode derrubar o vídeo nas outras redes
- **Dinheiro:** explique como funciona; nunca diga onde a pessoa deve investir
- **Notícia:** com a data e a fonte. Informação não confirmada sobre crise ou eleição fica fora do "Pra você"
- **Polêmica:** neutra, com os dois lados e com número. Em guerra e tragédia, o desastre é do sistema (o navio
  parado, o preço subindo), nunca gente ferida

## Feito para crianças (YouTube)

- Desenho animado e personagem fofo estão na lista do que o YouTube olha pra decidir se um vídeo é pra criança. Mas a
  própria regra diz que "animação que agrada todo mundo" é público geral
- Vídeo marcado como pra crianças perde os comentários e os anúncios personalizados (os que pagam mais), e passa a
  aparecer junto de vídeo infantil
- Canal pra todo mundo: marque "não é para crianças", fale com "você" sobre coisa do dia a dia e não use título, capa
  ou hashtag voltados pra criança
- Quem responde por isso é você: marcar errado de propósito pode dar problema com a lei americana de proteção de
  crianças (a COPPA)

## A conta

- **Verificação em 2 etapas** ligada nas 3 redes
- **Golpe comum:** e-mail ou direct dizendo que o seu canal "vai ser apagado por direito autoral" ou que você "ganhou
  o selo de verificado", com um link. Confira só dentro do app (YouTube Studio, Status da conta do Instagram, TikTok
  Studio) e nunca ponha a senha num link
- O mesmo @ nas 3 redes ajuda a pessoa a achar você. E não troque o nome e o @ toda hora: confunde quem segue e a
  busca
- Não apague e reposte o mesmo vídeo pra "dar outra chance": a rede pode tratar como repetido, e vídeo parado às
  vezes volta a crescer semanas depois

## "Shadowban" existe?

- As redes não usam esse nome, mas existe "não pode ser recomendado". Confira: Instagram → Configurações → **Status
  da conta**; TikTok → os números do vídeo avisam se ele não pode ser recomendado; YouTube → os avisos no Studio
- Sem aviso, a queda é do vídeo (o gancho, o tema), não castigo: veja os números (`medir-e-testar.md`)

## Dados pessoais

- Nunca mostre na tela: CPF, endereço, placa de carro, telefone, e-mail, senha, chave de API, extrato
- Gravando a tela do computador? Esconda as abas, as notificações e os nomes de quem aparece

## De onde vem

- YouTube, central de ajuda: políticas de monetização (conteúdo não autêntico e reutilizado, 15/07/2025), conteúdo
  alterado ou sintético, Shorts de três minutos, conteúdo para crianças
- TikTok, Diretrizes da Comunidade: integridade e autenticidade; padrões de elegibilidade do "Pra você"
- Meta, central de ajuda: o rótulo de IA. Instagram: recomendações do conteúdo original (30/04/2024)
- ElevenLabs, página de preços (novembro de 2026): "Commercial License" a partir do plano Starter
