# YouTube Shorts

> Pra você e pra sua IA: como o Shorts escolhe quem vê, o que marcar na hora de postar, música, dinheiro, os números
> e os cuidados. Conferido em novembro de 2026. As redes mudam: se o app estiver diferente, vale o app.

## Como o Shorts decide quem vê

- O Shorts mostra o vídeo primeiro pra um grupo pequeno. Se esse grupo **para de rolar** (não desliza pro próximo),
  assiste até o fim, vê de novo, compartilha e comenta, ele mostra pra mais gente. Por isso o gancho e o fim pesam
  tanto
- A maior parte das views vem do feed do Shorts, de gente que não segue o canal. Ter muito inscrito não garante view
- Um Short pode voltar a crescer dias ou semanas depois. Não apague o vídeo que foi mal

## O formato

- Vertical (9:16) ou quadrado, **até 3 minutos** (YouTube, central de ajuda)
- A Máquina já sai no formato certo (1080x1920, H.264, som AAC, volume em −14 LUFS): não precisa mudar nada
- Envie o `video.mp4` da Máquina, nunca um vídeo baixado de outra rede

## Na hora de postar

1. **Título:** a pergunta de busca, até ~60 caracteres (o limite é 100), sem hashtag (o `publicacao.md` traz pronto)
2. **Descrição:** a do `publicacao.md`, com até 5 hashtags no fim
3. **Capa:** em "Capa" (ou "Miniatura"), escolha o **1º quadro**: é a própria capa da Máquina. Se o seu app deixar
   enviar imagem, envie a `capa.png`
4. **Público: "Não, não é conteúdo para crianças"**, se o canal é pra todo mundo. É obrigatório responder, e quem
   responde é você (veja "Feito para crianças", abaixo)
5. **Conteúdo alterado ou sintético** (o aviso de IA): marque "Sim" só se o vídeo parece real: uma pessoa de verdade
   fazendo o que não fez, um lugar ou acontecimento real alterado, uma cena realista que não aconteceu. Animação com
   cara de desenho não precisa. Usar IA no roteiro, na capa ou no título também não (YouTube, central de ajuda)
6. **Vídeo relacionado:** ligue o Short a um vídeo seu mais longo ou ao próximo da série. É o único link clicável que
   o Short tem
7. **Comentários abertos**, e fixe o comentário do `publicacao.md` logo depois de postar
8. **Idioma do vídeo:** o idioma do canal. Ajuda a legenda automática e a busca

## Música e direito autoral

- **Short com mais de 1 minuto que recebe uma reivindicação de direito autoral (o Content ID) fica bloqueado no mundo
  inteiro**, até a reivindicação sair. Short de até 1 minuto não tem essa trava (YouTube, "Shorts de três minutos")
- Então: só a trilha e os sons da Máquina, música sua ou da **Biblioteca de áudio do YouTube**, que não gera
  reivindicação. Música famosa, nunca, nem baixinha no fundo
- Trecho de vídeo dos outros, nunca (`cuidados.md`)

## Ganhar dinheiro (o Programa de Parcerias)

- **Pra entrar:** 1.000 inscritos + 10 milhões de views válidas de Shorts nos últimos 90 dias, ou 1.000 inscritos +
  4.000 horas de vídeo longo nos últimos 12 meses (YouTube, central de ajuda)
- **Não ganha dinheiro** (a regra do "conteúdo não autêntico", de 15/07/2025): vídeo "com cara de feito com molde",
  repetitivo, "com pouca variação entre os vídeos"; vídeo de IA feito com modelo genérico; e personagem de IA dando
  conselho de saúde, dinheiro, lei ou política como se fosse especialista
- **Pode:** usar IA e ferramentas automáticas, desde que o vídeo tenha a sua história e o seu jeito. A própria regra
  dá o exemplo: usar IA pra mostrar um personagem e uma história que você criou. A mesma abertura e o mesmo fim em
  todos os vídeos também podem, desde que o miolo mude
- **Na prática, com a Máquina:** cada vídeo com um tema novo, um roteiro escrito só pra ele e cenas diferentes. A
  revisão do YouTube olha o canal: muitos vídeos quase iguais podem tirar o canal todo do programa
- **A voz:** canal monetizado é uso comercial. Confira se a licença da voz deixa (`cuidados.md`, "IA")

## Os números (YouTube Studio)

- **Visualizações engajadas:** desde 24/08/2026, a "view" conta desde o 1º quadro, e as visualizações engajadas são
  as de quem escolheu continuar assistindo. Pra comparar um vídeo com outro, use as engajadas (Studio → Análise →
  Modo avançado). O dinheiro e a entrada no programa usam as engajadas
- **Quantos viram e quantos deslizaram** (em inglês, "Viewed vs. swiped away"): o gancho e a capa
- **Duração média e % visualizada:** o roteiro
- **Inscritos a cada mil views:** se o vídeo traz gente pro canal
- **Compartilhamentos:** o que espalha
- **Origem do tráfego:** feed do Shorts, busca, página do canal, vídeo relacionado
- **Quando o seu público está no YouTube:** Studio → Análise → Público. É o seu melhor horário (`horarios.md`)

## O que já vimos no YouTube (um canal feito com este método)

- Bicho do dia a dia foi o mais rápido: 226 mil views em 48 h, em média
- Dinheiro e sociedade começou mais devagar (106 mil em 48 h, em média), mas comentou 7 vezes mais por view e cresceu
  por dias
- O vídeo mais viral trouxe menos inscritos por view (4,4 a cada mil) que os de curiosidade pura (de 10 a 11)
- Um vídeo de pesca voltou a acelerar uma semana depois de postado: +372 mil views em 36 h

## Feito para crianças

- Desenho animado e personagem fofo estão na lista do que o YouTube olha pra decidir se um vídeo é pra criança. Mas a
  própria regra diz que "animação que agrada todo mundo" é público geral
- Vídeo marcado como pra crianças perde os comentários e os anúncios personalizados (os que pagam mais), e passa a
  aparecer junto de vídeo infantil
- Se o canal é pra todo mundo: marque "não é para crianças", fale com "você" sobre coisa do dia a dia e não use
  título, capa ou hashtag voltados pra criança ("pra crianças", "desenho infantil")
- Marcar errado de propósito pode dar problema com a lei americana de proteção de crianças (a COPPA): quem responde é
  você, não o YouTube

## Cuidados no YouTube

- Não poste o mesmo vídeo duas vezes no canal
- Não compre inscrito nem view, nem troque inscrição ("sub4sub"): o YouTube tira as views falsas e o canal perde força
- E-mail ou mensagem dizendo que o canal "vai ser apagado por direito autoral", com um link, é golpe. Confira só
  dentro do YouTube Studio

## De onde vem

- YouTube, central de ajuda: "Políticas de monetização de canais do YouTube" (conteúdo não autêntico e reutilizado,
  atualização de 15/07/2025), "Divulgação de conteúdo alterado ou sintético", "Entenda os Shorts de três minutos",
  "Programa de Parcerias do YouTube: qualificação", "Definir se o conteúdo é para crianças", "Enviar Shorts"
- A view desde o 1º quadro (24/08/2026): anúncio do YouTube, noticiado por Android Authority e vidIQ
- Os números do canal: API do YouTube, de 25/10 a 05/11/2026
