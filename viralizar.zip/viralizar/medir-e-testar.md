# Medir e testar

> Pra você e pra sua IA: que números olhar em cada rede, o que cada um quer dizer e como testar uma mudança de cada
> vez. É assim que o canal aprende o que funciona com o público dele.

## Os 3 números de todo vídeo

1. **A % que pula nos 3 primeiros segundos:** o gancho e a capa
2. **Os envios a cada mil views** (envios no Instagram, compartilhamentos no YouTube e no TikTok): o que espalha
3. **As views por hora nas primeiras 24 horas:** a largada. Compare sempre na mesma idade

E de vez em quando:

4. **Seguidores a cada mil views:** se o vídeo traz gente pro canal
5. **Quantos chegam na metade e no fim:** o roteiro

## Onde ver cada um

| O que mede | YouTube (Studio) | Instagram (Insights do Reel) | TikTok (TikTok Studio) |
|---|---|---|---|
| O gancho | Quantos viram e quantos deslizaram | % que pulou nos 3 primeiros segundos | O começo do gráfico de retenção |
| O roteiro | Duração média, % visualizada, retenção | Tempo médio assistido | Tempo médio, % que assistiu inteiro |
| O que espalha | Compartilhamentos | Envios | Compartilhamentos |
| Seguidores | Inscritos | Seguidores | Novos seguidores |
| De onde veio | Origem do tráfego | Alcance de quem não segue | Origem do tráfego |

No YouTube, compare as **visualizações engajadas**, não as views: desde 24/08/2026, a view conta desde o 1º quadro.

## O que fazer com cada resultado

- **Muita gente pula no começo (mais de 35%):** troque o gancho (uma pergunta com contradição) ou a capa (mais
  exagero) no próximo vídeo
- **Ficam, mas não mandam:** o tema não tem uma turma pra quem mandar, ou faltaram o "é por isso que" e a dica
- **Começa bem e cai no meio:** falta um problema novo a cada 10 a 15 segundos, ou tem cena repetida
- **Muita view e pouco seguidor:** é um tema que espalha. Equilibre com temas de curiosidade pura
- **Vai bem numa rede e mal noutra:** é a rede, não o vídeo (veja o arquivo de cada rede)
- **Caiu tudo de uma vez, em todos os vídeos:** confira o Status da conta e os avisos de cada rede (`cuidados.md`)

## A régua de um canal feito com este método

Pra começar a comparar. Depois de uns 10 vídeos, a régua é a do seu canal.

| Número | Os melhores | A média | Os mais fracos |
|---|---|---|---|
| % que pula nos 3 s (Instagram) | 22% a 28% | ~32% | 40% a 46% |
| Envios a cada mil views (Instagram) | 45 a 60 | | 2 a 3 |
| Inscritos a cada mil views (YouTube) | 10 a 11 | 5,9 | 4,4 |

## Como testar uma coisa

1. **Uma mudança por vez:** o gancho, ou a capa, ou o horário, ou o fim. Mudou duas, não dá pra saber qual funcionou
2. **O resto igual:** o mesmo tipo de tema e o mesmo horário
3. **Pelo menos 3 vídeos de cada jeito.** Com 1 ou 2, é palpite
4. **Decida antes qual número vai julgar** ("a % que pula nos 3 s no Instagram") e compare na mesma idade
5. **Anote:** o teste em andamento vai no caderno dos virais (`estudos/virais-estudados.md`, "Pra testar no próximo
   vídeo"); quando ele fechar, o resultado vai pro `canal/aprendizados.md`

## Onde anotar

- Os números de cada vídeo: `canal/pauta.md` (a coluna Resultado) e `canal/historico.md`
- O que virou regra no seu canal: `canal/aprendizados.md`, em "O que dá resultado nas redes"
- O que veio dos virais dos outros: `estudos/virais-estudados.md`

## Pra IA

- Quando a pessoa trouxer os números, compare com os outros vídeos dela, diga em 1 ou 2 frases o que você acha que
  pesou (o tema, o gancho, a capa, o tamanho, o horário) e proponha um teste só
- Com poucos vídeos, é palpite: fale como palpite
- O mesmo resultado em 3 vídeos vira regra no `canal/aprendizados.md`
