# Conquistas

> Pra você e pra sua IA. O caminho de quem cresce com a Máquina, em três trilhas, e o que fazer a cada conquista:
> mostrar pro mundo e ganhar mais alcance com isso. No painel, é o menu **🏆 Conquistas**: a Máquina lê o seu YouTube
> sozinha, marca cada conquista e monta a arte do story pra você postar.

## As três trilhas

Cada trilha segue um número só, que só sobe. Por isso uma conquista nunca chega antes da anterior. O seu **nível** é a
soma das três: são 14 conquistas.

### 🎬 Ritmo: os vídeos postados

| # | Conquista | Por que importa |
|---|---|---|
| 1 | 🎬 Primeiro vídeo no ar | O mais difícil é começar. Agora é ritmo |
| 2 | 🔟 10 vídeos postados | Constância: é ela que faz a rede confiar no canal |
| 3 | 📅 30 vídeos postados | Um mês de ritmo. A partir daqui, os seus números começam a ensinar |
| 4 | 💯 100 vídeos postados | Pouca gente chega aqui. O seu canal já é um acervo que trabalha sozinho |

### 👀 Alcance: as views do seu vídeo mais visto

| # | Conquista | Por que importa |
|---|---|---|
| 1 | 👀 1 mil views num vídeo | A rede mostrou o seu vídeo pra gente que não te conhece |
| 2 | 🚀 10 mil views num vídeo | Um vídeo que espalhou de verdade |
| 3 | 🔥 100 mil views num vídeo | O primeiro grande viral |
| 4 | 🌎 1 milhão de views num vídeo | O viral de verdade |
| 5 | 🌌 10 milhões de views num vídeo | Um vídeo que o país inteiro viu. Lenda |

### 🙋 Seguidores: os inscritos (ou os seguidores, na rede em que você tem mais)

| # | Conquista | Por que importa |
|---|---|---|
| 1 | 🙋 100 seguidores | Gente que quer ver o seu próximo vídeo |
| 2 | ⭐ 1 mil seguidores | No YouTube, é o número de inscritos que o programa que paga pelos vídeos pede, junto com as views |
| 3 | 💎 10 mil seguidores | No TikTok, é o número de seguidores que os guias citam pro Programa de Recompensas |
| 4 | 🥈 100 mil seguidores | No YouTube, é a Placa de Prata |
| 5 | 👑 1 milhão de seguidores | No YouTube, é a Placa de Ouro. Lenda |

## Como a Máquina sabe os seus números

- Ela lê o seu canal do YouTube pelo **@ nas redes** que está em **Meu canal**: os inscritos, os vídeos postados e as
  views de cada vídeo. É o mesmo que qualquer pessoa vê no seu canal: **sem senha, sem login e sem chave**
- Ela lê quando você abre as Conquistas (no máximo a cada 3 horas) e quando você toca em **Ler agora**. Na primeira
  vez, ela baixa o leitor do YouTube (o mesmo do Estudar virais), uma vez só
- Os números vêm como o YouTube mostra no app ("29 mil", "1,5 milhão"), sempre arredondados pra baixo: uma conquista
  nunca chega antes da hora
- **No Instagram e no TikTok**, esses números só aparecem com login, e a Máquina nunca pede a sua senha. Bateu uma
  conquista lá? Toque em **Bati esse marco**. As de antes, na mesma trilha, também ficam marcadas
- A Máquina não achou o seu YouTube? Confira se o @ em Meu canal é o mesmo do YouTube. Se o do YouTube for outro,
  escreva ele na tela das Conquistas (o campo aparece quando ela não acha)

## Bateu uma conquista? Faça isto, no mesmo dia

1. **Abra a conquista no painel** (🏆 Conquistas → **Compartilhar**). A arte do story já vem pronta, com o nome do
   canal e o seu nível: a capa do vídeo que bateu a marca (Alcance), os seus vídeos mais novos (Ritmo) ou a foto do seu
   canal (Seguidores)
2. **Quer o número de verdade na arte?** Tire o print que vale (a tabela abaixo) e ponha na arte. Esconda o que for
   pessoal (e-mail, valores, notificações)
3. **Baixe a arte e poste no story do Instagram** com:
   - a figurinha de **menção** marcando **@desconstruindouniverso**: a gente reposta nos stories (o máximo que der), e
     quem vê lá conhece o seu canal
   - a figurinha de **link** pro vídeo ou pro seu perfil: quem gostar toca e vai direto
   - o seu @, escrito grande
4. **Sem Instagram?** Mande no canal 🏆・conquistas do Discord da comunidade (discord.gg/jywFJ35jN) ou pro e-mail
   desconstruindouniverso@gmail.com
5. **Comemore no Discord** (🏆・conquistas): a galera comemora junto, e quem está começando vê que dá

| Trilha | O print que vale |
|---|---|
| 🎬 Ritmo | A grade do seu perfil (na primeira, o vídeo postado, aberto no seu perfil) |
| 👀 Alcance | O vídeo com o número de views |
| 🙋 Seguidores | O seu perfil com o número de seguidores |

## Por que isso dá alcance

- O story repostado mostra o seu canal pra quem segue o @desconstruindouniverso: gente que gosta de vídeo curto
  feito com IA, e que segue canais assim
- Poste no mesmo dia: enquanto o vídeo está subindo, o story manda mais gente pra ele, e a rede vê o vídeo crescendo
- Cada conquista é um story novo. Quem viu a de 1 mil e vê a de 10 mil começa a acompanhar o seu canal
- Número de verdade convence. Nunca poste número inventado ou print editado: é público, e derruba a confiança no seu
  canal

## Ganhe com o seu resultado

- Quem vê o seu story vai querer fazer igual. Com o link de afiliado, você ganha 50% de cada Máquina vendida pelo seu
  link, com aprovação na hora: https://app.cakto.com.br/affiliate/invite/c65a283a-2700-4227-ab54-a5b4ee45f60a
- Ponha o link na bio ou na figurinha de link do story
- Mostre o seu resultado de verdade. Nunca prometa renda, prazo ou "vídeo pronto": promessa que não se cumpre vira
  reembolso e reclamação

## Pra IA

- A pessoa contou que bateu uma conquista ("bati mil views!"): comemore numa frase e rode `npm run conquistas` (lê o
  YouTube e mostra as três trilhas, em uns 20 segundos). Se a conquista apareceu, mostre os passos de "Bateu uma
  conquista?" e termine com o link do painel em Conquistas (`npm run painel -- --conquistas`)
- Foi no Instagram ou no TikTok (a Máquina não lê esses números)? Rode `npm run conquistas -- --marcar <conquista>`.
  Os nomes: `primeiro-video`, `dez-videos`, `trinta-videos`, `cem-videos` (Ritmo); `mil-views`, `dez-mil-views`,
  `cem-mil-views`, `milhao-views`, `dez-milhoes-views` (Alcance); `cem-seguidores`, `mil-seguidores`,
  `dez-mil-seguidores`, `cem-mil-seguidores`, `milhao-seguidores` (Seguidores)
- A Máquina não achou o canal: confira o "@ nas redes" do `canal/canal.md`. Se o @ do YouTube for outro, rode
  `npm run conquistas -- --youtube @canal-no-youtube`
- Não escreva no `canal/conquistas.json` à mão: o painel e o `npm run conquistas` gravam. Lá ficam a última leitura do
  YouTube (`leitura`) e cada conquista (`marcos`), com a data, o vídeo e as capas (`canal/conquistas/`); `manual` é o
  que a pessoa marcou e o YouTube ainda não confirmou
- Depois, diga qual é a próxima conquista de cada trilha (o `npm run conquistas` mostra quanto falta) e uma dica pra
  chegar lá, de `viralizar/dicas.md`
- Nunca invente número nem ajude a editar print: é público, e derruba a confiança no canal
