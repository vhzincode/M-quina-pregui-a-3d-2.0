# Todas as dicas pra viralizar

> Pra você e pra sua IA. Tudo que a Máquina sabe sobre vídeo curto que viraliza, do tema ao que fazer depois de
> postar, numa lista numerada (a IA pode citar "a dica 19"). Os números vêm dos vídeos de "como funciona" que passaram
> de 1 milhão de views e de um canal feito com este método (as fontes estão no fim). As regras completas que a IA segue
> ao escrever ficam em `metodo/formula-roteiro.md` e `metodo/ritmo-e-visual.md` (no painel, em Meu canal → Os
> roteiros, onde você pode mudar). O que você mudou lá, e o que já deu certo no seu canal, vale mais que esta lista.
>
> "Em teste" quer dizer: funcionou uma vez, ainda sem número pra virar regra.

## 1. O tema (antes de escrever)

1. **Viraliza o vídeo que a pessoa manda pra alguém.** Segurar até o fim ajuda, mas quem espalha é o envio. Antes de
   escrever, pergunte: "pra quem essa pessoa vai mandar?" O vídeo mais visto do canal (mais de 3,5 milhões de views)
   foi o mais enviado: 53 mil envios no Instagram.
2. **As 3 perguntas do tema. Dois "sim" e o tema é forte:** a pessoa já viveu a cena do gancho? Tem uma turma que
   manda o vídeo pra alguém (pescador, mãe de pet, quem trabalha em obra)? Ela sai com uma dica que usa?
3. **Coisa do dia a dia que ninguém viu por dentro rende mais.** Obra e estrutura grande primeiro: num canal de "como
   funciona", a ponte fez 4,9 milhões, o arranha-céu 4,1 e o telhado 3,7; geladeira e micro-ondas, de 1,6 a 2.
4. **A água é a vilã em 7 de cada 10 virais de "como funciona":** vaza, infiltra, alaga, apodrece. Tema com água
   dando errado já tem o desastre pronto.
5. **Tema com peças escondidas** (dentro da parede, embaixo da terra, atrás do aparelho) dá pra montar peça por peça,
   e cada peça vira um pedaço do roteiro.
6. **Bicho, só quando a pessoa convive com ele** (mosquito, gato, cachorro). No YouTube, foram os mais rápidos do
   canal: 226 mil views em 48 h, em média. Bicho de outro país ficou bem abaixo.
7. **Cada tipo de tema cresce de um jeito.** No mesmo canal: bicho do dia a dia foi o mais rápido no YouTube; dinheiro
   e sociedade comentou 7 vezes mais por view e foi o melhor no Instagram (61 mil views de média), mas começou devagar
   e cresceu por dias; objeto e documentário trouxeram mais seguidor por view, mas espalharam pouco.
8. **Equilibre os dois tipos de tema:** o que espalha (tem dica e tem turma) e o que traz seguidor (curiosidade pura).
9. **Espaço e história, só com medo ou mito forte.** Sem isso, é o que mais perde gente no começo: de 33% a 36% pulam
   nos 3 primeiros segundos, contra 22% a 28% dos melhores.
10. **Assunto polêmico pode, sempre neutro:** mostra o que dá certo e o que dá errado de cada lado, com número
    conferido, e deixa a conclusão pra quem assiste. Polêmico rende comentário.
11. **A notícia que todo mundo está falando e ninguém entende** vira gancho: a manchete abre, e a peça por trás dela
    é o vídeo, que continua valendo quando a notícia esfria. Saia rápido, com a data e a fonte. (em teste)
12. **Tema que viralizou noutro canal pode**, com a sua pergunta, a sua sequência e o seu visual. Copiar a sequência
    de um vídeo deles, não.
13. **Teste rápido do tema:** dá pra fechar com "Coloque ___, ___ e [uma piada]. Agora é só ___."? E tem uns 5
    problemas que dá pra ver quebrando na tela? Se sim, o tema encaixa.
14. **Os comentários dão tema.** A dúvida e o pedido do público viram pauta (a IA anota no `canal/pauta.md`).
15. **Procure o que já deu certo no seu nicho:** busque o assunto do canal no YouTube e no TikTok e abra os vídeos com
    muito mais views que os outros do mesmo canal (o jeito está em `estudar-copy.md`, "Que viral estudar").
16. **Série puxa seguidor:** um assunto que rende vários vídeos (cada cômodo da casa, cada peça do carro) faz quem
    gostou de um seguir pra ver o próximo.

## 2. O gancho (os 3 primeiros segundos)

17. **Os 3 primeiros segundos decidem.** É onde mais gente vai embora: no canal, de 22% a 46% pularam ali, conforme o
    gancho.
18. **Uma pergunta BEM curiosa, de até ~10 palavras, que a pessoa já se fez.**
19. **Com uma contradição, segura mais:** "mesmo com", "se", "tão... e...". Com ela, 26% pularam em média no
    Instagram; com o "Como funciona X?" sozinho, 40%. Ex.: "Como um prego tão fino segura um quadro pesado?"
20. **O "Como funciona X?" sozinho é o que mais faz pular.** Junte o detalhe que deixa a coisa com cara de impossível.
21. **A resposta tem que estar no vídeo.** Gancho que não entrega vira comentário de "clickbait", e o vídeo afunda.
22. **Fala no primeiro segundo.** Nada de logo, vinheta ou "oi, pessoal". Silêncio é porta de saída.
23. **A pergunta escrita na tela enquanto é falada:** quem assiste sem som também entende.
24. **Logo depois do gancho, o personagem já vive o problema**, em movimento, e o 1º problema aparece até uns 8
    segundos (nos virais, entre 4,4 e 5,8 s).
25. **Gancho ousado pode** ("Se um tubarão morder o cabo, a internet cai?"), desde que o vídeo responda.
26. **Jeitos de gancho que funcionam (um por vídeo):** a dor do dia a dia ("a comida queima por fora e fica gelada no
    meio"), o jeito ingênuo exagerado ("e se você empilhar andares em cima da sua casa?"), o experimento caseiro, a
    contradição ("tão leve e aguenta tanto peso"), o mito que todo mundo repete e a notícia que ninguém entendeu.
27. **Proibido no gancho:** "Você sabia que...?", "Neste vídeo eu vou mostrar...", pergunta que se responde sozinha e
    promessa que o vídeo não cumpre.
28. **Gancho, título e capa conversam:** a mesma pergunta (ou bem perto dela) nos três. Quem toca na capa não pode
    sentir que caiu noutro vídeo.
29. **Em tema "chato" (dinheiro, imposto), o gancho pesa menos:** de 38% a 44% pularam com qualquer gancho, mas quem
    ficou foi até o fim (74% chegaram na metade). Não julgue esse tema só pelos 3 segundos.
30. **Abrir com vários sustos antes de explicar** (umas 5 frases do que pode dar errado antes do primeiro "Se
    você...") pode fazer mandar mais: o primeiro assim foi o mais enviado por view do canal no Instagram, com 54
    envios a cada mil. (em teste)

## 3. O roteiro

31. **Monte o objeto do zero, junto com quem assiste.** Cada peça aparece porque resolve um problema que a peça
    anterior criou.
32. **Quem assiste é o inventor: "você" o tempo todo.** "Então você põe", "você encaixa". Não é aula, é missão.
33. **O motor do roteiro:** "Se você..." (o jeito simples que dá errado) → "Mas..." (o problema novo) → "Então
    você..." (a solução) → "Esse é o..." (o nome). E repete.
34. **De 6 a 10 voltas desse motor** no vídeo pra crescer; 3 ou 4 no primeiro vídeo.
35. **Um problema novo a cada 10 ou 15 segundos.** Ver coisa quebrando prende: a pessoa fica pra ver o que quebra
    depois.
36. **O problema nasce da solução anterior.** Se dá pra trocar duas partes de lugar, virou lista de peças, e lista é
    pulada.
37. **O problema tem que dar pra ver:** racha, tomba, vaza, apaga, esquenta, derrete, cai. Nada de "perde eficiência".
38. **Um desastre que se vê em toda volta** (a casa alaga, o personagem cai). A falha é a cena mais forte.
39. **Descreva antes de nomear:** "um espelho em forma de tigela, que joga a luz pra frente. Esse é o refletor." O
    nome técnico é a recompensa.
40. **Ciência sem nome de lei:** "empurra o ar pra baixo e é empurrado pra cima", nunca "terceira lei de Newton".
41. **Os conectores se repetem de propósito** ("Mas", "Então você", "Esse é"): quem assiste começa a antecipar a
    virada.
42. **Pelo menos 2 "é por isso que..." da vida real.** É o trecho que a pessoa manda pros amigos: "é ele que faz
    aquele barulho quando você liga".
43. **Pelo menos 1 dica que dá pra usar** (o que fazer, o que evitar). É o que faz salvar e mandar: o vídeo mais
    enviado do canal tinha 6.
44. **Pelo menos 1 número concreto:** "uma pilha comum aguenta umas poucas horas acesa direto." Número gruda.
45. **Comparação caseira, de 1 a 3:** "igual a uma mangueira com o dedo na ponta". Certa antes de engraçada.
46. **Quebra de mito:** "a pilha não guarda eletricidade pronta: ela fabrica na hora."
47. **6 ou mais frases explicando o porquê** (os virais têm de 7 a 17).
48. **Frases curtas, de ~10 palavras.** No máximo 4 com mais de 15 no vídeo todo: a legenda entra palavra por
    palavra.
49. **Palavra do dia a dia:** "pra", "tá", "aí". Termo difícil só depois do que ele faz: "um tubo amarelo chamado
    eletroduto".
50. **Verbo de ação:** põe, encaixa, estica, aperta, enrola, pendura.
51. **Nada de** "basicamente", "é importante ressaltar", "você sabia que", bordão de internet ou risada escrita.
52. **O fecho dos virais:** "Coloque [2 ou 3 detalhes, o último com uma piada]. Agora é só [usar]." + a vitória do
    canal + um pedido só.
53. **Tamanho sem meio-termo:** curto e seco (1:05 a 1:50) ou longo e denso (1:55 a 2:50). O meio-termo é o que menos
    aparece entre os virais.
54. **Palavras:** ~470 em média nos virais longos; de 220 a 550 pra crescer; de 150 a 200 no primeiro vídeo.
55. **~190 palavras por minuto** (os virais vão de 188 a 198). Uma conversa normal tem de 150 a 160.
56. **Confira a ciência.** Simplificar pode, inventar não. Um erro apontado nos comentários derruba a confiança.
57. **Nenhuma frase copiada** de outro vídeo. Leve a estrutura, nunca o texto.

## 4. O personagem e o humor

58. **Um personagem que sofre por nós:** sua, congela, leva choque, cai. Sofre, mas nunca é humilhado.
59. **A dor logo no começo, a vitória no fim.** Emoção boa no fim vira curtida, comentário e envio.
60. **Um ajudante (um bicho, um vizinho) pode aparecer**, com um papel na história.
61. **A mesma graça pode voltar duas vezes** (o tombo que se repete).
62. **Humor na dose:** o personagem sofrendo, a piada no último item do "Coloque..." e, no máximo, 1 ou 2 frases
    secas no meio ("E garfo? Nem pensar!"). A piada nunca toma o lugar da explicação.
63. **Animado, não gritado:** ritmo de conversa com um amigo que acha aquilo incrível. Nada de "gente", "pasmem", meme
    ou piada que zomba de quem assiste.
64. **O tom "engraçadão"** (dança, rebolada, piada em toda frase) foi testado e não ganhou: o alcance caiu no
    Instagram e no TikTok.
65. **A frase engraçada vira cena:** "um vizinho que arrasta móveis à meia-noite" → o relógio em 00:00 e alguém
    acordando.

## 5. Câmera, ritmo, visual e som

66. **A câmera perto da ação.** O personagem ocupa pelo menos 1/3 da altura da tela quando aparece, e a peça da frase
    enche boa parte do quadro. Câmera longe deixa o cenário com cara de vazio.
67. **A câmera sempre se mexendo, com vontade:** chegando, girando em volta, subindo, passando de lado. Câmera
    parada dá sensação de vídeo parado.
68. **Plano aberto é tempero, não prato:** só no gancho, numa revelação ("olha o tamanho disso") e no fim. No resto,
    médio, perto e detalhe.
69. **Dois alvos só se estiverem perto um do outro.** Filmar o personagem e uma coisa lá longe obriga a câmera a abrir,
    e os dois ficam pequenos.
70. **Encha o quadro:** coisas do lugar perto da ação (uma pedra, uma caixa, uma ferramenta, uma planta) e algo na
    frente da câmera de vez em quando. Fundo vazio é porta de saída.
71. **A imagem muda a cada 1 ou 2 segundos:** uma frase, um plano de câmera. Num viral, foram 18 trocas de plano por
    minuto.
72. **Cada frase é uma cena diferente**, com 4 coisas: a câmera mexendo, o personagem atuando, algo acontecendo e um
    texto ou um som.
73. **A mesma animação em frases seguidas** é o que mais faz a pessoa sair.
74. **O que a voz fala aparece na hora**, não um segundo depois.
75. **Legenda uma palavra por vez, no meio da tela**, com o termo-chave em amarelo.
76. **A camada de informação:** pílulas que repetem o que a voz diz (vermelho = problema, verde = funciona), placas
    ("VAZANDO"), medidores, etapas numeradas. Até 3 de uma vez.
77. **O invisível vira visível:** luz como feixe, calor como fogo, água escorrendo.
78. **Preto e branco e rebobinar, só no desastre mais forte,** no máximo 2 por vídeo.
79. **Visual bonito é o mínimo, não o que faz viralizar:** o vídeo mais caprichado do canal foi um dos que menos
    espalharam (2,2 envios a cada mil views).
80. **A fala ocupa ~90% do vídeo.** Respiro longo é porta de saída.
81. **Um efeito sonoro em cada interação** (os virais têm um a cada 2 segundos), sempre por baixo da voz.
82. **Trilha baixinha o vídeo todo**, uns 15 dB abaixo da voz.
83. **Volume final em −14 LUFS**, o padrão das redes (a Máquina já faz). Som estourado vira reclamação nos
    comentários.
84. **Tudo que importa no meio da tela:** os botões e o texto do post cobrem a parte de baixo e o lado direito.
85. **60 quadros por segundo** deixa o movimento mais liso (`"fps": 60` no roteiro.json).

## 6. A capa e o título

86. **A capa é o 1º quadro do vídeo**, com a pergunta escrita no topo: quem toca na capa não percebe corte.
87. **Tudo exagerado:** a cara, o gesto, o tamanho do objeto e o detalhe mais estranho. A capa tem que dar uma emoção
    (susto, curiosidade, riso).
88. **Um círculo vermelho no detalhe estranho** e contraste forte.
89. **Tudo que importa entre 1/8 e 7/8 da altura:** o TikTok e o Instagram cortam a capa em 3:4 na grade do perfil.
90. **A pergunta numa caixa branca, com 1 a 3 palavras na cor do canal.**
91. **Título de busca:** a pergunta que uma criança curiosa faria e alguém digitaria, com o detalhe que intriga. Até
    ~60 caracteres, sem hashtag e sem emoji. Ex.: "Como um avião tão pesado consegue voar?"
92. **O vídeo responde o título.** Sempre.
93. **A IA dá 2 opções de título** e anota qual você escolheu: o mesmo jeito em 2 vídeos vira preferência.
94. **No YouTube Shorts, a capa é o 1º quadro:** na hora de postar, escolha o primeiro quadro, que é a própria capa.
95. **Teste capa com 1, 2 ou 3 palavras coloridas** e compare as visitas ao perfil. (em teste)

## 7. O fim e o pedido

96. **Um pedido só, fácil de responder, logo depois da vitória.** Empilhar pedidos (curte, segue, manda, link)
    derruba.
97. **Uma pergunta curta ligada ao tema, que se responde com uma palavra ou uma história:** "Qual coisa do dia a dia a
    gente desmonta no próximo? Comenta aí." Foi o fim do vídeo mais enviado do canal.
98. **O par de palavras do tema:** "Se você sabia, comente [palavra]. Se não sabia, comente [outra]." Quem sabia se
    exibe, quem não sabia brinca consigo mesmo, e os dois comentam.
99. **Não peça like.**
100. **Por padrão, sem venda e sem "link na bio" na fala.** As redes mostram mais o vídeo que não parece anúncio. O
     vídeo sutil espalha mais, e o que leva pro link vende mais: alterne e meça os dois.
101. **"Segue" no meio do vídeo, se usar:** uma frase rápida, de até 8 palavras, ligada ao tema, logo depois de um
     "Mas" (o problema na tela, a resposta ainda não veio), entre 1/3 e 60% do vídeo. Ex.: "Segue aí, que essa conta
     vai dar errado."
102. **Vídeo pra fazer seguir:** no fim, o gancho do próximo vídeo ("Mas [o fato estranho]. Então [a pergunta]?
     Segue, que esse é o próximo.") e poste o próximo logo, porque promessa não cumprida não volta. (em teste)
103. **Quer vender algo? "Comenta [palavra]" e o link chega no direct** (com uma resposta automática, como o
     ManyChat): num canal, deu 30 vendas em 3 dias, contra 17 do link da bio no mesmo período. Só funciona com o
     pedido falado no vídeo: falado, 12 pedidos a cada mil views; só escrito no comentário, menos de 0,1.
104. **O vídeo que vende segura menos** (36,7% pularam nos 3 s, contra 31,9% da média do canal): é troca. Use num
     vídeo de venda, não em todos.
105. **Link em comentário e na legenda não é clicável** no Shorts, no Reels nem no TikTok: o caminho é a bio, o vídeo
     relacionado (YouTube) ou o direct.

## 8. O texto de postar

106. **Descrição simples:** uma abertura de 1 ou 2 frases (a pergunta + o começo da resposta), o que o vídeo mostra,
     a assinatura do canal e as hashtags.
107. **Até 5 hashtags, em todas as redes** (o Instagram não aceita mais que 5 desde dezembro de 2025): o tema, 2 do
     nicho e a do canal. #reels, #viral e #fyp não ajudam.
108. **Palavras de busca no título e na descrição:** as redes leem o texto (e o TikTok, também a fala e o texto da
     tela) pra mostrar o vídeo na busca. Escreva como a pessoa pesquisaria: "como funciona o chuveiro elétrico".
109. **Comentário fixado que aprofunda:** a pergunta em caixa alta, uma linha de espanto e de 4 a 7 itens numerados,
     com um detalhe extra de cada peça. O último item é uma pergunta.
110. **Responda os comentários na 1ª hora,** de preferência com outra pergunta: conversa nos comentários ajuda o vídeo
     a ser mostrado pra mais gente.
111. **Fixe o melhor comentário do público** (a dúvida mais curtida, a história boa): puxa mais gente pra comentar.
112. **Não prometa no texto o que o vídeo não mostra**, e nada de texto copiado de outro canal.

## 9. Postar

113. **O mesmo vídeo nas 3 redes, cada uma com o seu texto e a sua capa** (o que marcar em cada uma está em
     `youtube.md`, `instagram.md` e `tiktok.md`).
114. **Sempre o arquivo original da Máquina.** Vídeo baixado de outra rede vem com marca d'água, e o Instagram e o
     TikTok mostram menos vídeo com marca de outro app.
115. **Comece pelo almoço (11h às 13h) e pelo começo da noite (18h às 21h)**, no horário de Brasília. Depois de umas
     semanas, use o horário do seu público, que cada rede mostra (`horarios.md`).
116. **Horário fixo por 2 semanas antes de comparar.** Mudar todo dia não ensina nada.
117. **Constância vale mais que quantidade:** no Instagram, quem posta de 3 a 5 vezes por semana cresce mais rápido
     que quem posta 1 ou 2 (estudo com 2 milhões de posts). Um canal feito com este método posta 2 por dia.
118. **Não poste vários de uma vez** na mesma rede: um vídeo come o alcance do outro, e o TikTok pode achar que é
     spam. Deixe umas 4 a 6 horas entre um e outro.
119. **Fique por perto na 1ª hora:** responda os comentários e confira se a capa e o texto entraram certo.
120. **Confira a capa na grade do perfil** depois de postar (o Instagram e o TikTok cortam em 3:4).
121. **No YouTube, marque "não é conteúdo para crianças"** se o canal é pra todo mundo (`cuidados.md`).
122. **Aviso de IA:** animação com cara de desenho não precisa; vídeo que parece real precisa. Se a rede perguntar,
     responda com sinceridade (`cuidados.md`).
123. **No YouTube, ligue o vídeo relacionado** do Short a um vídeo seu: é o único link clicável do Short.

## 10. Depois de postar

124. **Os 3 números de todo vídeo:** a % que pula nos 3 primeiros segundos, os envios a cada mil views e as views por
     hora nas primeiras 24 h (onde ver cada um: `medir-e-testar.md`).
125. **Passou de 35% pulando nos 3 s:** o problema é o gancho ou a capa. Teste uma pergunta com contradição.
126. **Poucos envios:** o tema não tem turma pra quem mandar, ou faltou o "é por isso que" e a dica.
127. **Compare sempre na mesma idade:** as primeiras 24 h de um contra as primeiras 24 h do outro.
128. **Vídeo que começa devagar pode crescer depois,** se quem fica assiste até o fim: um vídeo de pesca voltou a
     acelerar uma semana depois (+372 mil views em 36 h). Não apague vídeo que foi mal.
129. **Viral não é o mesmo que seguidor:** olhe os seguidores a cada mil views. No canal, a média foi 5,9; o vídeo
     mais viral trouxe 4,4; os de curiosidade pura, de 10 a 11.
130. **Prender o começo não basta:** o vídeo que menos gente pulou foi um dos que menos foram enviados (2,8 envios a
     cada mil, contra 59,9 do melhor). A pessoa ficou, mas não tinha pra quem mandar.
131. **Cada rede tem o seu gosto:** um vídeo que foi mal numa pode ir bem noutra. No canal, o nicho de dinheiro foi o
     melhor do Instagram e não pegou no TikTok.
132. **Uma mudança por vez:** mudou o gancho e o horário juntos, não dá pra saber o que funcionou.
133. **3 vídeos com o mesmo resultado viram regra;** com 1 ou 2, é palpite.
134. **No YouTube, compare as visualizações engajadas,** não as views: desde agosto de 2026, a view conta desde o 1º
     quadro.
135. **Anote tudo:** o resultado de cada vídeo na `canal/pauta.md` e o que virou regra no `canal/aprendizados.md`. É
     assim que a IA aprende o que dá certo no seu canal.

## 11. Estudar os virais dos outros

136. **Estude os virais do seu nicho antes de inventar:** a estrutura de quem já furou é o atalho. Use o menu
     **Estudar virais**.
137. **Escolha o viral certo:** muito mais views que os seguidores do canal (3 vezes ou mais) e de preferência
     recente.
138. **Estude também um vídeo fraco do mesmo canal:** a diferença entre os dois mostra o que fez o trabalho.
139. **Um viral é uma pista; 3 com o mesmo padrão, de canais diferentes, são um padrão;** testado no seu canal com
     número, vira regra.
140. **Leve o esqueleto, nunca as frases**, a piada ou a sequência de peças. E nunca poste o vídeo dos outros.
141. **Guarde a conclusão no caderno** (`estudos/virais-estudados.md`): é ele que a IA lê antes do próximo roteiro.

## De onde vêm os números

- **Os virais estudados:** 15 vídeos de "como funciona" com mais de 1 milhão de views, de dois canais (a fala, o
  ritmo, o visual e o som medidos em cada um), mais o catálogo de um deles pela API do YouTube (30/10/2026)
- **O canal feito com este método:** 22 vídeos postados de 25/10 a 05/11/2026, com mais de 7 milhões de views no
  YouTube e no Instagram, medidos pelas APIs das duas redes e pelo TikTok Studio
- **Postar:** Buffer, "How often should you post on Instagram" (2 milhões de posts, 2026); o limite de 5 hashtags do
  Instagram (anúncio de 19/12/2025)
- **YouTube:** a contagem de views desde o 1º quadro (24/08/2026)
- As regras de cada rede, com as fontes, estão em `youtube.md`, `instagram.md`, `tiktok.md` e `cuidados.md`
